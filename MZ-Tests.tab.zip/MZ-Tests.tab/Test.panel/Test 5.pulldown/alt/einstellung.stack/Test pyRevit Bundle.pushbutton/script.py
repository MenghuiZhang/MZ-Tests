# coding: utf8
from pyrevit import forms,revit
from pyrevit import script
print("Works!")
doc = revit.doc
print(doc)