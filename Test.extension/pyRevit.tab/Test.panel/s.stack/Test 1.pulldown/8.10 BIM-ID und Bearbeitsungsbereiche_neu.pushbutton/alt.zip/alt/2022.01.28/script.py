# coding: utf8
from logging import Logger
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from IGF_log import getlog
from rpw import revit, DB
from pyrevit import script, forms
import clr
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles, Visibility
from System.Windows.Media import Brushes, BrushConverter
from System.Windows.Forms import OpenFileDialog,DialogResult
from System.Windows.Controls import *
from pyrevit.forms import WPFWindow
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel
from System.Runtime.InteropServices import Marshal
from IGF_forms import abfrage

__title__ = "8.10 BIM-ID und Bearbeitsungsbereiche (RUB-NA)"
__doc__ = """BIM-ID und Bearbeitunsbereich aus excel in Modell schreiben

[2022.01.27]
Version: 2.2
"""
__authors__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

uidoc = revit.uidoc
doc = revit.doc

logger = script.get_logger()
output = script.get_output()

name = doc.ProjectInformation.Name
number = doc.ProjectInformation.Number

bimid_config = script.get_config(name+number+'BIM-ID und Bearbeitsungsbereiche')

muster_bb = ['KG4xx_Musterbereich']


# Bearbeitungsbereich
worksets = DB.FilteredWorksetCollector(doc).OfKind(DB.WorksetKind.UserWorkset)
Workset_dict = {}
for el in worksets:
    Workset_dict[el.Name] = el.Id.ToString()

# Exceldaten
class Exceldaten(object):
    def __init__(self):
        self.checked = False
        self.bb = False
        self.Systemname = ''
        self.GK = ''
        self.KG = ''
        self.KN01 = ''
        self.KN02 = ''
        self.AnNr = ''
        self.AnGeAn = ''
        self.PzAT = ''
        self.PzAZ = ''
        self.SysKZ = ''
        self.Sysname = ''
        self.BIMID = ''
        self.TempW = ''
        self.TempS = ''
        self.Workset = ''
Liste_Luft = ObservableCollection[Exceldaten]()
Liste_Rohr = ObservableCollection[Exceldaten]()
Liste_All = ObservableCollection[Exceldaten]()

def datenlesen(filepath):
    ex = Excel.ApplicationClass()
    book = ex.Workbooks.Open(filepath)
    sheet = book.Worksheets['Luft']
    rows = sheet.UsedRange.Rows.Count
    for row in range(3,rows+1):
        tempclass = Exceldaten()
        sysname = sheet.Cells[row, 1].Value2
        GK = sheet.Cells[row, 2].Value2
        KG = str(int(sheet.Cells[row, 3].Value2))
        KN01 = str(int(sheet.Cells[row, 4].Value2))
        if len(KN01) == 1:
            KN01 = '0' + KN01
        KN02 = str(int(sheet.Cells[row, 5].Value2))
        if len(KN02) == 1:
            KN02 = '0' + KN02
        bimid = sheet.Cells[row, 6].Value2
        annr = sheet.Cells[row, 7].Value2
        gean = sheet.Cells[row, 8].Value2
        TempW = sheet.Cells[row, 9].Value2
        TempS = sheet.Cells[row, 10].Value2
        PzAT = sheet.Cells[row, 11].Value2
        PzAZ = sheet.Cells[row, 12].Value2
        syskz = sheet.Cells[row, 13].Value2
        sysna = sheet.Cells[row, 14].Value2
        workset = sheet.Cells[row, 15].Value2
        tempclass.AnNr = annr
        tempclass.AnGeAn = gean
        tempclass.SysKZ = syskz
        tempclass.Sysname = sysna
        tempclass.Systemname = sysname
        tempclass.GK = GK
        tempclass.KG = KG
        tempclass.KN01 = KN01
        tempclass.KN02 = KN02
        tempclass.TempW = TempW
        tempclass.TempS = TempS
        tempclass.PzAT = PzAT
        tempclass.PzAZ = PzAZ
        tempclass.BIMID = bimid
        tempclass.Workset = workset
        Liste_Luft.Add(tempclass)
        Liste_All.Add(tempclass)
    
    sheet = book.Worksheets['Rohr']
    rows = sheet.UsedRange.Rows.Count
    for row in range(3,rows+1):
        tempclass = Exceldaten()
        sysname = sheet.Cells[row, 1].Value2
        GK = sheet.Cells[row, 2].Value2
        KG = str(int(sheet.Cells[row, 3].Value2))
        KN01 = str(int(sheet.Cells[row, 4].Value2))
        if len(KN01) == 1:
            KN01 = '0' + KN01
        KN02 = str(int(sheet.Cells[row, 5].Value2))
        if len(KN02) == 1:
            KN02 = '0' + KN02
        bimid = sheet.Cells[row, 6].Value2
        annr = sheet.Cells[row, 7].Value2
        gean = sheet.Cells[row, 8].Value2
        PzAT = sheet.Cells[row, 9].Value2
        PzAZ = sheet.Cells[row, 10].Value2
        syskz = sheet.Cells[row, 11].Value2
        sysna = sheet.Cells[row, 12].Value2
        workset = sheet.Cells[row, 13].Value2
        tempclass.AnNr = annr
        tempclass.AnGeAn = gean
        tempclass.SysKZ = syskz
        tempclass.Sysname = sysna
        tempclass.Systemname = sysname
        tempclass.GK = GK
        tempclass.KG = KG
        tempclass.KN01 = KN01
        tempclass.KN02 = KN02
        tempclass.PzAT = PzAT
        tempclass.PzAZ = PzAZ
        tempclass.BIMID = bimid
        tempclass.Workset = workset
        Liste_Rohr.Add(tempclass)
        Liste_All.Add(tempclass)
    book.Save()
    book.Close()
    Marshal.FinalReleaseComObject(sheet)
    Marshal.FinalReleaseComObject(book)
    ex.Quit()
    Marshal.FinalReleaseComObject(ex)


try:
    Adresse = bimid_config.bimid
    try:
        datenlesen(Adresse)
    except Exception as e:
        logger.error(e)
except:
    pass


# ExcelBimId GUI
class ExcelBimId(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr):
        self.liste_Luft = liste_Luft
        self.liste_Rohr = liste_Rohr
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[Exceldaten]()
        self.altdatagrid = None
        self.read_config()

        try:
            self.dataGrid.ItemsSource = self.liste_Luft
            self.altdatagrid = self.liste_Luft
            self.backAll()
            self.click(self.luft)
        except Exception as e:
            logger.error(e)

        self.systemsuche.TextChanged += self.search_txt_changed
        self.Adresse.TextChanged += self.excel_changed

    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal
    def backAll(self):
        self.back(self.luft)
        self.back(self.rohr)

    def rohr(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Columns[11].Visibility = Visibility.Hidden
        self.dataGrid.Columns[12].Visibility = Visibility.Hidden
        self.dataGrid.Items.Refresh()

    def luft(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Columns[11].Visibility = Visibility.Visible
        self.dataGrid.Columns[12].Visibility = Visibility.Visible
        self.dataGrid.Items.Refresh()

    def read_config(self):
        try:
            self.Adresse.Text = str(bimid_config.bimid)
        except:
            self.Adresse.Text = bimid_config.bimid = ""

    def write_config(self):
        bimid_config.bimid = self.Adresse.Text.encode('utf-8')
        script.save_config()

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.systemsuche.Text.upper()
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.Systemname.upper().find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()

    def excel_changed(self, sender, args):
        Liste_Luft.Clear()
        Liste_Rohr.Clear()
        try:
            datenlesen(self.Adresse.Text)
        except:
            pass
        self.liste_Luft = Liste_Luft
        self.dataGrid.ItemsSource = Liste_Luft

    def durchsuchen(self,sender,args):
        dialog = OpenFileDialog()
        dialog.Multiselect = False
        dialog.Title = "BIM-ID Datei suchen"
        dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
        if dialog.ShowDialog() == DialogResult.OK:
            self.Adresse.Text = dialog.FileName
        self.write_config()

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()
    def checkallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = True
        self.dataGrid.Items.Refresh()

    def uncheckallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = False
        self.dataGrid.Items.Refresh()

    def toggleallbb(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.bb
            item.bb = not value
        self.dataGrid.Items.Refresh()

    def ok(self,sender,args):
        self.Close()

windowExcelBimId = ExcelBimId("Window.xaml",Liste_Luft,Liste_Rohr)
try:
    windowExcelBimId.ShowDialog()
except Exception as e:
    logger.error(e)
    windowExcelBimId.Close()
    script.exit()

muster_bb_bearbeiten = windowExcelBimId.muster.IsChecked
sichtbar = windowExcelBimId.sichtbar.IsChecked

worksset_Excel = [e.Workset for e in Liste_All if e.checked or e.bb]
worksset_Excel = list(worksset_Excel)
fehlendeworkset = []
if len(worksset_Excel) > 0:
    for item in worksset_Excel:
        if not item in Workset_dict.keys():
           fehlendeworkset.append(item)
fehlendeworkset = set(fehlendeworkset)
fehlendeworkset = list(fehlendeworkset)

# Bearbeitungsbereich erstellen
if len(fehlendeworkset) > 0:
    logger.error('folgende Bearbeitungsbereiche fehlt:')
    for e in fehlendeworkset:
        logger.error(e)

    if forms.alert("fehlende Bearbeitungsbereiche erstellen?", ok=False, yes=True, no=True):
        t = DB.Transaction(doc)
        t.Start('Bearbeitungsbereich erstellen')
        for el in fehlendeworkset:
            logger.info(30*'-')
            logger.info(el)
            try:
                item = DB.Workset.Create(doc,el)
                DB.WorksetDefaultVisibilitySettings.SetWorksetVisibility(item,sichtbar)
                Workset_dict[el] = item.Id.ToString()
                logger.info('Bearbeitungsbereich {} erstellt'.format(el))
            except Exception as e:
                logger.error(e)
        doc.Regenerate()
        t.Commit()
        t.Dispose()

# Luft System
luftsys = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
luftsysids = luftsys.ToElementIds()
luftsys.Dispose()

# Rohr System
rohrsys = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
rohrsysids = rohrsys.ToElementIds()
rohrsys.Dispose()


class MEP_System:
    def __init__(self,System_Excel):
        self.bimid = System_Excel.checked
        self.systemname = System_Excel.Systemname
        self.GK = System_Excel.GK
        self.KG = System_Excel.KG
        self.KN01 = System_Excel.KN01
        self.KN02 = System_Excel.KN02
        self.BIMID = System_Excel.BIMID
        self.AnNr = System_Excel.AnNr
        self.AnGeAn = System_Excel.AnGeAn
        self.SysKZ = System_Excel.SysKZ
        self.Sysname = System_Excel.Sysname
        self.PzAT = System_Excel.PzAT
        self.PzAZ = System_Excel.PzAZ
        self.TempW = System_Excel.TempW
        self.TempS = System_Excel.TempS
        self.Workset = System_Excel.Workset
        self.bb = System_Excel.bb

        try:
            self.PzAT = float(self.PzAT[:self.PzAT.find('%')])/100
        except:
            pass
        
        self.liste_system = []
        self.liste_bauteile = []
        self.typ = None
        
    def get_elemente(self):
        for el in self.liste_system:
            systemid = el.Id.ToString()
            try:
                elemente = el.DuctNetwork
            except:
                elemente = el.PipingNetwork

            for elem in elemente:
                cate = elem.Category.Id.ToString()
                # Leitung
                if cate in ['-2008000','-2008020','-2008050','-2008044']:
                    if elem.MEPSystem.Id.ToString() == systemid:
                        if elem.Id.ToString() not in self.liste_bauteile:
                            self.liste_bauteile.append(elem.Id.ToString())
                # Auslass, Sprinkler
                elif cate in ['-2008013','-2008099']:
                    if list(elem.MEPModel.ConnectorManager.Connectors)[0].MEPSystem.Id.ToString() == systemid:
                        if elem.Id.ToString() not in self.liste_bauteile:
                            self.liste_bauteile.append(elem.Id.ToString())
                # Bauteile
                elif cate in ['-2008010','-2008016','-2001140','-2008049','-2008055','-2001160']:
                    conns = elem.MEPModel.ConnectorManager.Connectors
                    In = {}
                    Out = {}
                    Unverbunden = {}
                    for conn in conns:
                        if conn.IsConnected:
                            if conn.Direction.ToString() == 'In':
                                In[conn.Id] = conn
                            else:
                                Out[conn.Id] = conn
                        else:
                            Unverbunden[conn.Id] = conn
                    sorted(In)
                    sorted(Out)
                    sorted(Unverbunden)
                    conns = In.values()[:]
                    connouts = Out.values()[:]
                    connunvers = Unverbunden.values()[:]
                    conns.extend(connouts)
                    conns.extend(connunvers)
                    
                    try:
                        for conn in conns:
                            if not conn.MEPSystem:
                                continue
                            else:
                                if conn.MEPSystem.Id.ToString() == systemid:
                                    if elem.Id.ToString() not in self.liste_bauteile:
                                        self.liste_bauteile.append(elem.Id.ToString())
                    except:
                        pass

    def get_systemtyp(self):
        for el in self.liste_system:
            typ = el.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsElementId()
            self.typ = doc.GetElement(typ)
            break
    
    def wert_schreiben(self, elem, param_name, wert):
        if not wert is None:
            para = elem.LookupParameter(param_name)
            if para:
                if para.StorageType.ToString() == 'Double':
                    para.SetValueString(str(wert))
                else:
                    para.Set(wert)

    def wert_schreiben_system(self):
        self.wert_schreiben(self.typ,'IGF_X_Gewerkkürzel',str(self.GK))
        self.wert_schreiben(self.typ,'IGF_X_Kostengruppe',int(self.KG))
        self.wert_schreiben(self.typ,'IGF_X_Kennnummer_1',int(self.KN01))
        self.wert_schreiben(self.typ,'IGF_X_Kennnummer_2',int(self.KN02))
        self.wert_schreiben(self.typ,'IGF_X_BIM-ID',str(self.BIMID))
        self.wert_schreiben(self.typ,'IGF_X_SystemName',str(self.Sysname))
        self.wert_schreiben(self.typ,'IGF_X_SystemKürzel',str(self.SysKZ))
        self.wert_schreiben(self.typ,'IGF_X_AnlagenGeräteAnzahl',int(self.AnGeAn))
        self.wert_schreiben(self.typ,'IGF_X_AnlagenNr',int(self.AnNr))
        self.wert_schreiben(self.typ,'IGF_X_AnlagenProzentualAnteil',float(self.PzAT))
        self.wert_schreiben(self.typ,'IGF_X_AnlagenProzentualAnzahl',int(self.PzAZ))
        self.wert_schreiben(self.typ,'IGF_RLT_ZuluftTemperaturSo',str(self.TempS))
        self.wert_schreiben(self.typ,'IGF_RLT_ZuluftTemperaturWi',str(self.TempW))
        

class Bauteil:
    def __init__(self,elemid,system):
        self.elemid = DB.ElementId(int(elemid))
        self.elem = doc.GetElement(self.elemid)
        self.system = system
        self.bb = self.elem.LookupParameter('Bearbeitungsbereich').AsValueString()

    def wert_schreiben(self, elem, param_name, wert):
        if not wert is None:
            para = elem.LookupParameter(param_name)
            if para:
                if para.StorageType.ToString() == 'Double':
                    para.SetValueString(str(wert))
                else:
                    para.Set(wert)

    
    def werte_schreiben_bimid(self):
        self.wert_schreiben(self.elem,'IGF_X_Gewerkkürzel_Exemplar',str(self.system.GK))
        self.wert_schreiben(self.elem,'IGF_X_KG_Exemplar',int(self.system.KG))
        self.wert_schreiben(self.elem,'IGF_X_KN01_Exemplar',int(self.system.KN01))
        self.wert_schreiben(self.elem,'IGF_X_KN02_Exemplar',int(self.system.KN02))
        self.wert_schreiben(self.elem,'IGF_X_BIM-ID_Exemplar',str(self.system.BIMID))

        self.wert_schreiben(self.elem,'IGF_X_AnlagenGeräteAnzahl_Exemplar',int(self.system.AnGeAn))
        self.wert_schreiben(self.elem,'IGF_X_AnlagenNr_Exemplar',int(self.system.AnNr))
        self.wert_schreiben(self.elem,'IGF_X_SystemKürzel_Exemplar',str(self.system.SysKZ))
        self.wert_schreiben(self.elem,'IGF_X_SystemName_Exemplar',str(self.system.Sysname))

        self.wert_schreiben(self.elem,'IGF_RLT_ZuluftTemperaturSo_Exemplar',str(self.system.TempS))
        self.wert_schreiben(self.elem,'IGF_RLT_ZuluftTemperaturWi_Exemplar',str(self.system.TempW))

    def werte_schreiben_BB(self):
        try:
            self.wert_schreiben(self.elem,'Bearbeitungsbereich',int(Workset_dict[self.system.Workset]))
        except Exception as e:
            logger.error(e)

dict_systeme = {}

for system in Liste_Luft:
    if system.checked or system.bb:
        dict_systeme[system.Systemname] = MEP_System(system)
for system in Liste_Rohr:
    if system.checked or system.bb:
        dict_systeme[system.Systemname] = MEP_System(system)

if len(dict_systeme.keys()) == 0:
    script.exit()

for sysid in luftsysids:
    elem = doc.GetElement(sysid)
    systyp = elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
    if systyp in dict_systeme.keys():
        system = dict_systeme[systyp]
        system.liste_system.append(elem)

for sysid in rohrsysids:
    elem = doc.GetElement(sysid)
    systyp = elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
    if systyp in dict_systeme.keys():
        system = dict_systeme[systyp]
        system.liste_system.append(elem)

liste = dict_systeme.keys()[:]
liste_neu = []
with forms.ProgressBar(title="{value}/{max_value} Systeme --- Datenermittlung",cancellable=True, step=1) as pb:
    for n,typ in enumerate(liste):
        if pb.cancelled:
            frage_schicht = abfrage(title= __title__,
                    info = 'Vorgang abrechen oder ermittlete Daten behalten?' , 
                    ja = True,ja_text= 'abbrechen',nein_text='weiter').ShowDialog()
            if frage_schicht.antwort == 'abbrechen':
                script.exit()
            else:
                break
        mepsystem = dict_systeme[typ]
        mepsystem.get_elemente()
        logger.info('{} Elemente in System {}'.format(len(mepsystem.liste_bauteile),mepsystem.systemname))
        liste_neu.append(mepsystem)
        pb.update_progress(n+1,len(liste))

bearbeitet = []
nichtbearbeitet = liste_neu[:]
t = DB.Transaction(doc,'BIM-ID')
t.Start()
if forms.alert('Daten schreiben?',yes=True,no=True,ok=False):
    with forms.ProgressBar(title='Systeme --- Datene schreiben',cancellable=True, step=10) as pb2:
        for n,mepsystem in enumerate(liste_neu):
            systeme_title = str(mepsystem.systemname) + ' --- ' + str(n+1) + '/' + str(len(liste_neu)) + 'Systeme'
            pb2.title = '{value}/{max_value} Elemente in System ' +  systeme_title
            pb2.step = int((len(mepsystem.liste_bauteile)) /1000) + 10
            mepsystem.get_systemtyp()
            try:
                mepsystem.wert_schreiben_system()
            except:
                pass
            for n1,bauteilid in enumerate(mepsystem.liste_bauteile):
                if pb2.cancelled:
                    if forms.alert('bisherige Änderung behalten?',yes=True,no=True,ok=False):
                        t.Commit()
                        logger.info('Folgenede Systeme sind bereits bearbeitet.')
                        for el in bearbeitet:
                            logger.info(el.systemname)
                        logger.info('---------------------------------------')
                        logger.info('Folgenede Systeme sind nicht bearbeitet.')
                        for el in nichtbearbeitet:
                            logger.info(el.systemname)
                    else:
                        t.RollBack()
                    
                    script.exit()
                bauteil = Bauteil(bauteilid,mepsystem)
                if bauteil.system.bimid:
                    bauteil.werte_schreiben_bimid()
                if bauteil.system.bb:
                    if bauteil.bb in muster_bb and not muster_bb_bearbeiten:
                        pass
                    else:
                        bauteil.werte_schreiben_BB()

                pb2.update_progress(n1+1, len(mepsystem.liste_bauteile))
            bearbeitet.append(mepsystem)
            nichtbearbeitet.remove(mepsystem)
            
t.Commit()