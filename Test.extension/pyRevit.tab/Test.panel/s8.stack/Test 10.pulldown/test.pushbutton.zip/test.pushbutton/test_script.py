# coding: utf8
# from IGF_log import getlog,getloglocal
from pyrevit import forms,script
# import os
# from eventhandler import config,ExternalEvent,_params,Externalliste

__title__ = "3.1 Dimensionen in Schema-Modell einlesen"
__doc__ = """

Parameter: 
IGF_X_SM_Durchmesser
IGF_X_RVT_TS_Nr

[2022.08.29]
Version: 2.0
"""
__authors__ = "Menghui Zhang"



logger = script.get_logger()

class Test(forms.WPFWindow):
    def __init__(self):
        forms.WPFWindow.__init__(self,'test.xaml',handle_esc=False)
    
    def testmethode(self, s, e):
        print('Test')
    

test = Test()
test.ShowDialog()

