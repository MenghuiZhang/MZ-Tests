# coding: utf8
from Autodesk.Revit.UI import IExternalEventHandler,ExternalEvent,TaskDialog
import Autodesk.Revit.DB as DB

class ListeExternalEvent(IExternalEventHandler):
    def __init__(self):
        self.GUI = None
        self.name = ''
        self.ExcuteApp = ''
        
    def Execute(self,uiapp):
        if self.ExcuteApp:
            try:
                self.ExcuteApp(uiapp)
            except:
                pass
        
    def GetName(self):
        return self.name

    def Dimension(self,uiapp):
        self.name = 'Kanalrechnenr'
        uidoc = uiapp.ActiveUIDocument
        doc = uidoc.Document
        elems = []
        if self.GUI.Kanalfitting.IsChecked:
            for elid in uidoc.Selection.GetElementIds():
                el = doc.GetElement(elid)
                if el.Category.Id.IntegerValue in [-2008000,-2008010]:
                    elems.append(el)
            if len(elems) == 0:
                TaskDialog.Show('Info','Kein Luftkanal/Luftkanalformteile ausgewählt!')
                return
        else:
            for elid in uidoc.Selection.GetElementIds():
                el = doc.GetElement(elid)
                if el.Category.Id.IntegerValue in [-2008000]:
                    elems.append(el)
            if len(elems) == 0:
                TaskDialog.Show('Info','Kein Luftkanal ausgewählt!')
                return
        kanalids = [e.Id.ToString() for e in elems if e.Category.Id.IntegerValue == -2008000]
        t = DB.Transaction(doc,'Kanäle anpassen')
        t.Start()
        if len(kanalids) == 0:
            
            for el in elems:
                try:
                    conns = el.MEPModel.ConnectorManager.Connectors
                    for conn in conns:
                        mepinfo = conn.GetMEPConnectorInfo()
                        d = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_DIAMETER))
                        r = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_RADIUS))
                        h = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_HEIGHT))
                        b = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_WIDTH))
                        if d != DB.ElementId.InvalidElementId:
                            try:
                                param = doc.GetElement(d)
                                el.get_Parameter(param.GetDefinition()).SetValueString(self.GUI.Durchmesser.SelectedItem.ToString())
                            except Exception as e:print(e)
                        if r != DB.ElementId.InvalidElementId:
                            try:
                                param = doc.GetElement(r)
                                el.get_Parameter(param.GetDefinition()).SetValueString(str(round(float(self.GUI.Durchmesser.SelectedItem.ToString())/2,1)))
                            except Exception as e:print(e)
                        else:
                            print(1)
                        if h != DB.ElementId.InvalidElementId:
                            try:
                                param = doc.GetElement(h)
                                el.get_Parameter(param.GetDefinition()).SetValueString(self.GUI.Hoehe.SelectedItem.ToString())
                            except:pass
                        if b != DB.ElementId.InvalidElementId:
                            try:
                                param = doc.GetElement(b)
                                el.get_Parameter(param.GetDefinition()).SetValueString(self.GUI.breite.SelectedItem.ToString())
                            except:pass
                except:pass

        else:
            for el in elems:
                if el.Category.Id.IntegerValue == -2008000:
                    try:
                        if self.GUI.breite.SelectedIndex != -1:
                            el.LookupParameter('Breite').SetValueString(self.GUI.breite.SelectedItem.ToString())
                        if self.GUI.Hoehe.SelectedIndex != -1:
                            el.LookupParameter('Höhe').SetValueString(self.GUI.Hoehe.SelectedItem.ToString())
                    except:
                        try:
                            if self.GUI.Durchmesser.SelectedIndex != -1:
                                el.LookupParameter('Durchmesser').SetValueString(self.GUI.Durchmesser.SelectedItem.ToString())
                        except Exception as e:print(e)
                else:
                    try:
                        conns = el.MEPModel.ConnectorManager.Connectors
                        for conn in conns:
                            refs = conn.AllRefs
                            for ref in refs:
                                if ref.Owner.Id.ToString() in kanalids:
                                    mepinfo = conn.GetMEPConnectorInfo()
                                    d = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_DIAMETER))
                                    r = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_RADIUS))
                                    h = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_HEIGHT))
                                    b = mepinfo.GetAssociateFamilyParameterId(DB.ElementId(DB.BuiltInParameter.CONNECTOR_WIDTH))
                                    if d != DB.ElementId.InvalidElementId:
                                        try:
                                            param = doc.GetElement(d)
                                            el.get_Parameter(param.GetDefinition()).SetValueString(self.GUI.Durchmesser.SelectedItem.ToString())
                                        except Exception as e:print(e)
                                    if r != DB.ElementId.InvalidElementId:
                                        try:
                                            param = doc.GetElement(r)
                                            el.get_Parameter(param.GetDefinition()).SetValueString(str(round(float(self.GUI.Durchmesser.SelectedItem.ToString())/2,1)))
                                        except Exception as e:print(e)
                                    if h != DB.ElementId.InvalidElementId:
                                        try:
                                            param = doc.GetElement(h)
                                            el.get_Parameter(param.GetDefinition()).SetValueString(self.GUI.Hoehe.SelectedItem.ToString())
                                        except:pass
                                    if b != DB.ElementId.InvalidElementId:
                                        try:
                                            param = doc.GetElement(b)
                                            el.get_Parameter(param.GetDefinition()).SetValueString(self.GUI.breite.SelectedItem.ToString())
                                        except:pass
                    except:pass

        doc.Regenerate()
        t.Commit()
    
    def GUIAktualiesieren(self,uiapp):
        self.name = 'GUI aktualisieren'
        uidoc = uiapp.ActiveUIDocument
        doc = uidoc.Document
        elems = []
        for elid in uidoc.Selection.GetElementIds():
            el = doc.GetElement(elid)
            if el.Category.Id.IntegerValue in [-2008000]:
                elems.append(el)
        if len(elems) != 1:
            TaskDialog.Show('Info','Bitte nur ein Luftkanal auswählen!')
            return
        self.GUI.kanalanpassen.IsEnabled = True
        self.GUI.elems = elems
        for el in elems:
            try:
                b_p = el.LookupParameter('Breite')
                h_p = el.LookupParameter('Höhe')
                d_p = el.LookupParameter('Durchmesser')
                mh_p = el.LookupParameter('Mittlere Höhe')
                if b_p:
                    b = str(int(round(b_p.AsDouble() * 304.8)))
                    self.GUI.selectb.IsEnabled = True
                    self.GUI.selectb.Text = b
                else:
                    self.GUI.selectb.IsEnabled = False
                    self.GUI.selectb.Text = '-'
                if h_p:
                    h = str(int(round(h_p.AsDouble() * 304.8)))
                    self.GUI.selecth.IsEnabled = True
                    self.GUI.selecth.Text = h
                else:
                    self.GUI.selecth.IsEnabled = False
                    self.GUI.selecth.Text = '-'
                if d_p:
                    d = str(int(round(d_p.AsDouble() * 304.8)))
                    self.GUI.selectd.IsEnabled = True
                    self.GUI.selectd.Text = d
                else:
                    self.GUI.selectd.IsEnabled = False
                    self.GUI.selectd.Text = '-'
                if mh_p:
                    mh = str(int(round(mh_p.AsDouble() * 304.8)))
                    self.GUI.mhoehe.IsEnabled = True
                    self.GUI.mhoehe.Text = mh
                else:
                    self.GUI.mhoehe.IsEnabled = False
                    self.GUI.mhoehe.Text = '-'

            except Exception as e:
                print(e)
                self.GUI.kanalanpassen.IsEnabled = False
    
    def KANALAnpassen(self,uiapp):
        self.name = 'Kanal anpassen'
        uidoc = uiapp.ActiveUIDocument
        doc = uidoc.Document
        elems = self.GUI.elems
        el = elems[0]
        t = DB.Transaction(doc,'Kanal anpassen')
        t.Start()
        self.GUI.kanalanpassen.IsEnabled = False
        if self.GUI.selectb.IsEnabled:
            try:
                el.LookupParameter('Breite').SetValueString(self.GUI.selectb.Text)
            except Exception as e:print(e)
        if self.GUI.selecth.IsEnabled:
            try:
                el.LookupParameter('Höhe').SetValueString(self.GUI.selecth.Text)
            except Exception as e:print(e)
        if self.GUI.selectd.IsEnabled:
            try:
                el.LookupParameter('Durchmesser').SetValueString(self.GUI.selectd.Text)
            except Exception as e:print(e)
        if self.GUI.mhoehe.IsEnabled:
            try:
                el.LookupParameter('Mittlere Höhe').SetValueString(self.GUI.mhoehe.Text)
            except Exception as e:print(e)
        t.Commit()
        t.Dispose()
