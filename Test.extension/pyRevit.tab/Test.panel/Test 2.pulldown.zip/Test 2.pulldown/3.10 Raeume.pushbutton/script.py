# coding: utf8
from cmath import phase
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from rpw import revit,DB
from pyrevit import script, forms
from IGF_log import getlog
from IGF_lib import get_value
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import Visibility

__title__ = "3.10 Raumluft_Übersicht"
__doc__ = """
Luftmengenberechnung in MEP-Räume

imput Parameter:
-------------------------
Fläche: Raumfläche
Volumen: Raumvolumen
Personenzahl: Anzahl der Personen für Luftmengenberechnung
TGA_RLT_VolumenstromProFaktor: Volumenstromfaktor pro [Faktor oder m3/h]
IGF_RLT_RaumDruckstufeEingabe: RaumDruckstufe
IGF_RLT_ÜberströmungSummeIn: Überstromluft einströmend
IGF_RLT_ÜberströmungSummeAus: Überstromluft ausströmend
TGA_RLT_RaumÜberströmungMenge: Menge der Überströmung
IGF_RLT_AbluftSumme24h: 24h Abluft
IGF_RLT_AbluftminSummeLabor: min. Laborabluft
IGF_RLT_AbluftmaxSummeLabor: max. Laborabluft
IGF_RLT_Nachtbetrieb: Nachtbetrieb
IGF_RLT_NachtbetriebVon: Beginn des Nachbetriebs
IGF_RLT_NachtbetriebBis: Ende des Nachbetriebs
IGF_RLT_NachtbetriebLW: Luftwechsel für Nacht [-1/h]
IGF_RLT_TieferNachtbetrieb: Tiefnachtbetrieb
IGF_RLT_TieferNachtbetriebVon: Beginn des Tiefnachtbetrieb
IGF_RLT_TieferNachtbetriebBis: Ende des Tiefnachtbetrieb
IGF_RLT_TieferNachtbetriebLW: Luftwechsel für Tiefnacht [-1/h]
TGA_RLT_VolumenstromProNummer: Kennziffer für Luftmengenberechnung
TGA_RLT_RaumÜberströmungAus: Überströmung aus Raum
-------------------------

output Parameter:
-------------------------
IGF_RLT_AbluftminSummeLabor24h: IGF_RLT_AbluftSumme24h + IGF_RLT_AbluftminSummeLabor
IGF_RLT_AbluftmaxSummeLabor24h: IGF_RLT_AbluftSumme24h + IGF_RLT_AbluftmaxSummeLabor
IGF_RLT_AbluftminRaum: min. Raumabluft, ohne Anteil der Überströmung
IGF_RLT_AbluftmaxRaum: max. Raumabluft, ohne Anteil der Überströmung
IGF_RLT_ZuluftminRaum: min. Raumzuluft 
IGF_RLT_ZuluftmaxRaum: max. Raumzuluft
TGA_RLT_VolumenstromProEinheit: Einheit
Angegebener Zuluftstrom: 
Angegebener Abluftluftstrom: 
IGF_RLT_AbluftminRaumGes:
IGF_RLT_AnlagenRaumAbluft: Raumabluft für Anlagenberechnung. ohne Anteil der 24h Abluft
IGF_RLT_AnlagenRaumZuluft: Raumzuluft für Anlagenberechnung
IGF_RLT_AnlagenRaum24hAbluft: 24h Abluft für Anlagenberechnung
IGF_RLT_RaumBilanz: Bilanz der aller Anschlüsse im Raum
IGF_RLT_RaumDruckstufeLegende: Raum Druckstufe Legende
IGF_RLT_Hinweis: Hinweis
IGF_RLT_NachtbetriebDauer: Dauer des Nachbetriebs 
IGF_RLT_ZuluftNachtRaum: Zuluftmengen des Nachbetriebs
IGF_RLT_AbluftNachtRaum: Abluftmengen des Nachbetriebs
IGF_RLT_TieferNachtbetriebDauer: Dauer des Tiefnachtbetrieb
IGF_RLT_ZuluftTieferNachtRaum: Zuluftmenegen des Tiefnachtbetrieb
IGF_RLT_AbluftTieferNachtRaum: Abluftmengen des Tiefnachtbetrieb

-------------------------

[2021.11.22]
Version: 1.2
"""
__author__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc
active_view = doc.ActiveView

dict_Luftauslass = {}
dict_ueberstrom = {}
dict_vsr = {}
liste_mepraum = []
PHASE = doc.Phases[0]
DICT_UEBERSTROM = {} ## MEP: 'Ein' ..., 'Aus'...
ELEMID_UEBER = [] ## ElememntId Überstrom
DICT_LUFTAUSLASS = {} ## MEP: OB_Auslässe
DICT_EINBAUTEILE = {} ## MEP: [VSRID]
DICT_MEP_AUSLASS = {} ## VSR: [MEPID,MEPID]
DICT_VSR_AUSLASS = {} ## VSRID: OB...Auslässe
DICT_VSR = {} ## VSRID: Class VSR


# Überstrom
Baugruppen_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Assemblies).WhereElementIsNotElementType()
Baugruppen = Baugruppen_collector.ToElementIds()
Baugruppen_collector.Dispose()

class Auslass(object):
    def __init__(self,elem,vol):
        self.elem = elem
        self.menge = vol
        self.conns = self.get_connector()
        self.typ = self.get_typ()
        self.raum = ''
        self.Raumid = ''
        self.get_einbauort()
        try:
            self.familieundtyp = self.elem.get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_AND_TYPE_PARAM).AsValueString()
        except:
            self.familieundtyp = ''
        

    def get_connector(self):
        return list(self.elem.MEPModel.ConnectorManager.Connectors)

    def get_typ(self):
        conn = self.conns[0]
        if conn.Direction.ToString() == 'Out':
            return 'Out'
        elif conn.Direction.ToString() == 'In':
            return 'In'
        else:
            return ''

    def get_einbauort(self):
        try:
            self.raum = self.elem.Space[PHASE].Number
            self.Raumid = self.elem.Space[PHASE].Id.ToString()
        except:
            if self.elem.LookupParameter('Bearbeitungsbereich').AsValueString() != 'KG4xx_Musterbereich':
                logger.error('Einbauort konnte nicht ermittelt werden, ElementId: {}'.format(self.elem.Id.ToString()))
            return ''

class Baugruppe:
    def __init__(self,elemid):
        self.elemid = elemid
        self.elem = doc.GetElement(self.elemid)
        self.members = self.get_members()
        if self.Pruefen():
            self.Volumen = get_value(self.elem.LookupParameter('IGF_RLT_Überströmung'))
            self.Eingang = ''
            self.Ausgang = ''

            self.Eingangauslass = ''
            self.Ausgangauslass = ''

            self.Leitung = ''
            self.Analyse()
            self.change_raum()
            
    def get_members(self):
        return self.elem.GetMemberIds()
    
    def Pruefen(self):
        if len(self.members) == 3:
            return True
        else:
            return False
    
    def Analyse(self):
        for elemid in self.members:
            elem = doc.GetElement(elemid)
            Category = elem.Category.Id.ToString()
            if Category == '-2008013':
                auslass = Auslass(elem,self.Volumen)
                if auslass.typ == 'Out':
                    self.Ausgangauslass = auslass
                    self.Ausgang = auslass.Raumid
                elif auslass.typ == 'In':
                    self.Eingangauslass = auslass
                    self.Eingang = auslass.Raumid
    def change_raum(self):
        temp = self.Eingangauslass.raum
        self.Eingangauslass.raum = self.Ausgangauslass.raum
        self.Ausgangauslass.raum = temp


with forms.ProgressBar(title = "{value}/{max_value} Überströmungsbaugruppen",cancellable=True, step=10) as pb:
    for n, BGid in enumerate(Baugruppen):
        if pb.cancelled:
            script.exit()

        pb.update_progress(n + 1, len(Baugruppen))
        baugruppe = Baugruppe(BGid)
        if not baugruppe.Pruefen():
            continue
        if not baugruppe.Eingang in DICT_UEBERSTROM.keys():
            DICT_UEBERSTROM[baugruppe.Eingang] = {'Ein':ObservableCollection[Auslass](),'Aus':ObservableCollection[Auslass]()}
        if not baugruppe.Ausgang in DICT_UEBERSTROM.keys():
            DICT_UEBERSTROM[baugruppe.Ausgang] = {'Ein':ObservableCollection[Auslass](),'Aus':ObservableCollection[Auslass]()}
        DICT_UEBERSTROM[baugruppe.Eingang]['Ein'].Add(baugruppe.Eingangauslass)
        DICT_UEBERSTROM[baugruppe.Ausgang]['Aus'].Add(baugruppe.Ausgangauslass)
        ELEMID_UEBER.append(baugruppe.Eingangauslass.elem.Id.ToString())
        ELEMID_UEBER.append(baugruppe.Ausgangauslass.elem.Id.ToString())


Ductterminal_coll = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_DuctTerminal).WhereElementIsNotElementType()
Ductterminalids = Ductterminal_coll.ToElementIds()
Ductterminal_coll.Dispose()

class Luftauslass(object):
    def __init__(self,elementid):
        self.elem_id = elementid
        self.elem = doc.GetElement(self.elem_id)
        self.RoutingListe = []
        self.size = ''
        self.vsr = ''
        self.Einbauteile = []
        self.Luftmengenmin = 0
        self.Luftmengenmax = 0
        self.Luftmengennacht = 0
        self.Luftmengentiefe = 0
        
        try:
            self.System = self.elem.LookupParameter('Systemtyp').AsValueString()
        except:
            self.System = ''

        self.Luftmengenermitteln()
        self.Wirkungsort(self.elem)
        self.einbauort = ''
        self.raumnr = ''
        self.get_Einbauort()
        
        try:
            self.familieundtyp = self.elem.get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_AND_TYPE_PARAM).AsValueString()
        except:
            self.familieundtyp = ''
        
        self.get_Size()
        
    
    def Luftmengenermitteln(self):
        try:
            self.Luftmengenmin = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromMin')))
        except:
            pass
        try:
            self.Luftmengenmax = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromMax')))
        except:
            pass
        try:
            self.Luftmengennacht = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromNacht')))
        except:
            pass
        try:
            self.Luftmengentiefe = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromTiefeNacht')))
        except:
            pass
    def get_Einbauort(self):
        try:
            self.einbauort = self.elem.Space[PHASE].Id.ToString()
            self.raumnr = self.elem.Space[PHASE].Number
        except:
            if self.elem.LookupParameter('Bearbeitungsbereich').AsValueString() != 'KG4xx_Musterbereich':
                logger.error('Einbauort konnte nicht ermittelt werden, ElementId: {}'.format(self.elem_id.ToString()))
            return ''

    def Wirkungsort(self,element):
        elemid = element.Id.ToString()
        self.RoutingListe.append(elemid)
        cate = element.Category.Name
        if not cate in ['Luftkanal Systeme', 'Rohr Systeme', 'Luftkanaldämmung außen', 'Luftkanaldämmung innen', 'Rohre', 'Rohrformteile', 'Rohrzubehör','Rohrdämmung']:
            conns = None
            try:
                conns = element.MEPModel.ConnectorManager.Connectors
            except:
                try:
                    conns = element.ConnectorManager.Connectors
                except:
                    pass

            if conns:
                for conn in conns:
                    refs = conn.AllRefs
                    for ref in refs:
                        owner = ref.Owner

                        if not owner.Id.ToString() in self.RoutingListe:
                            if owner.Category.Name == 'Luftkanalzubehör':
                                faminame = owner.Symbol.FamilyName
                                if faminame.upper().find('VOLUMENSTROMREGLER') != -1:
                                    self.vsr = owner.Id.ToString()
                                    return

                            self.Wirkungsort(owner)

                            if self.vsr:
                                return

    def get_Size(self):
        conns = self.elem.MEPModel.ConnectorManager.Connectors
        for conn in conns:
            try:
                self.size = 'DN ' + str(int(conn.Radius*609.6))
            except:
                Height = str(int(conn.Height*304.8))
                Width = str(int(conn.Width*304.8))
                self.size = Width + 'x' + Height
            break

class VSR(object):
    def __init__(self,elementid):
        self.elem_id = DB.ElementId(int(elementid))
        self.elem = doc.GetElement(self.elem_id)
        self.einbauort = ''
        self.checked = False
        self.einbauortnr = ''
        self.size = ''
        self.Auslass = ObservableCollection[Luftauslass]()
        self.liste_Raum = []
        self.Luftmengenmin = 0
        self.Luftmengenmax = 0
        self.Luftmengennacht = 0
        self.Luftmengentiefe = 0
        self.art = ''
        self.Luftmengenermitteln()
        self.get_Size()
        self.get_Einbauort()

        try:
            self.familieundtyp = self.elem.get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_AND_TYPE_PARAM).AsValueString()
        except:
            self.familieundtyp = ''

    def Luftmengenermitteln(self):
        try:
            self.Luftmengenmin = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromMin')))
        except:
            pass
        try:
            self.Luftmengenmax = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromMax')))
        except:
            pass
        try:
            self.Luftmengennacht = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromNacht')))
        except:
            pass
        try:
            self.Luftmengentiefe = float(get_value(self.elem.LookupParameter('IGF_RLT_AuslassVolumenstromTiefeNacht')))
        except:
            pass

    def get_Einbauort(self):
        try:
            self.einbauort = self.elem.Space[PHASE].Id.ToString()
            self.einbauortnr = self.elem.Space[PHASE].Number
        except:
            if self.elem.LookupParameter('Bearbeitungsbereich').AsValueString() != 'KG4xx_Musterbereich':
                logger.error('Einbauort konnte nicht ermittelt werden, ElementId: {}'.format(self.elem_id.ToString()))
            
            return 
    
    def get_Art(self):
        systyp = ''
        for el in self.Auslass:
            if el.System:
                systyp = el.System
                break
        if systyp:
            if systyp.upper().find('24H') != -1:
                self.art = '24h'
            elif systyp.upper().find('TIERHALTUNG') != -1:
                if systyp.upper().find('ZULUFT') != -1:
                    self.art = 'TZU'
                elif systyp.upper().find('ABLUFT') != -1:
                    self.art = 'TAB'
            elif systyp.upper().find('LABOR') != -1:
                if systyp.upper().find('ZULUFT') != -1:
                    self.art = 'LZU'
                elif systyp.upper().find('ABLUFT') != -1:
                    self.art = 'LAB'

            else:
                if systyp.upper().find('ZULUFT') != -1:
                    self.art = 'RZU'
                elif systyp.upper().find('ABLUFT') != -1:
                    self.art = 'RAB'
        else:
            self.art = 'XXX'
        


    def get_Size(self):
        try:
            diameter = str(int(list(self.elem.MEPModel.ConnectorManager.Connectors)[0].Radius*609.6))
            self.size = 'DN ' + diameter
        except:
            try:
                conn = list(self.elem.MEPModel.ConnectorManager.Connectors)[0]
                Height = str(int(conn.Height*304.8))
                Width = str(int(conn.Width*304.8))
                self.size = Width + 'x' + Height
            except:
                pass
       
with forms.ProgressBar(title = "{value}/{max_value} Luftauslässe",cancellable=True, step=10) as pb:
    for n, ductid in enumerate(Ductterminalids):
        if pb.cancelled:
            script.exit()

        pb.update_progress(n + 1, len(Ductterminalids))
        if ductid.ToString() in ELEMID_UEBER:
            continue
        auslass = Luftauslass(ductid)
        if not auslass.einbauort in DICT_LUFTAUSLASS.keys():
            DICT_LUFTAUSLASS[auslass.einbauort] = ObservableCollection[Luftauslass]()
        
        DICT_LUFTAUSLASS[auslass.einbauort].Add(auslass)
        if not auslass.vsr:continue
        if not auslass.vsr in DICT_MEP_AUSLASS.keys():
            DICT_MEP_AUSLASS[auslass.vsr] = [auslass.raumnr]
        else:
            if auslass.raumnr not in DICT_MEP_AUSLASS[auslass.vsr]:
                DICT_MEP_AUSLASS[auslass.vsr].append(auslass.raumnr)

        if not auslass.einbauort in DICT_EINBAUTEILE.keys():
            DICT_EINBAUTEILE[auslass.einbauort] = [auslass.vsr]
        else:
            if auslass.vsr not in DICT_EINBAUTEILE[auslass.einbauort]:
                DICT_EINBAUTEILE[auslass.einbauort].append(auslass.vsr)

        if not auslass.vsr in DICT_VSR_AUSLASS.keys():
            DICT_VSR_AUSLASS[auslass.vsr] = ObservableCollection[Luftauslass]()
        DICT_VSR_AUSLASS[auslass.vsr].Add(auslass)

liste_temp = DICT_VSR_AUSLASS.keys()[:]
with forms.ProgressBar(title = "{value}/{max_value} Volumenstromregler",cancellable=True, step=10) as pb:
    for n, vsrid in enumerate(liste_temp):
        if pb.cancelled:
            script.exit()

        pb.update_progress(n + 1, len(liste_temp))
        vsr = VSR(vsrid)
        vsr.Auslass = DICT_VSR_AUSLASS[vsrid]
        vsr.liste_Raum = DICT_MEP_AUSLASS[vsrid]
        vsr.get_Art()
        DICT_VSR[vsrid] = vsr


# MEP Räume aus aktueller Ansicht
spaces_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MEPSpaces).WhereElementIsNotElementType()
spaces = spaces_collector.ToElementIds()
spaces_collector.Dispose()

berechnung_nach_0 = {
    '1': "Fläche",
    '2': "Luftwechsel",
    '3': "Person",
    '4': "manuell",
    '5': "nurZUMa",
    '6': "nurABMa",
    '5.1': "nurZU_Fläche",
    '5.2': "nurZU_Luftwechsel",
    '5.3': "nurZU_Person",
    '6.1': "nurAB_Fläche",
    '6.2': "nurAB_Luftwechsel",
    '6.3': "nurAB_Person",
    '9': "keine",
}

class MEPRaum(object):
    def __init__(self, elem_id,list_auslass,list_vsr,list_ueber):
        self.elem_id = elem_id
        self.elem = doc.GetElement(self.elem_id)
        self.Raumnr = self.elem.Number
        self.list_auslass = list_auslass
        self.list_vsr = list_vsr
        self.list_ueber = list_ueber
        self.raumname = self.elem.LookupParameter('Name').AsString()
        try:
            self.ebene = self.elem.LookupParameter('Ebene').AsValueString()
        except:
            self.ebene = ''
        # try:
        #     self.bezugsname = self.elem.LookupParameter('TGA_RLT_VolumenstromProName').AsValueString()
        # except:
        #     self.bezugsname = ''
        self.bezugsnummer = self.elem.LookupParameter('TGA_RLT_VolumenstromProNummer').AsValueString()
        self.bezugsnummer = self.elem.LookupParameter('TGA_RLT_VolumenstromProNummer').AsValueString()
        try:
            self.bezugsname = berechnung_nach_0[self.bezugsnummer]
        except:
            self.bezugsname = 'keine'
        self.flaeche = round(self.get_element('Fläche'),1)
        self.volumen = round(self.get_element('Volumen'),1)
        self.personen = round(self.get_element('Personenzahl'),1)
        self.faktor = self.get_element('TGA_RLT_VolumenstromProFaktor')
        self.einheit = self.get_element('TGA_RLT_VolumenstromProEinheit')
        self.hoehe = int(self.get_element('Lichte Höhe'))
        
        self.ab_24h = self.get_element('IGF_RLT_AbluftSumme24h')
        self.zu_min = self.get_element('IGF_RLT_ZuluftminRaum')
        self.zu_max = self.get_element('IGF_RLT_ZuluftmaxRaum')
        self.ab_min = self.get_element('IGF_RLT_AbluftminRaum')
        self.ab_max = self.get_element('IGF_RLT_AbluftmaxRaum')
        self.ab_lab_min = self.get_element('IGF_RLT_AbluftminSummeLabor24h')
        self.ab_lab_max = self.get_element('IGF_RLT_AbluftmaxSummeLabor24h')
        self.ueber_sum = self.get_element('IGF_RLT_ÜberströmungRaum')
        self.ueber_in = self.get_element('IGF_RLT_ÜberströmungSummeIn')
        self.ueber_aus = self.get_element('IGF_RLT_ÜberströmungSummeAus')
        self.nb_von = self.get_element('IGF_RLT_NachtbetriebVon')
        self.nb_bis = self.get_element('IGF_RLT_NachtbetriebBis')
        self.nb_dauer = self.get_element('IGF_RLT_NachtbetriebDauer')
        self.nb_zu = self.get_element('IGF_RLT_ZuluftNachtRaum')
        self.nb_ab = self.get_element('IGF_RLT_AbluftNachtRaum')
        self.tnb_von = self.get_element('IGF_RLT_TieferNachtbetriebVon')
        self.tnb_bis = self.get_element('IGF_RLT_TieferNachtbetriebBis')
        self.tnb_dauer = self.get_element('IGF_RLT_TieferNachtbetriebDauer')
        self.tnb_zu = self.get_element('IGF_RLT_ZuluftTieferNachtRaum')
        self.tnb_ab = self.get_element('IGF_RLT_AbluftTieferNachtRaum')
    
    def get_element(self, param_name):
        param = self.elem.LookupParameter(param_name)
        if not param:
            logger.error("Parameter {} konnte nicht gefunden werden".format(param_name))
            return ''
        return get_value(param)
    

mepraum_liste = {}
with forms.ProgressBar(title="{value}/{max_value} MEP-Räume",cancellable=True, step=10) as pb:
    for n,space_id in enumerate(spaces):
        if pb.cancelled:
            script.exit()
        pb.update_progress(n+1, len(spaces))
        if space_id.ToString() in DICT_UEBERSTROM.keys():
            list_ueber = DICT_UEBERSTROM[space_id.ToString()]
        else:
            list_ueber = {'Ein':ObservableCollection[Auslass](),'Aus':ObservableCollection[Auslass]()}

        if space_id.ToString() in DICT_EINBAUTEILE.keys():
            list_vsr = ObservableCollection[VSR]()
            for e in DICT_EINBAUTEILE[space_id.ToString()]:
                try:
                    list_vsr.Add(DICT_VSR[e])
                except Exception as e1:
                    logger.error(e1)
        else:
            list_vsr = ObservableCollection[VSR]()
        
        if space_id.ToString() in DICT_LUFTAUSLASS.keys():
            list_auslass = DICT_LUFTAUSLASS[space_id.ToString()]
        else:
            list_auslass = ObservableCollection[Luftauslass]()

        mepraum = MEPRaum(space_id,list_auslass,list_vsr,list_ueber)
        mepraum_liste[mepraum.Raumnr] = mepraum

auslass_liste = []
einbauteile_dict = {}

class MEPRaum_Uebersicht(forms.WPFWindow):
    def __init__(self, xaml_file_name):
 
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.Raumnr.ItemsSource = sorted(mepraum_liste.keys())
        self.raumnr = None
        self.mepraum = None
        self.temp_luftauslass = ObservableCollection[Luftauslass]()
        self.warnung.Visibility= Visibility.Hidden
        self.auswahl.Visibility= Visibility.Hidden
        self.raumwechsel_hinweis.Visibility= Visibility.Hidden
        self.Rauminfo.Visibility= Visibility.Hidden
        
    
    def set_up(self):
        self.raumname.Text = str(self.mepraum.raumname)
        self.ebene.Text = str(self.mepraum.ebene)
        self.bezugsname.Text = str(self.mepraum.bezugsname)
        self.faktor.Text = str(self.mepraum.faktor)
        self.einheit.Text = str(self.mepraum.einheit)
        self.flaeche.Text = str(self.mepraum.flaeche)
        self.volumen.Text = str(self.mepraum.volumen)
        self.personen.Text = str(self.mepraum.personen)
        self.hoehe.Text = str(self.mepraum.hoehe)
        self.ab_24h.Text = str(self.mepraum.ab_24h)
        self.zu_min.Text = str(self.mepraum.zu_min)
        self.zu_max.Text = str(self.mepraum.zu_max)
        self.ab_min.Text = str(self.mepraum.ab_min)
        self.ab_max.Text = str(self.mepraum.ab_max)
        self.ab_lab_max.Text = str(self.mepraum.ab_lab_max)
        self.ab_lab_min.Text = str(self.mepraum.ab_lab_min)
        self.ueber_sum.Text = str(self.mepraum.ueber_sum)
        self.ueber_in.Text = str(self.mepraum.ueber_in)
        self.ueber_aus.Text = str(self.mepraum.ueber_aus)

        self.nb_von.Text = str(self.mepraum.nb_von)
        self.nb_bis.Text = str(self.mepraum.nb_bis)
        self.nb_dauer.Text = str(self.mepraum.nb_dauer)
        self.nb_zu.Text = str(self.mepraum.nb_zu)
        self.nb_ab.Text = str(self.mepraum.nb_ab)

        self.tnb_von.Text = str(self.mepraum.tnb_von)
        self.tnb_bis.Text = str(self.mepraum.tnb_bis)
        self.tnb_dauer.Text = str(self.mepraum.tnb_dauer)
        self.tnb_zu.Text = str(self.mepraum.tnb_zu)
        self.tnb_ab.Text = str(self.mepraum.tnb_ab)

        self.lv_vsr.ItemsSource = self.mepraum.list_vsr
        self.lv_auslass.ItemsSource = self.mepraum.list_auslass
        
        self.lv_ueber_aus.ItemsSource = self.mepraum.list_ueber['Aus']
        self.lv_ueber_in.ItemsSource = self.mepraum.list_ueber['Ein']

    def nummer_changed(self, sender, args):
        text = str(self.Raumnr.SelectedItem)
        self.temp_luftauslass.Clear()
        try:
            self.mepraum = mepraum_liste[text]
            self.warnung.Visibility= Visibility.Hidden
            self.auswahl.Visibility= Visibility.Hidden
            for el in self.lv_vsr.Items:
                el.checked = False
            self.set_up()
        except Exception as e:
            print(e)
    
    def nummer_changed_vsr(self, sender, args):
        text = str(self.auswahl.SelectedItem)
        text_original = str(self.Raumnr.SelectedItem)
        if text != text_original:
            self.Rauminfo.Visibility = Visibility.Visible
            self.Rauminfo.Text = "Die angezeigte Rauminfomationen beziehen sich auf Raum => " + text
        else:
            self.Rauminfo.Visibility = Visibility.Hidden        
        try:
            temp = None
            for el in self.lv_vsr.Items:
                if el.checked:
                    
                    temp = el
                    break
            self.mepraum = mepraum_liste[text]
            self.set_up()
            # for el in self.lv_vsr.Items:
            #     if el.elem_id.ToString() == temp.elem_id.ToString():
            #         el.checked = True
            #         break
            # self.lv_vsr.Items.Refresh()
            self.temp_luftauslass.Clear()
            for el in temp.Auslass:
                if el.einbauort == self.mepraum.elem_id.ToString():
                    self.temp_luftauslass.Add(el)
            self.lv_auslass.ItemsSource = self.temp_luftauslass

        except Exception as e:
            print(e)

    def checked_changed(self, sender, args):
        Checked = sender.IsChecked
        item = sender.DataContext
        self.temp_luftauslass.Clear()
        if Checked:
            for el in self.lv_vsr.Items:
                el.checked = False
            item.checked = True

            self.lv_vsr.Items.Refresh()

            for el in item.Auslass:
                if el.einbauort == self.mepraum.elem_id.ToString():
                    self.temp_luftauslass.Add(el)
            self.lv_auslass.ItemsSource = self.temp_luftauslass

            if len(item.liste_Raum) > 1:
                self.raumwechsel_hinweis.Visibility= Visibility.Visible
                self.warnung.Visibility= Visibility.Visible
                self.auswahl.Visibility= Visibility.Visible
                self.auswahl.ItemsSource = item.liste_Raum
            else:
                self.raumwechsel_hinweis.Visibility= Visibility.Hidden
                self.warnung.Visibility= Visibility.Hidden
                self.auswahl.Visibility= Visibility.Hidden

        else:
            self.raumwechsel_hinweis.Visibility= Visibility.Hidden
            self.warnung.Visibility= Visibility.Hidden
            self.auswahl.Visibility= Visibility.Hidden
            self.lv_auslass.ItemsSource = self.mepraum.list_auslass
            



ScheduleWPF = MEPRaum_Uebersicht("MEP.xaml")
ScheduleWPF.ShowDialog()
# try:
#     ScheduleWPF.ShowDialog()
# except Exception as e:
#     logger.error(e)
#     ScheduleWPF.Close()
#     script.exit()
