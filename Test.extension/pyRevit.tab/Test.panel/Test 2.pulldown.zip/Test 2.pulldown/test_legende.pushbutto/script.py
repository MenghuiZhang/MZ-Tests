# coding: utf8
from pyrevit import revit,script,DB

import time

start = time.time()

__title__ = "legend"
__doc__ = """"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc

legendcom = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_LegendComponents).WhereElementIsNotElementType()
legendcomids = legendcom.ToElementIds()
legendcom.Dispose()


if not legendcomids:
    logger.error("Keine Legendenkomponenten gefunden")
    script.exit()

legend = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Views).WhereElementIsNotElementType()
for el in legend:
    if el.ViewType.ToString() 
legendids = legendcom.ToElementIds()
legend.Dispose()


if not legendcomids:
    logger.error("Keine Legendenkomponenten gefunden")
    script.exit()
