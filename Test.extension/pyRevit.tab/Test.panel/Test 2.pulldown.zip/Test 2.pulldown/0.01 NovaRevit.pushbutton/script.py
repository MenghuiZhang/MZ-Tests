# coding: utf8
from pyrevit import revit, UI, DB, script, forms
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
from System.Windows.Forms import *
from System.Windows.Controls import *
import clr
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel

from pyrevit.forms import WPFWindow
import time

start = time.time()

__title__ = "0.1 Revit_Nova_Verknüpfung"
__doc__ = """Revit_Nova_Verknüpfung"""
__author__ = "Menghui Zhang"

from pyIGF_logInfo import getlog
getlog(__title__)

logger = script.get_logger()
output = script.get_output()
Nova_config = script.get_config()
ex = Excel.ApplicationClass()

uidoc = revit.uidoc
doc = revit.doc

system_luft = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
system_rohr = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
system_elek = FilteredElementCollector(doc).OfClass(clr.GetClrType(Electrical.ElectricalSystem)).WhereElementIsNotElementType()
system_luft_dict = {}
system_rohr_dict = {}
system_elek_dict = {}

def coll2dict(coll,dict):
    for el in coll:
        name = el.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM).AsString()
        type = el.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
        if type in dict.Keys:
            dict[type].append(el.Id)
        else:
            dict[type] = [el.Id]
coll2dict(system_luft,system_luft_dict)
coll2dict(system_rohr,system_rohr_dict)
coll2dict(system_elek,system_elek_dict)
system_luft.Dispose()
system_rohr.Dispose()
system_elek.Dispose()

class System(object):
    def __init__(self):
        self.checked = False
        self.SystemName = ''
        self.TypName = ''

    @property
    def TypName(self):
        return self._TypName
    @TypName.setter
    def TypName(self, value):
        self._TypName = value
    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def ElementId(self):
        return self._ElementId
    @ElementId.setter
    def ElementId(self, value):
        self._ElementId = value

Liste_Luft = ObservableCollection[System]()
Liste_Rohr = ObservableCollection[System]()
Liste_Elektro = ObservableCollection[System]()
Liste_Alle = ObservableCollection[System]()

for key in system_luft_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_luft_dict[key]
    Liste_Luft.Add(temp_system)
    Liste_Alle.Add(temp_system)

for key in system_rohr_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_rohr_dict[key]
    Liste_Rohr.Add(temp_system)
    Liste_Alle.Add(temp_system)

for key in system_elek_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_elek_dict[key]
    Liste_Elektro.Add(temp_system)
    Liste_Alle.Add(temp_system)



# GUI Systemauswahl
class Systemauswahl(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_Elektro,liste_All):
        self.liste_Luft = liste_Luft
        self.liste_Rohr = liste_Rohr
        self.liste_Elektro = liste_Elektro
        self.liste_All = liste_All
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[System]()
        self.altdatagrid = None
        self.read_config()

        try:
            self.dataGrid.ItemsSource = self.liste_All
            self.altdatagrid = self.liste_All
            self.backAll()
            self.click(self.all)
        except Exception as e:
            logger.error(e)

        self.SucheSystemtyp.TextChanged += self.search_txt_changed
    
    def read_config(self):
        try:
            self.Adresse.Text = str(Nova_config.nova)
        except:
            self.Adresse.Text = Nova_config.nova = ""

    def write_config(self):
        Nova_config.nova = self.Adresse.Text.encode('utf-8')
        script.save_config()

    def durchsuchen(self,sender,args):
        dialog = OpenFileDialog()
        dialog.Multiselect = False
        dialog.Title = "Nova-Datei suchen"
        dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
        if dialog.ShowDialog() == DialogResult.OK:
            self.Adresse.Text = dialog.FileName

        self.write_config()

# Button Farbe ändern
    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic

# Button Farbe zurücksetzen
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.SucheSystemtyp.Text
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.TypName.find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()
    

    def backAll(self):
        def back(button):
            button.Background  = Brushes.White
            button.FontWeight = FontWeights.Normal
            button.FontStyle = FontStyles.Normal
        self.back(self.all)
        self.back(self.luft)
        self.back(self.rohr)
        self.back(self.elek)

    def lueftung(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Items.Refresh()

    def rohre(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Items.Refresh()

    def elektro(self,sender,args):
        self.backAll()
        self.click(self.elek)
        self.dataGrid.ItemsSource = self.liste_Elektro
        self.altdatagrid = self.liste_Elektro
        self.dataGrid.Items.Refresh()

    def alle(self,sender,args):
        self.backAll()
        self.click(self.all)
        self.dataGrid.ItemsSource = self.liste_All
        self.altdatagrid = self.liste_All
        self.dataGrid.Items.Refresh()

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()

    def auswahl(self,sender,args):
        self.backAll()
        self.Close()

Systemwindows = Systemauswahl("System.xaml",Liste_Luft,Liste_Rohr,Liste_Elektro,Liste_Alle)
Systemwindows.ShowDialog()

Adresse = Nova_config.nova

def EXCEL_Nova(filepath):
    _nova_Nr_Id = {}
    book = ex.Workbooks.Open(filepath)
    sheet = book.Worksheets['Eingang Nova']
    rows = sheet.UsedRange.Rows.Count
    for row in range(2, rows + 1):
        TsNr = sheet.Cells[row, 1].Value2
        TsId = sheet.Cells[row, 3].Value2
        if TsNr:
            if not TsNr in _nova_Nr_Id.Keys:
                _nova_Nr_Id[TsNr] = TsId 
    book.Save()
    book.Close()
    return _nova_Nr_Id

nova_Nr_Id = {}
try:
    nova_Nr_Id = EXCEL_Nova(Adresse)
except Exception as e:
    logger.error(e)
    
SystemListe = {}
for el in Liste_Alle:
    if el.checked == True:
        for it in el.ElementId:
            elem = doc.GetElement(it)
            sysname = elem.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM).AsString()
            systype = elem.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
            cate = elem.Category.Name
            if not cate in SystemListe.Keys:
                SystemListe[cate] = {}
            if not systype in SystemListe[cate].Keys:
                SystemListe[cate][systype] = [elem]
            else:
                SystemListe[cate][systype].append(elem)


class Teilstrecke(object):
    def __init__(self):
        self.checked = False
        self.System = ''
        self.RTSID = ''
        self.RTSNR = ''
        self.NTSNR = ''
        self.selected = False

    @property
    def System(self):
        return self._System
    @System.setter
    def System(self, value):
        self._System = value
    @property
    def RTSID(self):
        return self._RTSID
    @RTSID.setter
    def RTSID(self, value):
        self._RTSID = value
    @property
    def NTSID(self):
        return self._NTSID
    @NTSID.setter
    def NTSID(self, value):
        self._NTSID = value
    @property
    def RTSNR(self):
        return self._RTSNR
    @RTSNR.setter
    def RTSNR(self, value):
        self._RTSNR = value
    @property
    def NTSNR(self):
        return self._NTSNR
    @NTSNR.setter
    def NTSNR(self, value):
        self._NTSNR = value
    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def selected(self):
        return self._selected
    @selected.setter
    def selected(self, value):
        self._selected = value

Liste_Luft_TS = ObservableCollection[Teilstrecke]()
Liste_Rohr_TS = ObservableCollection[Teilstrecke]()
Liste_Elektro_TS = ObservableCollection[Teilstrecke]()
Liste_Alle_TS = ObservableCollection[Teilstrecke]()

elem_ts_dict = {}

for System_Cate in SystemListe.Keys:
    if System_Cate == 'Luftkanal Systeme':
        for systyp in SystemListe[System_Cate]:
            TS_liste = []
            sysliste = SystemListe[System_Cate][systyp]
            if not systyp in elem_ts_dict.Keys:
                elem_ts_dict[systyp]= {}
            for sys_ele in sysliste:
                elements = sys_ele.DuctNetwork
                for elem in elements:
                    cate = elem.Category.Name
                    if cate in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                        continue
                    R_TS_ID = elem.LookupParameter('IGF_X_RVT_TS_ID').AsString()
                    N_TS_ID = elem.LookupParameter('IGF_X_Nova_TS_ID').AsString()
                    R_TS_NR = elem.LookupParameter('IGF_X_RVT_TS_Nr').AsString()
                    N_TS_NR = elem.LookupParameter('IGF_X_Nova_TS_Nr').AsString()
                    Ver = elem.LookupParameter('IGF_X_Nova_RVT_Verknüpft').AsInteger()
                    if not R_TS_ID in elem_ts_dict[systyp].Keys:
                        elem_ts_dict[systyp][R_TS_ID] = [int(elem.Id.ToString())]
                    else:
                        elem_ts_dict[systyp][R_TS_ID].append(int(elem.Id.ToString()))

                    if not R_TS_ID in TS_liste:
                        TS_liste.append(R_TS_ID)
                        temp_TS = Teilstrecke()
                        temp_TS.System = systyp
                        temp_TS.RTSID = R_TS_ID
                        temp_TS.NTSID = N_TS_ID
                        temp_TS.RTSNR = R_TS_NR
                        temp_TS.NTSNR = N_TS_NR
                        if Ver != 0:
                            temp_TS.checked = True
                        Liste_Luft_TS.Add(temp_TS)
                        Liste_Alle_TS.Add(temp_TS)
                    
    elif System_Cate == 'Rohr Systeme':
        for systyp in SystemListe[System_Cate]:
            TS_liste = []
            sysliste = SystemListe[System_Cate][systyp]
            if not systyp in elem_ts_dict.Keys:
                elem_ts_dict[systyp]= {}
            for sys_ele in sysliste:
                elements = sys_ele.PipingNetwork
                for elem in elements:
                    cate = elem.Category.Name
                    if cate in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                        continue
                    R_TS_ID = elem.LookupParameter('IGF_X_RVT_TS_ID').AsString()
                    N_TS_ID = elem.LookupParameter('IGF_X_Nova_TS_ID').AsString()
                    R_TS_NR = elem.LookupParameter('IGF_X_RVT_TS_Nr').AsString()
                    N_TS_NR = elem.LookupParameter('IGF_X_Nova_TS_Nr').AsString()
                    Ver = elem.LookupParameter('IGF_X_Nova_RVT_Verknüpft').AsInteger()
                    if not R_TS_ID in elem_ts_dict[systyp].Keys:
                        elem_ts_dict[systyp][R_TS_ID] = [int(elem.Id.ToString())]
                    else:
                        elem_ts_dict[systyp][R_TS_ID].append(int(elem.Id.ToString()))
                    
                    if not R_TS_ID in TS_liste:
                        TS_liste.append(R_TS_ID)
                        temp_TS = Teilstrecke()
                        temp_TS.System = systyp
                        temp_TS.RTSID = R_TS_ID
                        temp_TS.NTSID = N_TS_ID
                        temp_TS.RTSNR = R_TS_NR
                        temp_TS.NTSNR = N_TS_NR
                        if Ver != 0:
                            temp_TS.checked = True
                        Liste_Rohr_TS.Add(temp_TS)
                        Liste_Alle_TS.Add(temp_TS)

# GUI Systemauswahl
class TSNovaRVT(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_Elektro,liste_All,elem_dict,dict_nova):
        self.liste_Luft = liste_Luft
        self.liste_Rohr = liste_Rohr
        self.liste_Elektro = liste_Elektro
        self.liste_All = liste_All
        self.elem_dict = elem_dict
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[System]()
        self.altdatagrid = None
        self.read_config()
        self.prevalue = None
        self.newvalue = None
        self.Tempsource = None
        self.nova_dict = dict_nova

        try:
            self.dataGrid.ItemsSource = self.liste_All
            self.altdatagrid = self.liste_All
            self.backAll()
            self.click(self.all)
        except Exception as e:
            logger.error(e)

        self.SucheSystemtyp.TextChanged += self.search_txt_changed
        self.Adresse.TextChanged += self.novaexcel_changed
        
    
    def dataGrid_BeginningEdit(self,sender,args):
        if args.Column.DisplayIndex == 4:
            self.prevalue = args.Column.GetCellContent(args.Row).Text


    def dataGrid_CellEditEnding(self,sender,args):
        if args.Column.DisplayIndex == 4:
            self.newvalue = args.EditingElement.Text
            if self.newvalue != self.prevalue:
                args.Row.Item.selected = True
                args.Row.Item.checked = True
        
        self.Tempsource = self.dataGrid.ItemsSource
        self.dataGrid.ItemsSource = None
        self.dataGrid.ItemsSource = self.Tempsource
        

    def read_config(self):
        try:
            self.Adresse.Text = str(Nova_config.nova)
        except:
            self.Adresse.Text = Nova_config.nova = ""

    def write_config(self):
        Nova_config.nova = self.Adresse.Text.encode('utf-8')
        script.save_config()

# Button Farbe ändern
    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic

# Button Farbe zurücksetzen
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal
    
    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.selected = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.selected = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.selected
            item.selected = not value
        self.dataGrid.Items.Refresh()

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.SucheSystemtyp.Text
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.System.find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()
    
    def novaexcel_changed(self, sender, args):
        """Handle text change in search box."""
        adresse = self.Adresse.Text
        try:
            self.nova_dict = EXCEL_Nova(adresse)
        except:
            logger.error("Fehler mit Excel")
        print(self.nova_dict)
    

    def durchsuchen(self,sender,args):
        dialog = OpenFileDialog()
        dialog.Multiselect = False
        dialog.Title = "Nova-Datei suchen"
        dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
        if dialog.ShowDialog() == DialogResult.OK:
            self.Adresse.Text = dialog.FileName

        self.write_config()

    def backAll(self):
        def back(button):
            button.Background  = Brushes.White
            button.FontWeight = FontWeights.Normal
            button.FontStyle = FontStyles.Normal
        self.back(self.all)
        self.back(self.luft)
        self.back(self.rohr)
        self.back(self.elek)

    def lueftung(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Items.Refresh()

    def rohre(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Items.Refresh()

    def elektro(self,sender,args):
        self.backAll()
        self.click(self.elek)
        self.dataGrid.ItemsSource = self.liste_Elektro
        self.altdatagrid = self.liste_Elektro
        self.dataGrid.Items.Refresh()

    def alle(self,sender,args):
        self.backAll()
        self.click(self.all)
        self.dataGrid.ItemsSource = self.liste_All
        self.altdatagrid = self.liste_All
        self.dataGrid.Items.Refresh()

    def ok(self,sender,args):
        t = Transaction(doc,'Nova Ts_Nr./ID schreiben')
        t.Start()
        for item in self.dataGrid.Items:
            if item.selected:
                system = item.System
                R_TsId = item.RTSID
                N_TsNr = item.NTSNR
                N_TsId = item.NTSID
                ver = 0
                if item.checked:
                    ver = 1
                elements = self.elem_dict[system][R_TsId]
                for elemid in elements:
                    elem = doc.GetElement(DB.ElementId(elemid))
                    elem.LookupParameter('IGF_X_Nova_TS_Nr').Set(str(N_TsNr))
                    elem.LookupParameter('IGF_X_Nova_TS_ID').Set(str(N_TsId))
                    elem.LookupParameter('IGF_X_Nova_RVT_Verknüpft').Set(int(ver))
        doc.Regenerate()
        t.Commit()
        self.Close()

    def aktua(self,sender,args):
        t = Transaction(doc,'Nova Ts_Nr./ID schreiben')
        t.Start()
        for item in self.dataGrid.Items:
            if item.selected:
                system = item.System
                R_TsId = item.RTSID
                N_TsNr = item.NTSNR
                N_TsId = item.NTSID
                ver = 0
                if item.checked:
                    ver = 1
                elements = self.elem_dict[system][R_TsId]
                for elemid in elements:
                    elem = doc.GetElement(ElementId(elemid))
                    elem.LookupParameter('IGF_X_Nova_TS_Nr').Set(str(N_TsNr))
                    elem.LookupParameter('IGF_X_Nova_TS_ID').Set(str(N_TsId))
                    elem.LookupParameter('IGF_X_Nova_RVT_Verknüpft').Set(int(ver))
                item.selected = False
        t.Commit()
        self.dataGrid.Items.Refresh()

    def close(self,sender,args):
        self.Close()
        
TSwindows = TSNovaRVT("N2R.xaml",Liste_Luft_TS,Liste_Rohr_TS,Liste_Elektro_TS,Liste_Alle_TS,elem_ts_dict,nova_Nr_Id)
TSwindows.ShowDialog()