# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
from pyIGF_lib import AddProjParamfromShared,get_value, set_value


start = time.time()


__title__ = "Luftkanalformteillänge"
__doc__ = """...."""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

LF = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctFitting) \
    .WhereElementIsNotElementType()


def DatenSchreiben(coll,Cate):
    trandoc = 'Länge Schreiben_'+Cate
    ids = coll.ToElementIds()
    t = Transaction(doc,trandoc)
    t.Start()

    with forms.ProgressBar(title='{value}/{max_value} Bauteile in Kategorie ' + Cate,
                           cancellable=True, step=10) as pb:
        for n, id in enumerate(ids):
            if pb.cancelled:
                script.exit()
            pb.update_progress(n, len(ids))
            el = doc.GetElement(id)
            try:
                cax0 = el.LookupParameter('CAx ab 2001').AsDouble()
                cax1 = el.LookupParameter('CAx 1501 bis 2000').AsDouble()
                cax2 = el.LookupParameter('CAx 1001 bis 1500').AsDouble()
                cax3 = el.LookupParameter('CAx 501 bis 1000').AsDouble()
                cax4 = el.LookupParameter('CAx bis 500').AsDouble()
                if cax0 > 0.01:
                    el.LookupParameter('IGF_RLT_Formteilelänge')\
                    .Set(round(cax0*0.3048*0.3048*100,1))
                if cax1 > 0.01:
                    el.LookupParameter('IGF_RLT_Formteilelänge')\
                    .Set(round(cax1*0.3048*0.3048*100,1))
                if cax2 > 0.01:
                    el.LookupParameter('IGF_RLT_Formteilelänge')\
                    .Set(round(cax2*0.3048*0.3048*100,1))
                if cax3 > 0.01:
                    el.LookupParameter('IGF_RLT_Formteilelänge')\
                    .Set(round(cax3*0.3048*0.3048*100,1))
                if cax4 > 0.01:
                    el.LookupParameter('IGF_RLT_Formteilelänge')\
                    .Set(round(cax4*0.3048*0.3048*100,1))
            except:
                pass

    t.Commit()

DatenSchreiben(LF,'Luftkanalformteile')
