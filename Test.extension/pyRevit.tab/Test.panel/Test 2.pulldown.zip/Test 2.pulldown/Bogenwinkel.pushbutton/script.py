# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
from pyIGF_lib import AddProjParamfromShared,get_value, set_value


start = time.time()


__title__ = "Bogenwinkel"
__doc__ = """...."""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

LF = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctFitting) \
    .WhereElementIsNotElementType()


def DatenSchreiben(coll,Cate):
    trandoc = 'Winkel Schreiben_'+Cate
    ids = coll.ToElementIds()
    t = Transaction(doc,trandoc)
    t.Start()

    with forms.ProgressBar(title='{value}/{max_value} Bauteile in Kategorie ' + Cate,
                           cancellable=True, step=10) as pb:
        for n, id in enumerate(ids):
            if pb.cancelled:
                script.exit()
            pb.update_progress(n, len(ids))
            el = doc.GetElement(id)
            try:
                a = el.LookupParameter('alpha').AsValueString()
                el.LookupParameter('IGF_RLT_Formteilealpha').SetValueString(a)
            except:
                pass

    t.Commit()

DatenSchreiben(LF,'Luftkanalformteile')
