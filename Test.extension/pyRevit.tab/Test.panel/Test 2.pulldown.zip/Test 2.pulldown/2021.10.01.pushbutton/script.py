# coding: utf8
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from rpw import revit,DB
from pyrevit import script, forms
from IGF_log import getlog
from IGF_lib import get_value
import time

start = time.time()


__title__ = "3.2 Raumluft_Summe"
__doc__ = """Anlagenberechnung

[01.10.2021]
Version: 1.2"""
__author__ = "Menghui Zhang"
try:
    getlog(__title__)
except:
    pass

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc

# MEP Räume aus aktueller Projekt
spaces_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MEPSpaces).WhereElementIsNotElementType()
spaces = spaces_collector.ToElementIds()

# Systemen aus Projekt
System_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
systemen = System_collector.ToElementIds()

logger.info("{} MEP Räume ausgewählt".format(len(spaces)))
logger.info("{} Luftkanalsystemen ausgewählt".format(len(systemen)))

if not (spaces and systemen):
    logger.error("Keine MEP Räume/Luftkanalsystemen in aktueller Projekt gefunden")
    script.exit()


class MEPRaum:
    def __init__(self, element_id):
        self.element_id = element_id
        self.element = doc.GetElement(self.element_id)
        attr = [
            ['name', 'Name'],
            ['nummer', 'Nummer'],
            ['Zu_Anl_Nr', 'TGA_RLT_AnlagenNrZuluft'],
            ['Ab_Anl_Nr', 'TGA_RLT_AnlagenNrAbluft'],
            ['Ab_Anl_Nr_24h', 'TGA_RLT_AnlagenNr24hAbluft'],
            ['ZU', 'IGF_RLT_AnlagenRaumZuluft'],
            ['AB', 'IGF_RLT_AnlagenRaumAbluft'],
            ['AB24H', 'IGF_RLT_AnlagenRaum24hAbluft'],
        ]

        for a in attr:
            python_name, revit_name = a
            setattr(self, python_name, self.get_element_attr(revit_name))

        logger.info(30 * "=")
        logger.info("{}\t{}".format(self.nummer, self.name))

        # Prüfung. Wenn es Luftmengen gibt aber kein Anlagennummer, dann falsch.

        if self.ZU > 0 and self.Zu_Anl_Nr is None:
            logger.error("Kein Zuluft_Anlage_Nummer in Raum{} gefunden".format(self.nummer))
           # self.Zu_Anl_Nr = 0

        if self.AB > 0 and self.Ab_Anl_Nr is None:
            logger.error("Kein Abluft_Anlage_Nummer in Raum{} gefunden".format(self.nummer))
           # self.Ab_Anl_Nr = 0

        if self.AB24H > 0 and self.Ab_Anl_Nr_24h is None:
            logger.error("Kein Abluft24h_Anlage_Nummer in Raum{} gefunden".format(self.nummer))
           # self.Ab_Anl_Nr_24h = 0


    def get_element_attr(self, param_name):
        param = self.element.LookupParameter(param_name)

        if not param:
            logger.error(
                "Parameter ({}) konnte nicht gefunden werden".format(param_name))
            return

        return get_value(param)

    def table_row(self):
        """ Gibt eine Datenreihe für den MEP Raum aus. Für die tabellarische Übersicht."""
        return [
            self.nummer,
            self.name,
            self.Zu_Anl_Nr,
            self.Ab_Anl_Nr,
            self.Ab_Anl_Nr_24h,
            self.ZU,
            self.AB,
            self.AB24H
        ]

table_data_MepRaum = []
mepraum_liste = []
Zuluft_Liste = {}

Abluft_Liste = {}
Abluft_24h_Liste = {}

with forms.ProgressBar(title='{value}/{max_value} MEP-Räume', cancellable=True, step=10) as pb:
    for n, space_id in enumerate(spaces):
        if pb.cancelled:
            script.exit()
        pb.update_progress(n + 1, len(spaces))
        mepraum = MEPRaum(space_id)
        mepraum_liste.append(mepraum)

        if not mepraum.Zu_Anl_Nr in Zuluft_Liste.keys():
            Zuluft_Liste[mepraum.Zu_Anl_Nr] = float(mepraum.ZU)
        else:
            Zuluft_Liste[mepraum.Zu_Anl_Nr] += float(mepraum.ZU)

        if not mepraum.Ab_Anl_Nr in Abluft_Liste.keys():
            Abluft_Liste[mepraum.Ab_Anl_Nr] = float(mepraum.AB)
        else:
            Abluft_Liste[mepraum.Ab_Anl_Nr] += float(mepraum.AB)

        if not mepraum.Ab_Anl_Nr_24h in Abluft_24h_Liste.keys():
            Abluft_24h_Liste[mepraum.Ab_Anl_Nr_24h] = float(mepraum.AB24H)
        else:
            Abluft_24h_Liste[mepraum.Ab_Anl_Nr_24h] += float(mepraum.AB24H)

        table_data_MepRaum.append(mepraum.table_row())
print(Zuluft_Liste)
# Sorteiren nach Raumnummer
table_data_MepRaum.sort()

output.print_table(
    table_data=table_data_MepRaum,
    title="MEP-Räume",
    columns=['Nummer', 'Name', 'Zu_Anl_Nr', 'Ab_Anl_Nr', 'Ab_Anl_Nr_24h', 'Zuluft','Abluft','24h Abluft']
)


class DuctSystem:
    def __init__(self, element_id):
        self.element_id = element_id
        self.element = doc.GetElement(self.element_id)

        attr = [
            ['name', 'Systemname'],
            ['Ger_Nr', 'TGA_RLT_AnlagenGeräteNr'],
            ['Ger_Anzahl', 'TGA_RLT_AnlagenGeräteAnzahl'],
            ['Anl_Nr', 'TGA_RLT_AnlagenNr'],
            ['Anl_Pro_Anz', 'TGA_RLT_AnlagenProzentualAnzahl'],
        ]

        for a in attr:
            python_name, revit_name = a
            setattr(self, python_name, self.get_element_attr(revit_name))

        if self.Ger_Anzahl == 0:
            self.Ger_Anzahl = 1
        if self.Anl_Pro_Anz == 0:
            self.Anl_Pro_Anz = 1

        self.Anl_Nr = str(int(self.Anl_Nr))


        self.zuluft = 0
        self.abluft = 0
        self.ab24h = 0
        self.zu_geraete = 0
        self.zu_geraete_p = 0
        self.ab_geraete = 0
        self.ab_geraete_p = 0
        self.ab_geraete24h = 0
        self.ab_geraete24h_p = 0
        
        if self.Anl_Nr in Zuluft_Liste.keys():
            self.zuluft = Zuluft_Liste[self.Anl_Nr]
            self.zu_geraete = round(self.zuluft / int(self.Ger_Anzahl),1)
            self.zu_geraete_p = round(self.zuluft / int(self.Anl_Pro_Anz),1)

        if self.Anl_Nr in Abluft_Liste.keys():
            self.abluft = Abluft_Liste[self.Anl_Nr]
            self.ab_geraete = round(self.abluft / int(self.Ger_Anzahl),1)
            self.ab_geraete_p = round(self.abluft / int(self.Anl_Pro_Anz),1)
            

        if self.Anl_Nr in Abluft_24h_Liste.keys():
            self.ab24h = Abluft_24h_Liste[self.Anl_Nr]
            self.ab_geraete24h = round(self.ab24h / int(self.Ger_Anzahl),1)
            self.ab_geraete24h_p = round(self.ab24h / int(self.Anl_Pro_Anz),1)


    def get_element_attr(self, param_name):
        param = self.element.LookupParameter(param_name)

        if not param:
            logger.error(
                "Parameter ({}) konnte nicht gefunden werden".format(param_name))
            return

        return get_value(param)

    def table_row(self):
        """ Gibt eine Datenreihe für den MEP Raum aus. Für die tabellarische Übersicht."""
        return [
            self.Anl_Nr,
            self.Ger_Nr,
            self.name,
            self.Ger_Anzahl,
            self.Anl_Pro_Anz,
            self.zu_geraete,
            self.zu_geraete_p,
            self.ab_geraete,
            self.ab_geraete_p,
            self.ab_geraete24h,
            self.ab_geraete24h_p
        ]

    def werte_schreiben(self):
        """Schreibt die berechneten Werte zurück in das Modell."""
        def wert_schreiben(param_name, wert):
            if not wert is None:
                param = self.element.LookupParameter(param_name)
                if param:
                    if param.StorageType.ToString() == 'Double':
                        param.SetValueString(str(wert))
                    else:
                        param.Set(wert)
        
        wert_schreiben("TGA_RLT_AnlagenZuMenge", self.zu_geraete)
        wert_schreiben("TGA_RLT_AnlagenProzentualZuMenge", self.zu_geraete_p)
        wert_schreiben("TGA_RLT_AnlagenAbMenge", self.ab_geraete)
        wert_schreiben("TGA_RLT_AnlagenProzentualAbMenge", self.ab_geraete_p)
        wert_schreiben("TGA_RLT_Anlagen24hAbMenge", self.ab_geraete24h)
        wert_schreiben("TGA_RLT_AnlagenProzentual24hAbMenge", self.ab_geraete24h_p)


table_data_System = []
Systemen_liste = []

with forms.ProgressBar(title='{value}/{max_value} Luftkanal Systeme',cancellable=True, step=10) as pb1:
    for n, System_id in enumerate(systemen):
        if pb1.cancelled:
            script.exit()

        pb1.update_progress(n + 1, len(systemen))
        ductsystem = DuctSystem(System_id)

        Systemen_liste.append(ductsystem)
        table_data_System.append(ductsystem.table_row())

# Sorteiren nach Anlagennummer und dann Gerätenummer
table_data_System.sort()


output.print_table(
    table_data=table_data_System,
    title="Luftkanal Systeme",
    columns=[ 'Anl. Nr','Ger. Nr', 'Systemname', 'Ger. Anzahl', 'Anl_Pro_Anz', 'Zuluft', 
    'Zuluft Prozentual', 'Abluft', 'Abluft Prozentual', '24h-Abluft', '24h-Abluft Prozentual' ]
)


# Werte zuückschreiben + Abfrage
if forms.alert('Berechnete Werte in Modell schreiben?', ok=False, yes=True, no=True):

    t = DB.Transaction(doc, "Werte schreiben")
    t.Start()

    with forms.ProgressBar(title='{value}/{max_value} Werte schreiben', cancellable=True, step=1) as pb2:
        for n, system in enumerate(Systemen_liste):
            if pb2.cancelled:
                t.rollBack()
                script.exit()

            pb2.update_progress(n+1, len(Systemen_liste))
            system.werte_schreiben()

    t.Commit()

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))