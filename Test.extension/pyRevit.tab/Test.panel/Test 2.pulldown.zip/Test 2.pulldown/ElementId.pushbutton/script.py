# coding: utf8

from pyrevit import revit, DB
from pyrevit import script, forms
import System

__title__ = "ElementID"
__doc__ = """ElementID in Parameter schreiben
Kategorien: nur für Model
Parameter: IGF_X_ElementId"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc

Categories = {}
for cat in doc.Settings.Categories:
    name = cat.Name
    if cat.CategoryType.ToString() == 'Model':
        Categories[name] = cat.Id

Liste1 = []
allcate = System.Enum.GetValues(DB.BuiltInCategory.OST_PointClouds.GetType())
for cat in allcate:
	try:
		name = doc.Settings.Categories.get_Item(cat).Name
		if name in Categories.keys():
			Liste1.append(name)
	except:
		pass

Liste = set(Liste1)
Liste1 = list(Liste)
Liste1.sort()

cate = forms.SelectFromList.show(Liste1, button_name='Select',multiselect=True,)
if not cate:
    script.exit()
    
if any(cate):
    t = DB.Transaction(doc,'ElementId schreiben')
    t.Start()
    for e in cate:
        try:
            coll = DB.FilteredElementCollector(doc).OfCategoryId(Categories[e]).WhereElementIsNotElementType()
            elementids = coll.ToElementIds()
            coll.Dispose()
            with forms.ProgressBar(title='{value}/{max_value} Bauteile in Kategorie ' + e,
                           cancellable=True, step=10) as pb:
                for n,elementid in enumerate(elementids):
                    if pb.cancelled:
                        t.RollBack()
                        script.exit()
                    pb.update_progress(n+1, len(elementids))
                    el = doc.GetElement(elementid)

                    elementid = elementid.ToString()
                    try:
                        el.LookupParameter('IGF_X_ElementId').Set(elementid)
                    except:
                        pass
        except Exception as e:
            t.RollBack()
            logger.error(e)

    t.Commit()