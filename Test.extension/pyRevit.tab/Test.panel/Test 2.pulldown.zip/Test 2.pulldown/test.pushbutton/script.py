# coding: utf8
from pyrevit import revit,script,DB

import time

start = time.time()

__title__ = "Rohrzubehör"
__doc__ = """"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc

coll = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_PipeAccessory).WhereElementIsNotElementType()
elemetliste = []
for el in coll:
    fam = el.get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_PARAM).AsValueString() 
    if fam == '_X_CAx Kugelhahn - Gewinde_IGF':

        try:
            conns = el.MEPModel.ConnectorManager.Connectors
            
            try:
                systemtyp = el.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsValueString()
            except:
                systemtyp = None
            if not systemtyp:
                fehler = 'Kein System, Familie: '+ fam + ', ELementID: ' + el.Id.ToString()
                logger.error(fehler)
                if not el.Id.ToString() in elemetliste:
                    elemetliste.append(el.Id.ToString())
                continue

            for conn in conns:
                refs = conn.AllRefs
                ro = False
                for ref in refs:
                    owner = ref.Owner
                    if owner.Category.Name in ['Rohre','Rohrformteile']:
                        ro = True
                        try:
                            sys = owner.LookupParameter('Systemtyp').AsValueString()
                            if sys != systemtyp:
                                fehler = 'unterschieder Systemtyp, Familie: '+ fam + '， ElementId: ' + el.Id.ToString()
                                logger.error(fehler)
                                if not el.Id.ToString() in elemetliste:
                                    elemetliste.append(el.Id.ToString())
                        except:
                            fehler = 'Kein System ' + owner.Id.ToString()
                            logger.error(fehler)
                            if not el.Id.ToString() in elemetliste:
                                elemetliste.append(el.Id.ToString())

                if not ro:
                    fehler = 'Nicht an die Rohre angeschlossen, Familie: '+ fam + '， ElementId: ' + el.Id.ToString()
                    logger.error(fehler)
                    if not el.Id.ToString() in elemetliste:
                        elemetliste.append(el.Id.ToString())
        except:
            fehler = 'Kein Connectors, Familie: '+ fam + ', ELementID: ' + el.Id.ToString()
            logger.error(fehler)

print(elemetliste)
