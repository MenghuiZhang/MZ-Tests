# coding: utf8
from pyrevit import revit, UI, DB, script, forms
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
import clr
from pyrevit.forms import WPFWindow
import time

start = time.time()

__title__ = "System Prüfen"
__doc__ = """System Prüfen"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc

HLS_coll = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType()

HLS_dict = {}

for elem in HLS_coll:
    conns = None
    try:
        conns = elem.MEPModel.ConnectorManager.Connectors
    except:
        try:
            conns = elem.ConnectorManager.Connectors
        except:
            conns = None
    if conns:
        for conn in conns:
            if conn.IsConnected:
                if conn.Direction == FlowDirectionType.Out:
                    connectorSet = conn.AllRefs.ForwardIterator()
                    while connectorSet.MoveNext():
                        currentConnector = connectorSet.Current
                        if currentConnector:
                            eleme = currentConnector.Owner
                            try:
                                systemid = eleme.MEPSystem.Id.ToString()
                                if not systemid in HLS_dict.Keys:
                                    HLS_dict[systemid] = eleme
                            except:
                                pass


system_luft_dict = {}
system_rohr_dict = {}
system_elek_dict = {}

def coll2dict(coll,dict):
    for el in coll:
        name = el.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM).AsString()
        type = el.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
        if type in dict.Keys:
            dict[type].append(el.Id)
        else:
            dict[type] = [el.Id]
coll2dict(system_luft,system_luft_dict)
coll2dict(system_rohr,system_rohr_dict)
coll2dict(system_elek,system_elek_dict)

class System(object):
    def __init__(self):
        self.checked = False
        self.SystemName = ''
        self.TypName = ''

    @property
    def TypName(self):
        return self._TypName
    @TypName.setter
    def TypName(self, value):
        self._TypName = value
    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def ElementId(self):
        return self._ElementId
    @ElementId.setter
    def ElementId(self, value):
        self._ElementId = value

Liste_Luft = ObservableCollection[System]()
Liste_Rohr = ObservableCollection[System]()
Liste_Elektro = ObservableCollection[System]()
Liste_Alle = ObservableCollection[System]()

for key in system_luft_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_luft_dict[key]
    Liste_Luft.Add(temp_system)
    Liste_Alle.Add(temp_system)

for key in system_rohr_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_rohr_dict[key]
    Liste_Rohr.Add(temp_system)
    Liste_Alle.Add(temp_system)

for key in system_elek_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_elek_dict[key]
    Liste_Elektro.Add(temp_system)
    Liste_Alle.Add(temp_system)

system_luft.Dispose()
system_rohr.Dispose()
system_elek.Dispose()

class Systemauswahl(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_Elektro,liste_All):
        self.liste_Luft = liste_Luft
        self.liste_Rohr = liste_Rohr
        self.liste_Elektro = liste_Elektro
        self.liste_All = liste_All
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[System]()
        self.altdatagrid = None

        try:
            self.dataGrid.ItemsSource = self.liste_All
            self.altdatagrid = self.liste_All
            self.backAll()
            self.click(self.all)
        except Exception as e:
            logger.error(e)

        self.SucheSystemtyp.TextChanged += self.search_txt_changed

# Button Farbe ändern
    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic

# Button Farbe zurücksetzen
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.SucheSystemtyp.Text
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.TypName.find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()

    def backAll(self):
        def back(button):
            button.Background  = Brushes.White
            button.FontWeight = FontWeights.Normal
            button.FontStyle = FontStyles.Normal
        self.back(self.all)
        self.back(self.luft)
        self.back(self.rohr)
        self.back(self.elek)

    def lueftung(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Items.Refresh()

    def rohre(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Items.Refresh()

    def elektro(self,sender,args):
        self.backAll()
        self.click(self.elek)
        self.dataGrid.ItemsSource = self.liste_Elektro
        self.altdatagrid = self.liste_Elektro
        self.dataGrid.Items.Refresh()

    def alle(self,sender,args):
        self.backAll()
        self.click(self.all)
        self.dataGrid.ItemsSource = self.liste_All
        self.altdatagrid = self.liste_All
        self.dataGrid.Items.Refresh()

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()

    def auswahl(self,sender,args):
        self.backAll()
        self.Close()

Systemwindows = Systemauswahl("System.xaml",Liste_Luft,Liste_Rohr,Liste_Elektro,Liste_Alle)
Systemwindows.ShowDialog()

SystemListe = {}
for el in Liste_Alle:
    if el.checked == True:
        for it in el.ElementId:
            elem = doc.GetElement(it)
            sysname = elem.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM).AsString()
            systype = elem.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
            cate = elem.Category.Name
            if not cate in SystemListe.Keys:
                SystemListe[cate] = {}
            if not systype in SystemListe[cate].Keys:
                SystemListe[cate][systype] = [elem]
            else:
                SystemListe[cate][systype].append(elem)

gesamtliste = []
for System_Cate in SystemListe.Keys:
    if System_Cate == 'Luftkanal Systeme':
        for System_Typ in SystemListe[System_Cate].Keys:
            sysliste = SystemListe[System_Cate][System_Typ]

            element_Liste = []
            elementid_Liste = []

            def connector(elem,System_Typ):
                id = elem.Id.ToString()
                elementid_Liste.append(id)
                cate = elem.Category.Name
                sys_typ = None

                if elem.LookupParameter('Systemtyp'):
                    sys_typ = elem.LookupParameter('Systemtyp').AsValueString()

                else:
                    try:
                        sys_typ = elem.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).AsValueString()

                    except:
                        try:
                            sys_typ = elem.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsValueString()
                        except:
                            pass

                if sys_typ == System_Typ:
                    if not cate in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                        conns = None
                        try:
                            conns = elem.MEPModel.ConnectorManager.Connectors
                        except:
                            try:
                                conns = elem.ConnectorManager.Connectors
                            except:
                                conns = None
                        if conns:
                            if conns.Size == 1:
                                element_Liste.append(id)
                                element_Liste.append('-')

                            elif conns.Size == 2:
                                if cate == 'Rohrformteile':
                                    try:
                                        groesse = elem.get_Parameter(BuiltInParameter.RBS_CALCULATED_SIZE).AsString()
                                        arra = groesse.Split('-')
                                        size = len(set(arra))
                                        if size == 2:
                                            element_Liste.append('-')
                                    except:
                                        pass
                                element_Liste.append(id)
                                for conn in conns:
                                    if not conn.IsConnected:
                                        element_Liste.append('-')
                                        continue
                                    connectorSet = conn.AllRefs
                                    iterator = connectorSet.ForwardIterator()
                                    while iterator.MoveNext():
                                        currentConnector = iterator.Current
                                        if currentConnector:
                                            eleme = currentConnector.Owner
                                            if not eleme.Id.ToString() in elementid_Liste:
                                                connector(eleme,System_Typ)


                            elif conns.Size == 3:
                                element_Liste.append('-')
                                for conn in conns:
                                    if not conn.IsConnected:
                                        element_Liste.append('-')
                                        continue
                                    connectorSet = conn.AllRefs
                                    iterator = connectorSet.ForwardIterator()
                                    while iterator.MoveNext():
                                        currentConnector = iterator.Current
                                        if currentConnector:
                                            eleme = currentConnector.Owner
                                            if not eleme.Id.ToString() in elementid_Liste:
                                                element_Liste.append(id)
                                                connector(eleme,System_Typ)
                            else:
                                element_Liste.append('-')
                                for conn in conns:
                                    if not conn.IsConnected:
                                        element_Liste.append('-')
                                        continue
                                    connectorSet = conn.AllRefs
                                    iterator = connectorSet.ForwardIterator()
                                    while iterator.MoveNext():
                                        currentConnector = iterator.Current
                                        if currentConnector:
                                            eleme = currentConnector.Owner
                                            if not eleme.Id.ToString() in elementid_Liste:
                                                connector(eleme,System_Typ)
                else:
                    element_Liste.append('-')

            for sys_ele in sysliste:
                elements = sys_ele.DuctNetwork
                element = None
                for elem in elements:
                    cate = elem.Category.Name
                    if cate == 'Luftkanäle':
                        conns = elem.ConnectorManager.Connectors
                        for conn in conns:
                            if not conn.IsConnected:
                                element = elem
                                break

                if element:
                    connector(element,System_Typ)
                else:
                    try:
                        element = HLS_dict[sys_ele.Id.ToString()]
                        connector(element,System_Typ)
                    except:
                        pass
            gesamtliste.append(element_Liste)


    elif System_Cate == 'Rohr Systeme':
        for System_Typ in SystemListe[System_Cate].Keys:
            sysliste = SystemListe[System_Cate][System_Typ]
            element_Liste = []
            elementid_Liste = []

            def connector(elem,System_Typ):
                id = elem.Id.ToString()
                elementid_Liste.append(id)
                cate = elem.Category.Name
                sys_typ = None

                if elem.LookupParameter('Systemtyp'):
                    sys_typ = elem.LookupParameter('Systemtyp').AsValueString()

                else:
                    try:
                        sys_typ = elem.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).AsValueString()

                    except:
                        try:
                            sys_typ = elem.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsValueString()
                        except:
                            pass

                if sys_typ == System_Typ:
                    if not cate in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                        conns = None
                        try:
                            conns = elem.MEPModel.ConnectorManager.Connectors
                        except:
                            try:
                                conns = elem.ConnectorManager.Connectors
                            except:
                                conns = None
                        if conns:
                            if conns.Size == 1:
                                element_Liste.append(id)
                                element_Liste.append('-')

                            elif conns.Size == 2:
                                if cate == 'Rohrformteile':
                                    try:
                                        groesse = elem.get_Parameter(BuiltInParameter.RBS_CALCULATED_SIZE).AsString()
                                        arra = groesse.Split('-')
                                        size = len(set(arra))
                                        if size == 2:
                                            conns_letzt_size = doc.GetElement(ElementId(int(element_Liste[-1]))).MEPModel.ConnectorManager.Connectors.Size
                                            if conns_letzt_size < 3:
                                                element_Liste.append('-')
                                    except:
                                        pass
                                element_Liste.append(id)
                                for conn in conns:
                                    if not conn.IsConnected:
                                        continue
                                    connectorSet = conn.AllRefs
                                    iterator = connectorSet.ForwardIterator()
                                    while iterator.MoveNext():
                                        currentConnector = iterator.Current
                                        if currentConnector:
                                            eleme = currentConnector.Owner
                                            if not eleme.Id.ToString() in elementid_Liste:
                                                connector(eleme,System_Typ)


                            elif conns.Size == 3:
                                element_Liste.append('-')
                                for conn in conns:
                                    if not conn.IsConnected:
                                        element_Liste.append('-')
                                        continue
                                    connectorSet = conn.AllRefs
                                    iterator = connectorSet.ForwardIterator()
                                    while iterator.MoveNext():
                                        currentConnector = iterator.Current
                                        if currentConnector:
                                            eleme = currentConnector.Owner
                                            if not eleme.Id.ToString() in elementid_Liste:
                                                element_Liste.append(id)
                                                connector(eleme,System_Typ)
                            else:
                                element_Liste.append('-')
                                for conn in conns:
                                    if not conn.IsConnected:
                                        element_Liste.append('-')
                                        continue
                                    connectorSet = conn.AllRefs
                                    iterator = connectorSet.ForwardIterator()
                                    while iterator.MoveNext():
                                        currentConnector = iterator.Current
                                        if currentConnector:
                                            eleme = currentConnector.Owner
                                            if not eleme.Id.ToString() in elementid_Liste:
                                                connector(eleme,System_Typ)


                else:
                    element_Liste.append('-')


            for sys_ele in sysliste:
                elements = sys_ele.PipingNetwork
                element = None
                for elem in elements:
                    cate = elem.Category.Name
                    if cate == 'Rohre':
                        conns = elem.ConnectorManager.Connectors
                        for conn in conns:
                            if not conn.IsConnected:
                                element = elem
                                break

                if element:
                    element_Liste.append('-')
                    connector(element,System_Typ)
                else:
                    try:
                        element = HLS_dict[sys_ele.Id.ToString()]
                        element_Liste.append('-')
                        connector(element,System_Typ)
                    except:
                        pass

            gesamtliste.append(element_Liste)

element_Liste_neu_ges = []
for element_lis in gesamtliste:
    element_Liste_neu = []
    teil_liste = []
    for elem in element_lis:
        if elem == '-':
            element_Liste_neu.append(teil_liste)
            teil_liste = []
        else:
            teil_liste.append(int(elem))
    element_Liste_neu.append(teil_liste)
    element_Liste_neu_ges.append(element_Liste_neu)

if not forms.alert("TS-Nr. schreiben?", ok=False, yes=True, no=True):
    script.exit()

TsId = {}
for item_liste in element_Liste_neu_ges:
    for i in item_liste:
        try:
            item_liste.remove([])
        except:
            break
    for n, idliste in enumerate(item_liste):
        if any(idliste):
            for id in idliste:
                if id in TsId.Keys:
                    if not n+1 in TsId[id]:
                        TsId[id].append(n+1)
                else:
                    TsId[id] = [n+1]

t = Transaction(doc, 'Teilstrecken')
t.Start()
for elem_id in TsId.Keys:
    elem = doc.GetElement(ElementId(int(elem_id)))
    TSNr = ''
    for nr in TsId[elem_id]:
        TSNr = TSNr + 'IGF-' + str(nr) + ','
    TSNr_neu = TSNr[:-1]
    elem.LookupParameter('IGF_X_TS_Nr').Set(TSNr_neu)
                
t.Commit()