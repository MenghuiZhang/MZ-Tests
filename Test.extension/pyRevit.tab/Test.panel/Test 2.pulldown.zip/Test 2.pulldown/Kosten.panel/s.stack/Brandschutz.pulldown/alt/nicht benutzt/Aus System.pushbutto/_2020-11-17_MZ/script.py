# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "KG übernehmen"
__doc__ = """Kostengruppen aus den System übernommen werden außer es ist eine IGF_HLS_KG_Familie hinterlegt"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

bauteile_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment)\
    .WhereElementIsNotElementType()
bauteile = bauteile_collector.ToElementIds()


logger.info("{} HLS Bauteile ausgewählt".format(len(bauteile)))

if not bauteile:
    logger.error("Keine HLS Bauteile in aktueller Projekt gefunden")
    script.exit()

pipe_sys_collector = DB.FilteredElementCollector(doc) \
    .OfClass(clr.GetClrType(DB.Plumbing.PipingSystem))\
    .WhereElementIsNotElementType()
pipe_sys = pipe_sys_collector.ToElementIds()

logger.info("{} HLS Bauteile ausgewählt".format(len(pipe_sys)))

# Kostengruppen von System ermitteln
def System_KG(SYS_collector):
    KG_SYS = []
    for Sys in SYS_collector:
        Name = Sys.LookupParameter('Systemname').AsString()
        KG = Sys.LookupParameter('IGF_HLS_SYS_KG').AsValueString()
        KG_SYS.append([Name,KG])
    return(KG_SYS)
Rohr_System_KG = System_KG(pipe_sys_collector)

# KG übernehmen

with forms.ProgressBar(title='{value}/{max_value} Kostengruppen übernehmen',
                       cancellable=True, step=10) as pb1:
    n = 0

    t = Transaction(doc, "Kostengruppen übernehmen")
    t.Start()

    for HLS_BT in bauteile_collector:

        if pb1.cancelled:
            script.exit()

        n += 1

        pb1.update_progress(n, len(bauteile))

        KG_Familie = HLS_BT.LookupParameter("IGF_HLS_KG_Familie").AsValueString()
        System = HLS_BT.LookupParameter("Systemname").AsString()
        Systemname = ''
        if System:
            Systemname = System.split(',')[0]
        if KG_Familie:
            HLS_BT.LookupParameter('IGF_HLS_KG').Set(int(KG_Familie))
        else:
            for KGSYS in Rohr_System_KG:
                if Systemname == KGSYS[0]:
                    HLS_BT.LookupParameter('IGF_HLS_KG').Set(int(KGSYS[1]))

    t.Commit()




total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
