# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "8.1 Aus System"
__doc__ = """Kostengruppen aus den System übernommen werden"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

# System
duct_system_collector = DB.FilteredElementCollector(doc)\
          .OfCategory(DB.BuiltInCategory.OST_DuctSystem) \
          .WhereElementIsNotElementType()
duct_system = duct_system_collector.ToElementIds()

logger.info("{} Luftkanal Systeme ausgewählt".format(len(duct_system)))

# System
pipe_system_collector = DB.FilteredElementCollector(doc)\
          .OfCategory(DB.BuiltInCategory.OST_PipingSystem) \
          .WhereElementIsNotElementType()
pipe_system = pipe_system_collector.ToElementIds()

logger.info("{} Rohr Systeme ausgewählt".format(len(pipe_system)))

def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value

# Kostengruppen von System ermitteln
def Info_KG_ID(SYS_collector,Title,System_Ids):
    Ueberschrift = '{value}/{max_value} '+ Title
    with forms.ProgressBar(title=Ueberschrift,
                           cancellable=True, step=10) as pb:
        n = 0
        SystemDaten = []
        for Item in SYS_collector:

            if pb.cancelled:
                script.exit()

            n += 1

            pb.update_progress(n, len(System_Ids))
            SystemTypeId = Item.GetTypeId()
            SystemType = doc.GetElement(SystemTypeId)
            Name = Item.Name
            Type = SystemType.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            KG = get_value(SystemType.LookupParameter('IGF_X_Kostengruppe'))
            BIMID = get_value(SystemType.LookupParameter('IGF_X_BIM-ID'))
            SystemDaten.append([Type,Name,KG,BIMID])
        SystemDaten.sort()
        output.print_table(
            table_data=SystemDaten,
            title="System",
            columns=['Systemtyp','Systemname','Kostengruppen','BIM-ID']
        )

def Ele_System(all_elements,werte_liste):
    def Datenschreiben(para,Werte,cate):
        ergebnis = i.LookupParameter(para)
        if ergebnis:
            if Werte:
                Input.Set(int(Werte))
                logger.info('Parameter: {}, Werte: {}'.format(para,Werte))
        else:
            logger.error('Parameter {} in Kategorie {} konnte nicht gefunden werden'.format(para,cate))

    for i in all_elements:
        parameter = ['IGF_X_KG_Exemplar','IGF_X_BIM-ID_Exemplar','IGF_X_KN01_Exemplar',
        'IGF_X_KN02_Exemplar','IGF_X_Gewerkkürzel_Exemplar']
        Kategorie = i.Category.Name
        for nr in range(len(parameter)):
            Datenschreiben(parameter[nr],werte_liste[nr],Kategorie)

# KG und BIM-ID übernehmen
def Daten_Rohr_Schreiben(SYS_collector,System_Ids):
    Ueberschrift = '{value}/{max_value} Daten aus Rohr Systeme übernehmen'
    with forms.ProgressBar(title=Ueberschrift,
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Werte aus Rohr Systeme übernehmen")
        t.Start()

        for Item in SYS_collector:

            if pb.cancelled:
                script.exit()

            n += 1

            pb.update_progress(n, len(System_Ids))

            werte_list = []
            SystemTypeId = Item.GetTypeId()
            SystemType = doc.GetElement(SystemTypeId)
            parameter = ['IGF_X_Kostengruppe','IGF_X_BIM-ID','IGF_X_Kennnummer_1',
            'IGF_X_Kennnummer_2','IGF_X_Gewerkkürzel']
            for parame in parameter:
                werte_list.append(get_value(SystemType.LookupParameter(parame)))
            werte_list = [KG,BIMID,KN01,KN02,GE]
            Element = Item.PipingNetwork
            HLS_BT = Item.Elements
            Ele_System(Element,werte_list)
            Ele_System(HLS_BT,werte_list)

        t.Commit()

def Daten_Luft_Schreiben(SYS_collector,System_Ids):
    Ueberschrift = '{value}/{max_value} Daten aus Luftkanal Systeme übernehmen'
    with forms.ProgressBar(title=Ueberschrift,
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Werte aus Luftkanal Systeme übernehmen")
        t.Start()

        for Item in SYS_collector:

            if pb.cancelled:
                script.exit()

            n += 1

            pb.update_progress(n, len(System_Ids))

            werte_list = []
            SystemTypeId = Item.GetTypeId()
            SystemType = doc.GetElement(SystemTypeId)
            parameter = ['IGF_X_Kostengruppe','IGF_X_BIM-ID','IGF_X_Kennnummer_1',
            'IGF_X_Kennnummer_2','IGF_X_Gewerkkürzel']
            for parame in parameter:
                werte_list.append(get_value(SystemType.LookupParameter(parame)))
            werte_list = [KG,BIMID,KN01,KN02,GE]
            Element = Item.DuctNetwork
            auslass = Item.Elements
            Ele_System(Element,werte_list)
            Ele_System(auslass,werte_list)


        t.Commit()

Info_KG_ID(pipe_system_collector,'Rohr Systeme',pipe_system)
Info_KG_ID(duct_system_collector,'Luftkanal Systeme',duct_system)
if forms.alert('Kostengruppe und BIM-ID schreiben?', ok=False, yes=True, no=True):
    Daten_Rohr_Schreiben(pipe_system_collector,pipe_system)
    Daten_Luft_Schreiben(duct_system_collector,duct_system)

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
