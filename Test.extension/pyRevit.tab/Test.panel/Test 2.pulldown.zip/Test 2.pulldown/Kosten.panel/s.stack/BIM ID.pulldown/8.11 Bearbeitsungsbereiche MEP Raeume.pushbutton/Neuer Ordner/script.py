# coding: utf8

import xlrd
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "8.0 Aus Excel"
__doc__ = """Kostengruppe und BIM-ID aus excel in Modell schreiben(HLS-Bauteile,Rohrzubehör,Rohrsystem)"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

from pyIGF_logInfo import getlog
getlog(__title__)


uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

clr.AddReference('RevitServices')
import RevitServices
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
clr.AddReference('RevitAPI')
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB import FilteredElementCollector

Alle_Familien = DB.FilteredElementCollector(doc).OfClass(FamilySymbol)

# Familien
def Familie(Kategorie):
    Familie_Kollektor = []
    for item in Alle_Familien:
        category = item.Family.FamilyCategory.Name
        if category == Kategorie:
            Familie_Kollektor.append(item)
    info = "{} " + Kategorie + " ausgewählt"
    logger.info(info.format(len(Familie_Kollektor)))
    return Familie_Kollektor

# Familien
bauteile_collector = Familie('HLS-Bauteile')
Rohrzubehoer_collector = Familie('Rohrzubehör')

# System
pipe_system_collector = DB.FilteredElementCollector(doc)\
          .OfClass(clr.GetClrType(DB.Plumbing.PipingSystemType))
pipe_system = pipe_system_collector.ToElementIds()

logger.info("{} Rohr Systemtypen ausgewählt".format(len(pipe_system)))

# System
Luft_system_collector = DB.FilteredElementCollector(doc)\
          .OfClass(clr.GetClrType(DB.Mechanical.MechanicalSystemType))
Luft_system = Luft_system_collector.ToElementIds()

logger.info("{} Luftkanal Systemtypen ausgewählt".format(len(Luft_system)))


# Daten einlesen
def Daten_einlesen(sheet_name,Art):
    path = "R:\\Vorlagen\\_IGF\\_Kostengruppen\\IGF_Kostengruppen.xlsx"

    book = xlrd.open_workbook(path)
    sheet = book.sheet_by_name(sheet_name)
    rows = sheet.nrows
    cols = sheet.ncols
    Col = []
    for row in range(rows):
        Row = []
        for col in range(cols):
            cell = sheet.cell_value(row,col)
            Row.append(cell)
        Col.append(Row)

    Daten = []
    for i in range(1,len(Col)):
        if Col[i][0] == Art:
            Daten.append(Col[i])

    output.print_table(
        table_data=Daten,
        title="Daten aus Excel-----"+Art,
        columns=Col[0]
    )

    return Daten

# Namen Änderung
def Name_Aendern(para_name):
    Namen = [['Ä','Ae'], ['Ü','Ue'], ['Ö','Oe'], ['ä','ae'], ['ö','oe'],
             ['ü','ue'], ['—','-'],  ['ß','ss'], ['°',' '], ]
    name = ''
    for Buchstabe in para_name:
        for Buchstabe_Gruppe in Namen:
            if Buchstabe == Buchstabe_Gruppe[0]:
                Buchstabe = Buchstabe_Gruppe[1]
        name = name + Buchstabe
    return name

# Werte schreiben
def Daten_Familie_Schreiben(Familie,KG_Familie,category):
    Titel = '{value}/{max_value} Kostengruppen_' + category + ' schreiben'
    with forms.ProgressBar(title=Titel,
                           cancellable=True, step=10) as pb:
        n = 0
        text = 'Kostengruppen--' + category + ' schreiben'
        t = Transaction(doc, text)
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie))

            Familie_Name = Item.Family.Name
            FamilieName = Name_Aendern(str(Familie_Name))
            Familie_Typ = Item.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            FamilieTyp = Name_Aendern(str(Familie_Typ))

            logger.info('Familie: {}, Typ: {}'.format(Familie_Name,Familie_Typ))

            for KG in KG_Familie:
                if Name_Aendern(FamilieName) == KG[1] and Name_Aendern(FamilieTyp) == KG[2] and KG[4]:
                    Item.LookupParameter("IGF_X_Kostengruppe").Set(int(KG[4]))
        t.Commit()

def Daten_System_Schreiben(System,System_Id,KG_System,category):
    Titel = '{value}/{max_value} Kostengruppen_' + category + ' schreiben'
    with forms.ProgressBar(title=Titel,
                           cancellable=True, step=10) as pb:
        n = 0

        text = 'Kostengruppen--' + category + ' schreiben'
        t = Transaction(doc, text)
        t.Start()

        for Item in System:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(System_Id))

            System_Name = Item.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME).AsString()
            SystemName = Name_Aendern(str(System_Name))

            logger.info('System: {}'.format(System_Name))

            for KG in KG_System:
                if Name_Aendern(SystemName) == KG[1]:
                    if KG[4]:
                        Item.LookupParameter("IGF_X_Kostengruppe").Set(int(KG[4]))
                    if KG[5]:
                        Item.LookupParameter("IGF_X_Kennnummer_1").Set(int(KG[5]))
                    if KG[6]:
                        Item.LookupParameter("IGF_X_Kennnummer_2").Set(int(KG[6]))
                    Item.LookupParameter("IGF_X_Gewerkkürzel").Set(KG[3])
                    Item.LookupParameter("IGF_X_BIM-ID").Set(KG[7])

        t.Commit()

HLS_BT_Liste = Daten_einlesen('Familien','HLS-Bauteile')
Rohrzubehoer_Liste = Daten_einlesen('Familien','Rohrzubehoer')
Rohrsystem_Liste = Daten_einlesen('Familien','Rohr Systeme Typen')
Luftsystem_Liste = Daten_einlesen('Familien','Lueftungssysteme Typen')
if forms.alert('Kostengruppen schreiben?', ok=False, yes=True, no=True):
    Daten_Familie_Schreiben(bauteile_collector,HLS_BT_Liste,'HLS-Bauteile')
    Daten_Familie_Schreiben(Rohrzubehoer_collector,Rohrzubehoer_Liste,'Rohrzubehoer')
    Daten_System_Schreiben(pipe_system_collector,pipe_system,Rohrsystem_Liste,'Rohr Systeme')
    Daten_System_Schreiben(Luft_system_collector,Luft_system,Luftsystem_Liste,'Luft Systeme')


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
