# coding: utf8
import clr
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import *
import time
import clr
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel
from System.Windows.Forms import SaveFileDialog,DialogResult
import System

exapp = Excel.ApplicationClass()

start = time.time()

__title__ = "8.00 BIM-ID Export"
__doc__ = """..."""
__author__ = "Menghui Zhang"

from pyIGF_logInfo import getlog
getlog(__title__)


logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc
Excel_config = script.get_config()

systeme_luft = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
systeme_rohr = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
systeme_elek = FilteredElementCollector(doc).OfClass(clr.GetClrType(Electrical.ElectricalSystem)).WhereElementIsNotElementType()

Luft = {}
Rohr = {}
Elek = {}
system_luft = {}
system_rohr = {}
system_elek = {}

for el in systeme_luft:
    systyp = el.GetTypeId().ToString()
    if not systyp in system_luft.Keys:
        system_luft[systyp] = el.Id

for el in systeme_rohr:
    systyp = el.GetTypeId().ToString()
    if not systyp in system_rohr.Keys:
        system_rohr[systyp] = el.Id

for el in systeme_elek:
    systyp = el.GetTypeId().ToString()
    if not systyp in system_elek.Keys:
        system_luft[systyp] = el.Id

Gesamt = {}

excel_Adresse = ''

def DatenErmitteln(Sys_coll):
    _dict = {}
    for id in Sys_coll.Keys:
        sys = doc.GetElement(Sys_coll[id])
        el = doc.GetElement(DB.ElementId(int(id)))
        sys_Name = el.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_NAME).AsString()
        KG = el.LookupParameter('IGF_X_Kostengruppe').AsValueString()
        Gewerke = el.LookupParameter('IGF_X_Gewerkkürzel').AsString()
        KN_01 = el.LookupParameter('IGF_X_Kennnummer_1').AsValueString()
        KN_02 = el.LookupParameter('IGF_X_Kennnummer_2').AsValueString()
        ID = el.LookupParameter('IGF_X_BIM-ID').AsString()
        bereich = None
        elements = None
        try:
            elements = sys.PipingNetwork
        except:
            elements = sys.DuctNetwork
        for ele in elements:
            try:
                bereich = ele.LookupParameter('Bearbeitungsbereich').AsValueString()
            except:
                pass
            if bereich:
                break
        _dict[sys_Name] = [ID,Gewerke,KG,KN_01,KN_02,bereich]
    return _dict

def ExcelExport(path):
    book = exapp.Workbooks.Open(path)
    Sheets = [s.Name for s in book.Worksheets]
    if not 'Elektro' in Sheets:
        sheet = book.Worksheets.Add()
        sheet.Name = 'Elektro'
        sheet.Cells[1,1] = 'Systemname'
        sheet.Cells[1,2] = 'Gewerkkürzel'
        sheet.Cells[1,3] = 'Kostengruppen'
        sheet.Cells[1,4] = 'Kennnummer_1'
        sheet.Cells[1,5] = 'Kennnummer_2'
        sheet.Cells[1,6] = 'BIM-ID'
        sheet.Cells[1,7] = 'Bearbeitungsbereich'
    if not 'Luft' in Sheets:
        sheet = book.Worksheets.Add()
        sheet.Name = 'Luft'
        sheet.Cells[1,1] = 'Systemname'
        sheet.Cells[1,2] = 'Gewerkkürzel'
        sheet.Cells[1,3] = 'Kostengruppen'
        sheet.Cells[1,4] = 'Kennnummer_1'
        sheet.Cells[1,5] = 'Kennnummer_2'
        sheet.Cells[1,6] = 'BIM-ID'
        sheet.Cells[1,7] = 'Bearbeitungsbereich'

    if not 'Rohr' in Sheets:
        sheet = book.Worksheets.Add()
        sheet.Name = 'Rohr'
        sheet.Cells[1,1] = 'Systemname'
        sheet.Cells[1,2] = 'Gewerkkürzel'
        sheet.Cells[1,3] = 'Kostengruppen'
        sheet.Cells[1,4] = 'Kennnummer_1'
        sheet.Cells[1,5] = 'Kennnummer_2'
        sheet.Cells[1,6] = 'BIM-ID'
        sheet.Cells[1,7] = 'Bearbeitungsbereich'


    for sheet in book.Worksheets:
        if sheet.Name in Gesamt.Keys:
            Daten = Gesamt[sheet.Name]
            rows = sheet.UsedRange.Rows.Count
            n = 0
            for row in range(2, rows+1):
                sysname = sheet.Cells[row, 1].Value2
                if sysname in Daten.Keys:
                    sheet.Cells[row, 2] = Daten[sysname][1]
                    sheet.Cells[row, 3] = Daten[sysname][2]
                    sheet.Cells[row, 4] = Daten[sysname][3]
                    sheet.Cells[row, 5] = Daten[sysname][4]
                    sheet.Cells[row, 6] = Daten[sysname][0]
                    sheet.Cells[row, 7] = Daten[sysname][5]
                    del Daten[sysname]
            if any(Daten.Keys):
                for name in Daten.Keys:
                    n += 1
                    sheet.Cells[rows + n,1] = name
                    sheet.Cells[rows + n,2] = Daten[name][1]
                    sheet.Cells[rows + n,3] = Daten[name][2]
                    sheet.Cells[rows + n,4] = Daten[name][3]
                    sheet.Cells[rows + n,5] = Daten[name][4]
                    sheet.Cells[rows + n,6] = Daten[name][0]
                    sheet.Cells[rows + n,7] = Daten[name][5]
        else:
            if not sheet.Name in ['Luft','Rohr','Elektro']:
                sheet.Delete()
    book.Save()
    book.Close()

# read_config
try:
    excel_Adresse = str(Excel_config.excel)
except:
    pass

if forms.alert("Neue Excel erstellen?", ok=False, yes=True, no=True):
    dialog = SaveFileDialog()
    dialog.Title = "Speichern unter"
    dialog.Filter = "Execl Dateien (*.xlsx)|*.xlsx"
    dialog.FilterIndex = 0
    dialog.RestoreDirectory = True
    
    exapp.Application.Workbooks.Add(System.Type.Missing)
    if dialog.ShowDialog() == DialogResult.OK:
        fs = dialog.OpenFile()
        fs.Close()

    exapp.ActiveWorkbook.SaveCopyAs(dialog.FileName)
    exapp.ActiveWorkbook.Saved = True
    exapp.Quit()
    excel_Adresse = dialog.FileName
    Excel_config.excel = excel_Adresse
    script.save_config()

Luft = DatenErmitteln(system_luft)
Rohr = DatenErmitteln(system_rohr)
Elek = DatenErmitteln(system_elek)
Gesamt['Luft'] = Luft
Gesamt['Rohr'] = Rohr
Gesamt['Elektro'] = Elek

ExcelExport(excel_Adresse)

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
