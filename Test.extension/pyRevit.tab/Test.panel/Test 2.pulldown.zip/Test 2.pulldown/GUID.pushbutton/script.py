# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
from pyIGF_lib import AddProjParamfromShared,get_value, set_value


start = time.time()


__title__ = "GUID"
__doc__ = """GUID in Parameter schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

HLS_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment) \
    .WhereElementIsNotElementType()

AM_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_GenericModel) \
    .WhereElementIsNotElementType()

EA_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_ElectricalEquipment) \
    .WhereElementIsNotElementType()

FR_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_FlexPipeCurves) \
    .WhereElementIsNotElementType()


FK_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_FlexDuctCurves) \
    .WhereElementIsNotElementType()

LR = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_Conduit) \
    .WhereElementIsNotElementType()

LRF = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_ConduitFitting) \
    .WhereElementIsNotElementType()

LDA = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctInsulations) \
    .WhereElementIsNotElementType()

LDI = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctLinings) \
    .WhereElementIsNotElementType()

LD = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctTerminal) \
    .WhereElementIsNotElementType()


LF = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctFitting) \
    .WhereElementIsNotElementType()

LZ = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctAccessory) \
    .WhereElementIsNotElementType()

LK = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctCurves) \
    .WhereElementIsNotElementType()

RD = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_PipeInsulations) \
    .WhereElementIsNotElementType()

RF = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_PipeFitting) \
    .WhereElementIsNotElementType()

RZ = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_PipeAccessory) \
    .WhereElementIsNotElementType()

Ro = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_PipeCurves) \
    .WhereElementIsNotElementType()

SI = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_PlumbingFixtures) \
    .WhereElementIsNotElementType()

SP = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_Sprinklers) \
    .WhereElementIsNotElementType()

def DatenSchreiben(coll,Cate):
    trandoc = 'GUID Schreiben_'+Cate
    ids = coll.ToElementIds()
    t = Transaction(doc,trandoc)
    t.Start()

    with forms.ProgressBar(title='{value}/{max_value} Bauteile in Kategorie ' + Cate,
                           cancellable=True, step=10) as pb:
        n = 0
        for id in ids:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(ids))
            el = doc.GetElement(id)

            guid = el.UniqueId
            el.LookupParameter('IGF_X_GUID').Set(guid)

    t.Commit()

DatenSchreiben(HLS_collector,'HLS Bauteile')


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
