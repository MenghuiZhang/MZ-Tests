# coding: utf8
from pyrevit import revit, UI, DB, script, forms
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
import clr
from pyrevit.forms import WPFWindow

__title__ = "Teilstrecken"
__doc__ = """Teilstrecken zuweisen"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()
Element_config = script.get_config()

uidoc = revit.uidoc
doc = revit.doc

system_luft = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
system_rohr = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
system_elek = FilteredElementCollector(doc).OfClass(clr.GetClrType(Electrical.ElectricalSystem)).WhereElementIsNotElementType()

HLS_coll = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType()

HLS_dict = {}

for elem in HLS_coll:
    conns = None
    try:
        conns = elem.MEPModel.ConnectorManager.Connectors
    except:
        try:
            conns = elem.ConnectorManager.Connectors
        except:
            conns = None
    if conns:
        for conn in conns:
            if conn.IsConnected:
                if conn.Direction == FlowDirectionType.Out:
                    connectorSet = conn.AllRefs.ForwardIterator()
                    while connectorSet.MoveNext():
                        currentConnector = connectorSet.Current
                        if currentConnector:
                            eleme = currentConnector.Owner
                            try:
                                systemid = eleme.MEPSystem.Id.ToString()
                                if not systemid in HLS_dict.Keys:
                                    HLS_dict[systemid] = [eleme,elem.Id.ToString()]
                            except:
                                pass
HLS_coll.Dispose()

system_luft_dict = {}
system_rohr_dict = {}
system_elek_dict = {}

def coll2dict(coll,dict):
    for el in coll:
        name = el.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM).AsString()
        type = el.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
        if type in dict.Keys:
            dict[type].append(el.Id)
        else:
            dict[type] = [el.Id]
coll2dict(system_luft,system_luft_dict)
coll2dict(system_rohr,system_rohr_dict)
coll2dict(system_elek,system_elek_dict)
system_elek.Dispose()
system_luft.Dispose()
system_rohr.Dispose()

class System(object):
    def __init__(self):
        self.checked = False
        self.SystemName = ''
        self.TypName = ''

    @property
    def TypName(self):
        return self._TypName
    @TypName.setter
    def TypName(self, value):
        self._TypName = value
    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def ElementId(self):
        return self._ElementId
    @ElementId.setter
    def ElementId(self, value):
        self._ElementId = value

# Datensource für GUI
Liste_Luft = ObservableCollection[System]()
Liste_Rohr = ObservableCollection[System]()
Liste_Elektro = ObservableCollection[System]()
Liste_Alle = ObservableCollection[System]()

for key in system_luft_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_luft_dict[key]
    Liste_Luft.Add(temp_system)
    Liste_Alle.Add(temp_system)

for key in system_rohr_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_rohr_dict[key]
    Liste_Rohr.Add(temp_system)
    Liste_Alle.Add(temp_system)

for key in system_elek_dict.Keys:
    temp_system = System()
    temp_system.TypName = key
    temp_system.ElementId = system_elek_dict[key]
    Liste_Elektro.Add(temp_system)
    Liste_Alle.Add(temp_system)

# GUI
class Systemauswahl(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_Elektro,liste_All):
        self.liste_Luft = liste_Luft
        self.liste_Rohr = liste_Rohr
        self.liste_Elektro = liste_Elektro
        self.liste_All = liste_All
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[System]()
        self.altdatagrid = None

        try:
            self.dataGrid.ItemsSource = self.liste_All
            self.altdatagrid = self.liste_All
            self.backAll()
            self.click(self.all)
        except Exception as e:
            logger.error(e)

        self.SucheSystemtyp.TextChanged += self.search_txt_changed

# Button Farbe ändern
    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic

# Button Farbe zurücksetzen
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.SucheSystemtyp.Text
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.TypName.find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()

    def backAll(self):
        def back(button):
            button.Background  = Brushes.White
            button.FontWeight = FontWeights.Normal
            button.FontStyle = FontStyles.Normal
        self.back(self.all)
        self.back(self.luft)
        self.back(self.rohr)
        self.back(self.elek)

    def lueftung(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Items.Refresh()

    def rohre(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Items.Refresh()

    def elektro(self,sender,args):
        self.backAll()
        self.click(self.elek)
        self.dataGrid.ItemsSource = self.liste_Elektro
        self.altdatagrid = self.liste_Elektro
        self.dataGrid.Items.Refresh()

    def alle(self,sender,args):
        self.backAll()
        self.click(self.all)
        self.dataGrid.ItemsSource = self.liste_All
        self.altdatagrid = self.liste_All
        self.dataGrid.Items.Refresh()

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()

    def auswahl(self,sender,args):
        self.backAll()
        self.Close()

Systemwindows = Systemauswahl("System.xaml",Liste_Luft,Liste_Rohr,Liste_Elektro,Liste_Alle)
Systemwindows.ShowDialog()

# Ausgewählte Systeme
SystemListe = {}
for el in Liste_Alle:
    if el.checked == True:
        for id in el.ElementId:
            elem = doc.GetElement(id)
            sysname = elem.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM).AsString()
            systype = elem.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
            cate = elem.Category.Name
            if not cate in SystemListe.Keys:
                SystemListe[cate] = {}
            if not systype in SystemListe[cate].Keys:
                SystemListe[cate][systype] = [elem]
            else:
                SystemListe[cate][systype].append(elem)



# Teilstrecken teilen
def TSListe(element,System_Typ,elem_id):
    element_Liste = []
    element_TSID_Liste = []
    elementid_Liste = []
    if elem_id:
        elementid_Liste.append(elem_id)

    def connector(elem,System_Typ):
        id = elem.Id.ToString()
        elementid_Liste.append(id)
        cate = elem.Category.Name
        sys_typ = None
        verknuepft = 0
        try:
            verknuepft = elem.LookupParameter("IGF_X_Nova_Verknüpft").AsInteger()
        except:
            verknuepft = 0

        try:
            sys_typ = elem.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).AsValueString()
        except:
            try:
                sys_typ = elem.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsValueString()
            except:
                pass
            
        if sys_typ == System_Typ:
            if not cate in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                conns = None
                try:
                    conns = elem.MEPModel.ConnectorManager.Connectors
                except:
                    try:
                        conns = elem.ConnectorManager.Connectors
                    except:
                        conns = None

                if conns:
                    # Position 1
                    if conns.Size == 1:
                        # print('# Position 1')
                        # if verknuepft == 0:
                        #     element_TSID_Liste.append(id)
                        #     element_TSID_Liste.append('-') 
                        element_Liste.append(id)
                        element_Liste.append('-')
                    # Position 2
                    elif conns.Size == 2:
                        # print('# Position 2.1')
                        if not cate in ['Rohrformteile', "Rohre", "Rohrzubehör","Flexible Rohre",
                        'Luftkanalformteile', "Luftkanäle", "Luftkanalzubehör","Flexkanäle",]:
                            element_Liste.append(id)
                            element_Liste.append('-')
                            # if verknuepft == 0:
                            #     element_TSID_Liste.append(id)
                            #     element_TSID_Liste.append('-') 
                        
                        else:
                            # print('# Position 2.2')
                            if cate in ['Rohrformteile','Luftkanalformteile']:
                                try:
                                    groesse = elem.get_Parameter(BuiltInParameter.RBS_CALCULATED_SIZE).AsString()
                                    sizeliste = groesse.Split('-')
                                    size = len(set(sizeliste))
                                    if size == 2:
                                        # element_TSID_Liste.append('-') 
                                        element_Liste.append('-')
                                except:
                                    pass
                            
                            # if verknuepft == 0:
                            #     element_TSID_Liste.append(id)
                            element_Liste.append(id)

                            for conn in conns:
                                if not conn.IsConnected:
                                    continue
                                Refs = conn.AllRefs
                                for ref in Refs:
                                    eleme = ref.Owner
                                    #print(id,eleme.Id.ToString())
                                    if not eleme.Id.ToString() in elementid_Liste:
                                        if eleme.Category.Name in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                                            continue
                                        # print(id,eleme.Id.ToString())
                                        connector(eleme,System_Typ)
                    # Position 3
                    elif conns.Size == 3:
                        element_Liste.append('-')
                        # element_TSID_Liste.append('-') 
                        # conn nach Id sortieren
                        conn_neu = [[int(co.Id.ToString()),co] for co in conns]
                        conn_neu.sort()
                        conns_neu = [item[1] for item in conn_neu] 

                        for conn in conns_neu:
                            if not conn.IsConnected:
                                element_Liste.append('-')
                                # element_TSID_Liste.append('-') 
                                continue
                            Refs = conn.AllRefs
                            for ref in Refs:
                                eleme = ref.Owner
                                if not eleme.Id.ToString() in elementid_Liste:
                                    if eleme.Category.Name in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                                        continue
                                    element_Liste.append(id)
                                    # if verknuepft == 0:
                                    #     element_TSID_Liste.append(id)
                                    connector(eleme,System_Typ)
                    # Position 4
                    else:
                        element_Liste.append('-')
                        # element_TSID_Liste.append('-') 
                        # conn nach Id sortieren
                        conn_neu = [[int(co.Id.ToString()),co] for co in conns]
                        conn_neu.sort()
                        conns_neu = [item[1] for item in conn_neu] 

                        for conn in conns_neu:
                            if not conn.IsConnected:
                                # element_TSID_Liste.append('-') 
                                element_Liste.append('-')
                                continue
                            Refs = conn.AllRefs
                            for ref in Refs:
                                eleme = ref.Owner
                                if not eleme.Id.ToString() in elementid_Liste:
                                    if eleme.Category.Name in ['Luftkanal Systeme','Rohr Systeme', 'Rohrdämmung' , 'Luftkanaldämmung außen', 'Luftkanaldämmung innen']:
                                        continue
                                    element_Liste.append(id)
                                    # if verknuepft == 0:
                                    #     element_TSID_Liste.append(id)
                                    connector(eleme,System_Typ)
        else:
            element_Liste.append('-')
            # element_TSID_Liste.append('-') 
    connector(element,System_Typ)
    return element_Liste#,element_TSID_Liste

# Anfangselement

def Anfang(system, category):
    Element = None
    elements = None
    elementId = None
    if category == 'Rohre':
        elements = system.PipingNetwork
    elif category == 'Luftkanäle':
        elements = system.DuctNetwork
    for el in elements:
        cate = el.Category.Name
        if cate == category:
            conns = el.ConnectorManager.Connectors
            for conn in conns:
                if not conn.IsConnected:
                    Element = el
                    break
    if not Element:
        try:
            Element = HLS_dict[sys_ele.Id.ToString()][0]
            elementId = HLS_dict[sys_ele.Id.ToString()][1]
        except:
            pass
    return Element, elementId

# Anfangselement

def Ende(systemlist):
    EndTSNr = 0
    for sys_ele in systemlist:
        elements = None
        try:
            elements = sys_ele.PipingNetwork
        except:
            elements = sys_ele.DuctNetwork
       
        for el in elements:
            try:
                EndTS = el.LookupParameter("IGF_X_TS_ID").AsString()
                verknuepft = el.LookupParameter("IGF_X_Nova_Verknüpft").AsInteger()
                if verknuepft != 0:
                    if len(EndTS) > 4:
                        if EndTSNr < int(float(EndTS[4:])):
                            EndTSNr = int(float(EndTS[4:]))
            except:
                pass
    return EndTSNr


gesamtliste = []
gesamtIDliste = []
for System_Cate in SystemListe.Keys:
    for System_Typ in SystemListe[System_Cate].Keys:
        sysliste = SystemListe[System_Cate][System_Typ]
        systemTs_liste= []
        # elementTSIDListe = []
        # EndNr = Ende(sysliste)

        for sys_ele in sysliste:
            
            if System_Cate == 'Rohr Systeme':
                element,elemId = Anfang(sys_ele,'Rohre')
                if element:
                    systemTs_liste.append('-')
                    #elementTSIDListe.append('-')
                    elementliste= TSListe(element,System_Typ,elemId)#, elementTSidListe= TSListe(element,System_Typ,elemId)
                    systemTs_liste.extend(elementliste)
                    # elementTSIDListe.extend(elementTSidListe)
                    # print(elementTSidListe)

            elif System_Cate == 'Luftkanal Systeme':
                element,elemId = Anfang(sys_ele,'Luftkanäle')
                if element:
                    systemTs_liste.append('-')
                    #elementTSIDListe.append('-')
                    elementliste= TSListe(element,System_Typ,elemId)#, elementTSidListe= TSListe(element,System_Typ,elemId)
                    systemTs_liste.extend(elementliste)
                    #elementTSIDListe.extend(elementTSidListe)
                    #print(elementTSidListe)
            else:
                pass
            
       # gesamtIDliste.append([EndNr,elementTSIDListe])
        gesamtliste.append(systemTs_liste)      

element_Liste_neu_ges = []
for element_lis in gesamtliste:
    element_Liste_neu = []
    teil_liste = []
    for elem in element_lis:
        if elem == '-':
            element_Liste_neu.append(teil_liste)
            teil_liste = []
        else:
            teil_liste.append(int(elem))
    element_Liste_neu.append(teil_liste)
    element_Liste_neu_ges.append(element_Liste_neu)

# element_Liste_neuID_ges = []
# for element_lis in gesamtIDliste:
#     endnr = element_lis[0]
#     element_Liste_neu = []
#     teil_liste = []
#     for elem in element_lis[1]:
#         if elem == '-':
#             element_Liste_neu.append(teil_liste)
#             teil_liste = []
#         else:
#             teil_liste.append(int(elem))
#     element_Liste_neu.append(teil_liste)
#     element_Liste_neuID_ges.append([endnr,element_Liste_neu])

if not forms.alert("TS-Nr. schreiben?", ok=False, yes=True, no=True):
    script.exit()

TsNr = {}
for item_liste in element_Liste_neu_ges:
    for i in item_liste:
        try:
            item_liste.remove([])
        except:
            break
    for n, idliste in enumerate(item_liste):
        if any(idliste):
            for id in idliste:
                if id in TsNr.Keys:
                    if not n+1 in TsNr[id]:
                        TsNr[id].append(n+1)
                else:
                    TsNr[id] = [n+1]

t = Transaction(doc, 'Teilstrecken Nr')
t.Start()
for elem_id in TsNr.Keys:
    elem = doc.GetElement(ElementId(int(elem_id)))
    TSNr = ''
    for nr in TsNr[elem_id]:
        TSNr = TSNr + 'IGF-' + str(nr) + ','
    TSNr_neu = TSNr[:-1]
    elem.LookupParameter('IGF_X_TS_Nr').Set(TSNr_neu)
                
t.Commit()

# TsID = {}
# for item_liste in element_Liste_neuID_ges:
#     for i in item_liste[1]:
#         try:
#             item_liste[1].remove([])
#         except:
#             break
#     for n, idliste in enumerate(item_liste[1]):
#         if any(idliste):
#             for id in idliste:
#                 if id in TsID.Keys:
#                     if not n+1 in TsID[id]:
#                         TsID[id].append(n+1+item_liste[0])
#                 else:
#                     TsID[id] = [n+1+item_liste[0]]


# t = Transaction(doc, 'Teilstrecken ID')
# t.Start()
# for elem_id in TsID.Keys:
#     elem = doc.GetElement(ElementId(int(elem_id)))
#     TSid = ''
#     for nr in TsID[elem_id]:
#         TSid = TSid + 'IGF-' + str(nr) + ','
#     TSid_neu = TSid[:-1]
#     elem.LookupParameter('IGF_X_TS_ID').Set(TSid_neu)
                
# t.Commit()