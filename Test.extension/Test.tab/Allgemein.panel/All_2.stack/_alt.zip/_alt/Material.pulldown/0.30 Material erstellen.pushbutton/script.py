# coding: utf8
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from IGF_log import getlog
from rpw import revit,DB
from pyrevit import script, forms
import clr
clr.AddReference("Microsoft.Office.Interop.Excel")
from IGF_forms import ExcelSuche
from System.Runtime.InteropServices import Marshal
import Microsoft.Office.Interop.Excel as Excel
from Autodesk.Revit.DB.Visual import AppearanceAssetEditScope
import System
import os


__title__ = "0.30 Material erstellen"
__doc__ = """
Material erstellen
Vorlage: R:\pyRevit\00_Allgemein\02_Material erstellen\IGF_Material.xlsx


[2021.11.29]
Version: 1.1
"""
__author__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc
app = revit.app
uiapp = revit.uiapp

projectinfo = doc.ProjectInformation.Name + ' - '+ doc.ProjectInformation.Number
config = script.get_config('Materialien - ' + projectinfo)
adresse = 'Excel Adresse'

try:
    adresse = config.adresse
    if not os.path.exists(config.adresse):
        config.adresse = ''
        adresse = "Excel Adresse"
except:
    pass

ExcelWPF = ExcelSuche(exceladresse = adresse)
ExcelWPF.ShowDialog()
try:
    config.adresse = ExcelWPF.Adresse.Text
    script.save_config()
except:
    logger.error('kein Excel gegeben')
    script.exit()

Material_collector = DB.FilteredElementCollector(doc).OfClass(clr.GetClrType(DB.Material))
Material_aus_projekt = {}

for ele in Material_collector:
    Material_aus_projekt[ele.Name] = ele
Material_collector.Dispose()

class Material_excel:
    def __init__(self,name,r,g,b,origin):
        self.name = name
        self.r = r
        self.g = g
        self.b = b
        self.origin = origin
        if not origin in Material_aus_projekt.keys():
            self.origin = None

exapp = Excel.ApplicationClass()
book = exapp.Workbooks.Open(adresse)

# Excel lesen
Material_aus_excel = []

for sheet in book.Worksheets:
    rows = sheet.UsedRange.Rows.Count
    with forms.ProgressBar(title='{value}/{max_value} Daten Lesen',cancellable=True, step=10) as pb:
        n = 0
        for row in range(2, rows+1):
            n += 1
            if pb.cancelled:
                Marshal.FinalReleaseComObject(sheet)
                Marshal.FinalReleaseComObject(book)
                exapp.Quit()
                Marshal.FinalReleaseComObject(exapp)
                script.exit()
            pb.update_progress(n, rows-1)
            original = sheet.UsedRange.Cells[row, 3].Value2
            Name = sheet.UsedRange.Cells[row, 4].Value2
            Farbe = sheet.UsedRange.Cells[row,6].Value2
            R = sheet.UsedRange.Cells[row,7].Value2
            G = sheet.UsedRange.Cells[row,8].Value2
            B = sheet.UsedRange.Cells[row,9].Value2
            if Farbe:
                material = Material_excel(Name,R,G,B,original)
                Material_aus_excel.append(material)

book.Save()
book.Close()

if forms.alert('Material erstellen?', ok=False, yes=True, no=True):
    t = DB.Transaction(doc,'Material aus Excel erstellen')
    t.Start()
    with forms.ProgressBar(title='{value}/{max_value} Material',cancellable=True, step=1) as pb:
        editScope = AppearanceAssetEditScope(doc)
        for n, material_excel in enumerate(Material_aus_excel):
            if pb.cancelled:
                t.RollBack()
                script.exit()
            pb.update_progress(n + 1, len(Material_aus_excel))
            R = int(material_excel.r)
            G = int(material_excel.g)
            B = int(material_excel.b)
            farbe = DB.Color(System.Byte(R),System.Byte(G),System.Byte(B))
            if not material_excel.name in Material_aus_projekt.keys():
                logger.info('{} wird erstellt'.format(material_excel.name))
                material_id = DB.Material.Create(doc,material_excel.name)
                material = doc.GetElement(material_id)
            else:
                logger.info('{} wird angepasst'.format(material_excel.name))
                material = Material_aus_projekt[material_excel.name]          
            
            material.Color = farbe
            material.Transparency = 0
            material.SurfaceForegroundPatternColor = farbe
            material.UseRenderAppearanceForShading = False
            aa = DB.AppearanceAssetElement.GetAppearanceAssetElementByName(doc, 'Generisch(1885)').Duplicate(material_excel.name)
            TherId = None
            StruId = None
            if material_excel.origin and material_excel.origin in Material_aus_projekt.keys():
                TherId = Material_aus_projekt[material_excel.origin].ThermalAssetId
                StruId = Material_aus_projekt[material_excel.origin].StructuralAssetId

            editableAsset = editScope.Start(aa.Id)
            asset = aa.GetRenderingAsset()
            dict_asset = {}
            for n in range(asset.Size):
                item = asset[n]
                try:
                    Name = item.Name
                    dict_asset[Name] = n

                except Exception as e:
                    pass
            try:
                editableAsset[dict_asset["generic_is_metal"]].Value = False
                editableAsset[dict_asset["generic_reflectivity_at_0deg"]].Value = 0
                editableAsset[dict_asset["generic_reflectivity_at_90deg"]].Value = 0
                editableAsset[dict_asset["generic_transparency_image_fade"]].Value = 1
                editableAsset[dict_asset["generic_diffuse_image_fade"]].Value = 0
                editableAsset[dict_asset["generic_transparency"]].Value = 0
                editableAsset[dict_asset["generic_glossiness"]].Value = 0
                editableAsset[dict_asset["generic_self_illum_filter_map"]].SetValueAsColor(farbe)
                editableAsset[dict_asset["generic_diffuse"]].SetValueAsColor(farbe)

            except Exception as e:
                logger.error(e)
            editScope.Commit(True)
            material.AppearanceAssetId = aa.Id
            if TherId:
                material.ThermalAssetId = TherId
                material.StructuralAssetId = StruId

    t.Commit()
    t.Dispose()