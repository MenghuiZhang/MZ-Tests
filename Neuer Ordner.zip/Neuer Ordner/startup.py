# coding: utf8
# import sys
# sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
# from pyrevit.coreutils.ribbon import get_uibutton

# button = get_uibutton('Werkzeuge')
# tooltip = r'R:\pyRevit\xx_Skripte\_Menghui\Test.extension\pyRevit.tab\Einstellungen.panel\s.stack\Werkzeuge.smartbutton\tooltip.png'
# button.set_tooltip_image(tooltip)