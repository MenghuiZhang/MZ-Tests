# pylint: skip-file

from System import EventHandler, Uri
from Autodesk.Revit.UI.Events import ViewActivatedEventArgs, ViewActivatingEventArgs
from pyrevit import HOST_APP, EXEC_PARAMS
from pyrevit import revit, script

# # import hooks_logger as hl
def event_handler_function():
    # do the even stuff here
    pass
__revit__.ViewActivating += EventHandler[ViewActivatingEventArgs](event_handler_function)
# args = EXEC_PARAMS.event_args
# print(args.Cancellable)

# hl.log_hook(__file__,
#     {
#         "cancellable?": str(args.Cancellable),
#         "doc": str(revit.doc),
#         "added": str(args.GetAddedElementIds().Count),
#         "deleted": str(args.GetDeletedElementIds().Count),
#         "modified": str(args.GetModifiedElementIds().Count),
#         "txn_names": str(list(args.GetTransactionNames())),
#         "operation": str(args.Operation),
#     },
#     log_doc_access=True
# )
# from Autodesk.Revit.ApplicationServices import ControlledApplication
# event1 = ControlledApplication.DocumentChanged
# print(event1)