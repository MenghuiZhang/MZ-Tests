# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr
from operator import itemgetter, attrgetter
import xlsxwriter

clr.AddReference('RevitServices')
import RevitServices
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
clr.AddReference('RevitAPI')
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB import FilteredElementCollector
start = time.time()

__title__ = "System"
__doc__ = """Alle Familien in Excel schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

pipe = DB.FilteredElementCollector(doc).OfClass(clr.GetClrType(DB.Plumbing.PipingSystemType))
duct = DB.FilteredElementCollector(doc).OfClass(clr.GetClrType(DB.Mechanical.MechanicalSystemType))
elec = DB.FilteredElementCollector(doc).OfClass(clr.GetClrType(DB.Electrical.ElectricalSystem))
# Name ändern
def Name_Aendern(para_name):
    Namen = [['Ä','Ae'], ['Ü','Ue'], ['Ö','Oe'], ['ä','ae'], ['ö','oe'],
             ['ü','ue'], ['ß','ss'], ['—','-'],]
    name = ''
    i = 0
    for Buchstabe in para_name:
        for Buchstabe_Gruppe in Namen:
            if Buchstabe == Buchstabe_Gruppe[0]:
                Buchstabe = Buchstabe_Gruppe[1]
        name = name + Buchstabe
    return name

# Daten in Excel schreiben
def Daten_Schreiben(path,liste):

    workbook = xlsxwriter.Workbook(path)
    worksheet = workbook.add_worksheet()

    for col in range(len(liste[0])):
        for row in range(len(liste)):
            cell = Name_Aendern(liste[row][col])
            worksheet.write(row, col,cell)


    workbook.close()

def NEW_Liste(para_name,old_list):
    new_list = []
    for item_list in old_list:
        if item_list[0] == para_name:
            new_list.append(item_list)
    return new_list

pipe_liste = []
for item in pipe:
    Name = item.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME).AsString()
    category = item.Category.Name
    pipe_liste.append([category,Name])

duct_liste = []
for item in duct:
    Name = item.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME).AsString()
    category = item.Category.Name
    duct_liste.append([category,Name])

# elec_liste = []
# for item in elec:
#     Name = item.ElectricalSystemType.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME).AsString()
#     category = item.Category.Name
#     elec_liste.append([category,Name])
output.print_table(
    table_data=pipe_liste,
    title="pipe_liste",
    columns=['Kategorie', 'Name', ]
)
output.print_table(
    table_data=duct_liste,
    title="duct_liste",
    columns=['Kategorie', 'Name', ]
)

new_list = pipe_liste+duct_liste
new_list = sorted(new_list, key=itemgetter(1))
path = 'C:\\Users\\werksstudent\\Desktop\\System.xlsx'
path1 = 'C:\\Users\\werksstudent\\Desktop\\duct.xlsx'
Daten_Schreiben(path,new_list)
Daten_Schreiben(path1,duct_liste)

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
