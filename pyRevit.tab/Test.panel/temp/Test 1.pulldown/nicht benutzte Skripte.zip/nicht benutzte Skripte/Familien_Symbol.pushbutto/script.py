# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr
from operator import itemgetter, attrgetter
import xlsxwriter

clr.AddReference('RevitServices')
import RevitServices
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
clr.AddReference('RevitAPI')
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB import FilteredElementCollector
start = time.time()

__title__ = "FamilySymbol"
__doc__ = """Alle Familien in Excel schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

out = DB.FilteredElementCollector(doc).OfClass(FamilySymbol)

# Name ändern
def Name_Aendern(para_name):
    Namen = [['Ä','Ae'], ['Ü','Ue'], ['Ö','Oe'], ['ä','ae'], ['ö','oe'],
             ['ü','ue'], ['ß','ss'], ['—','-'],]
    name = ''
    i = 0
    for Buchstabe in para_name:
        for Buchstabe_Gruppe in Namen:
            if Buchstabe == Buchstabe_Gruppe[0]:
                Buchstabe = Buchstabe_Gruppe[1]
        name = name + Buchstabe
    return name

# Daten in Excel schreiben
def Daten_Schreiben(path,liste):

    workbook = xlsxwriter.Workbook(path)
    worksheet = workbook.add_worksheet()

    for col in range(len(liste[0])):
        for row in range(len(liste)):
            cell = Name_Aendern(liste[row][col])
            worksheet.write(row, col,cell)


    workbook.close()

def NEW_Liste(para_name,old_list):
    new_list = []
    for item_list in old_list:
        if item_list[0] == para_name:
            new_list.append(item_list)
    return new_list

liste = []

for item in out:
    category = item.Family.FamilyCategory.Name
    Family = item.Family.Name
    type = item.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
    liste.append([category,Family,type])



path = rpw.ui.forms.TextInput('Excel-Adresse: ', default = 'C:\\Users\\werksstudent\\Desktop\\test.xlsx')

if forms.alert('Familien Filtern', ok=False, yes=True, no=True):
    Kategorie = rpw.ui.forms.TextInput('Kategorie: ', default = 'HLS-Bauteile')
    liste = NEW_Liste(Kategorie,liste)


new_list = sorted(liste, key=itemgetter(1,2))

output.print_table(
    table_data=new_list,
    title="Familien",
    columns=['Kategorie', 'Name', 'Typ']
)


Daten_Schreiben(path,new_list)

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
