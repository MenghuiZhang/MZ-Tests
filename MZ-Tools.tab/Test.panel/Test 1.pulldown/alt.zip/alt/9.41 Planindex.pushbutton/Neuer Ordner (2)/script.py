# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
import time
from Autodesk.Revit.DB import Transaction

start = time.time()


__title__ = "9.41 MFC_Planindex"
__doc__ = """MFC_Planindex"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

# MEP Räume aus aktueller Projekt
Plankoefte_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
    .WhereElementIsNotElementType()
Plankoefte = Plankoefte_collector.ToElementIds()

plaene_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_Sheets) \
    .WhereElementIsNotElementType()
plaene = plaene_collector.ToElementIds()


def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value

collector = []
for j in Plankoefte_collector:
    for i in plaene_collector:
        if get_value(i.LookupParameter('Plannummer')) == get_value(j.LookupParameter('Plannummer')):
            collector.append([i,j])
            break

with forms.ProgressBar(title='{value}/{max_value} Planindex',
                       cancellable=True, step=5) as pb:
    n = 0

    t = Transaction(doc, "Planindex")
    t.Start()


    def Vorabzug(input_para):
        out = 'P'
        if input_para == True:
            out = 'V'
        return out
    def Neunummer(indexnummer):
        index = '00'
        if indexnummer:
            if len(indexnummer) == 1:
                index = '0' + str(indexnummer)
            elif len(indexnummer) == 2:
                index = str(indexnummer)
        return index

    list = []
    for Item in collector:
        if pb.cancelled:
            script.exit()
        n += 1
        pb.update_progress(n, len(collector))
        Nummer = get_value(Item[0].LookupParameter('Plannummer'))
        tempel = get_value(Item[1].Symbol.LookupParameter('Vorabzugsstempel'))
        if not tempel:
            tempel = get_value(Item[1].LookupParameter('Vorabzugsstempel'))
        V_or_P = Vorabzug(tempel)
        Index = get_value(Item[0].LookupParameter('Aktuelle Änderung'))
        Neu_Index = Neunummer(Index)

        if len(Nummer) > 10:
            KN01 = Nummer[:len(Nummer) - 3]
            Neu_Nummer = KN01 + V_or_P + Neu_Index
            if Neu_Nummer in list:
                logger.error('{} ist bereits verwendet. Aktuelle Nummer: {}'.format(Neu_Nummer,Nummer))
            else:
                if Item[0].LookupParameter('Plannummer'):
                    Item[0].LookupParameter('Plannummer').Set(Neu_Nummer)
                    list.append(Neu_Nummer)
    t.Commit()


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
