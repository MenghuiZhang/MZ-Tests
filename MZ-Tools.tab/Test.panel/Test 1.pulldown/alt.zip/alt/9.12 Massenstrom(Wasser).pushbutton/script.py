# coding: utf8

import xlrd
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "9.12 Vereinheitlichen_Massenstrom(Wasser)"
__doc__ = """Massenstrom vereinheitlichen(HLS-Bauteile)"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

from pyIGF_logInfo import getlog
getlog(__title__)


uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

bauteile_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment)\
    .WhereElementIsNotElementType()
bauteile = bauteile_collector.ToElementIds()

logger.info("{} HLS Bauteile ausgewählt".format(len(bauteile)))

if not bauteile:
    logger.error("Keine HLS Bauteile in aktueller Projekt gefunden")
    script.exit()


def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value


Param_List = ['Volumenstrom','Massenstrom (R)','User_Massenstrom','CAx_HZK_Durchfluss',
              'Massenstrom (H)','Massenstrom (K)','Massenstrom (KO)','LIN_CO_CV_VALUE_RTV',
              'LIN_CO_CV_VALUE_THV','LIN_CO_FLOWRATE']

def Familien_Liste(Familie):
    familie_liste = []
    for item in Familie:
        Volumenstrom = 0
        for para in Param_List:
            if item.LookupParameter(para):
                Volu = get_value(item.LookupParameter(para))
                if Volumenstrom <= Volu:
                    Volumenstrom = Volu
        id = item.Id
        familie_liste.append([id,Volumenstrom])

    output.print_table(
        table_data=familie_liste,
        title="familie_liste",
        columns=['ID', 'Volumenstrom', ]
    )
    return familie_liste
# Schächte von Lüftung übernehmen
def Daten_Schreiben(Familie,Familie_Id,LISTE):
    with forms.ProgressBar(title='{value}/{max_value} Massenstrom schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Massenstrom vereinheitlichen")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))

            ID = Item.Id
            for ele in LISTE:
                if ID == ele[0]:
                    Item.LookupParameter('IGF_HLS_Volumenstrom').SetValueString(str(ele[1]))
                    logger.info('ID: {}, Volumenstrom: {}'.format(ele[0],ele[1]))

        t.Commit()


HLS_BT = Familien_Liste(bauteile_collector)
if forms.alert('Volumenstrom vereinheitlichen?', ok=False, yes=True, no=True):
    Daten_Schreiben(bauteile_collector,bauteile,HLS_BT)


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
