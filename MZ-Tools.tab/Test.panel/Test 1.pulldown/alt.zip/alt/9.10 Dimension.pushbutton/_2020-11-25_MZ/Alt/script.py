# coding: utf8

import xlrd
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "Sanitärinstallationen"
__doc__ = """Kostengruppe in Modell schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

PlumbingFixtures_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_PlumbingFixtures) \
    .WhereElementIsNotElementType()
PlumbingFixtures = PlumbingFixtures_collector.ToElementIds()


logger.info("{} Sanitärinstallationen ausgewählt".format(len(PlumbingFixtures)))

if not PlumbingFixtures:
    logger.error("Keine Sanitärinstallationen in aktueller Projekt gefunden")
    script.exit()

# Daten einlesen
path = "R:\\Vorlagen\\_IGF\\Revit_Parameter\\IGF_Kostengruppen.xlsx"

book = xlrd.open_workbook(path)
sheet = book.sheet_by_name('Sanitaerinstallationen')
rows = sheet.nrows
cols = sheet.ncols
Col = []
for row in range(rows):


    Row = []
    for col in range(cols):
        cell = sheet.cell_value(row,col)

        Row.append(cell)

    Col.append(Row)

Daten = []
for i in range(1,len(Col)):
    Daten.append(Col[i])

output.print_table(
    table_data=Daten,
    title="Daten aus Excel",
    columns=Col[0]
)

Namen = [
        ['Ä','Ae'],
        ['Ü','Ue'],
        ['Ö','Oe'],
        ['ä','ae'],
        ['ö','oe'],
        ['ü','ue'],
        ['—','-'],
        ['ß','ss'],

]
# Schächte von Lüftung übernehmen + Abfrage
if forms.alert('Kostengruppen schreiben?', ok=False, yes=True, no=True):

    with forms.ProgressBar(title='{value}/{max_value} Kostengruppen schreiben',
                           cancellable=True, step=10) as pb1:
        n = 0

        t = Transaction(doc, "Kostengruppen für Sanitärinstallationen schreiben")
        t.Start()

        for San_Einrichtungen in PlumbingFixtures_collector:

            if pb1.cancelled:
                script.exit()

            n += 1

            pb1.update_progress(n, len(PlumbingFixtures))

            Familie = San_Einrichtungen.get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_PARAM).AsValueString()
            FamilieName = ''
            for Buchstabe in Familie:
                for aendern in Namen:
                    if Buchstabe == aendern[0]:
                        Buchstabe = aendern[1]
                FamilieName = FamilieName + Buchstabe

            for KG in Daten:
                if FamilieName == KG[0] and KG[1]:
                    San_Einrichtungen.LookupParameter("IGF_HLS_KG_Familie").Set(int(KG[1]))


        t.Commit()

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
