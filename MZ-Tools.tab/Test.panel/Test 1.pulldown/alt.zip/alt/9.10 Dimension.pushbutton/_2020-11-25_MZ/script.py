# coding: utf8

import xlrd
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "Massenstrom"
__doc__ = """Massenstrom vereinheitlichen"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

bauteile_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment)\
    .WhereElementIsNotElementType()
bauteile = bauteile_collector.ToElementIds()

logger.info("{} HLS Bauteile ausgewählt".format(len(bauteile)))

if not bauteile:
    logger.error("Keine HLS Bauteile in aktueller Projekt gefunden")
    script.exit()
if not bauteile:
    logger.error("Keine Rohrzubehör in aktueller Projekt gefunden")
    script.exit()

def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value
def Parameter(element,Para):
    Wert = 0
    parameter = element.LookupParameter('Para')
    if parameter:
        Wert = get_value(parameter)
    return Wert

def Pruefung(Liste):
    Massenstrom = 0
    for ele in Liste:
        if ele != 0:
            Massenstrom = ele
    return Massenstrom

def Familien_Liste

# Schächte von Lüftung übernehmen
def Daten_Schreiben(Familie,Familie_Id,KG_Familie):
    with forms.ProgressBar(title='{value}/{max_value} Kostengruppen schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Massenstrom vereinheitlichen")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))

            Familie_Name = Item.get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_PARAM).AsValueString()
            FamilieName = Name_Aendern(str(Familie_Name))
            Familie_Typ = Item.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
            FamilieTyp = Name_Aendern(str(Familie_Typ))

            logger.info('Familie: {}, Typ: {}'.format(Familie_Name,Familie_Typ))

            for KG in KG_Familie:
                if FamilieName == KG[1] and FamilieTyp == KG[2] and KG[3]:
                    Item.LookupParameter("IGF_HLS_KG_Familie").Set(int(KG[3]))
        t.Commit()



Rohrzubehoer_Liste = Daten_einlesen('Familien','Rohrzubehoer')
if forms.alert('Kostengruppen schreiben?', ok=False, yes=True, no=True):
    Daten_Schreiben(Rohrzubehoer_collector,Rohrzubehoer,Rohrzubehoer_Liste)


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
