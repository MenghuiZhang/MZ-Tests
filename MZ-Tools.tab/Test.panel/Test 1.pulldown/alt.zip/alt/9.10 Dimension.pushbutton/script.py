# coding: utf8

import xlrd
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "9.10 Vereinheitlichen_Dimension"
__doc__ = """Dimension vereinheitlichen(Luftdurchlässe, HLS-Bauteile)"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

from pyIGF_logInfo import getlog
getlog(__title__)


uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

# Luftauslässe
Luftauslaesse_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctTerminal)\
    .WhereElementIsNotElementType()
Luftauslaesse = Luftauslaesse_collector.ToElementIds()

logger.info("{} Luftauslässe ausgewählt".format(len(Luftauslaesse)))

# HLS-Bauteile
bauteile_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment)\
    .WhereElementIsNotElementType()
bauteile = bauteile_collector.ToElementIds()

logger.info("{} HLS Bauteile ausgewählt".format(len(bauteile)))

def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value

def Familien_Liste(Familie):
    familie_liste = []
    for item in Familie:
        Volumenstrom = 0
        for para in Param_List:
            if item.LookupParameter(para):
                Volu = get_value(item.LookupParameter(para))
                if Volumenstrom <= Volu:
                    Volumenstrom = Volu
        id = item.Id
        familie_liste.append([id,Volumenstrom])

    output.print_table(
        table_data=familie_liste,
        title="familie_liste",
        columns=['ID', 'Volumenstrom', ]
    )
    return familie_liste

# Dimension schreiben
def Luft_auslass(Familie,Familie_Id):
    with forms.ProgressBar(title='{value}/{max_value} Dimension schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Dimension vereinheitlichen")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))
            def wertschreiben_Exemplar(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Exemplarparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.LookupParameter(alt):
                    wert = get_value(Item.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))

            wertschreiben_Exemplar('CAX_HLSE_Höhe','IGF_RLT_Höhe')
            wertschreiben_Exemplar('CAx_HLSE_Breite','IGF_RLT_Breite')
            wertschreiben_Exemplar('CAx_HLSE_Länge','IGF_RLT_Länge')

        t.Commit()
# Dimension schreiben
def HLS_bauteile(Familie,Familie_Id):
    with forms.ProgressBar(title='{value}/{max_value} Dimension schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Dimension vereinheitlichen")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))

            def wertschreiben_Typ(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Typparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.Symbol.LookupParameter(alt):
                    wert = get_value(Item.Symbol.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))
            def wertschreiben_Exemplar(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Exemplarparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.LookupParameter(alt):
                    wert = get_value(Item.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))

            wertschreiben_Exemplar('Plattenhöhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Plattenbreite','IGF_RLT_Breite')
            wertschreiben_Exemplar('Plattenlänge','IGF_RLT_Länge')
            wertschreiben_Exemplar('CAx_HZK_Höhe','IGF_RLT_Höhe')
            wertschreiben_Exemplar('CAx_HZK_Tiefe','IGF_RLT_Breite')
            wertschreiben_Exemplar('CAx_HZK_Länge','IGF_RLT_Länge')
            wertschreiben_Exemplar('CAX_HLSE_Höhe','IGF_RLT_Höhe')
            wertschreiben_Exemplar('CAx_HLSE_Breite','IGF_RLT_Breite')
            wertschreiben_Exemplar('CAx_HLSE_Länge','IGF_RLT_Länge')
            wertschreiben_Typ('Regiesterhöhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Registerbreite','IGF_RLT_Breite')
            wertschreiben_Typ('Registerlänge','IGF_RLT_Länge')
            wertschreiben_Typ('Höhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Breite','IGF_RLT_Breite')
            wertschreiben_Typ('Länge','IGF_RLT_Länge')
            wertschreiben_Typ('Höhe Bloc','IGF_RLT_Höhe')
            wertschreiben_Typ('Breite Bloc','IGF_RLT_Breite')
            wertschreiben_Typ('Länge Bloc','IGF_RLT_Länge')
            wertschreiben_Typ('Länge Verteiler','IGF_RLT_Länge')
            wertschreiben_Typ('KA Höhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Ka Breite','IGF_RLT_Breite')
            wertschreiben_Typ('Kasten Höhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Kasten Breite','IGF_RLT_Breite')
            wertschreiben_Typ('Kasten Länge','IGF_RLT_Länge')
            wertschreiben_Exemplar('Höhe Monobloc','IGF_RLT_Höhe')
            wertschreiben_Exemplar('Breite Monobloc','IGF_RLT_Breite')
            wertschreiben_Exemplar('Länge Monobloc','IGF_RLT_Länge')
            wertschreiben_Typ('Länge Behälter','IGF_RLT_Länge')
            wertschreiben_Exemplar('Unit Width','IGF_RLT_Breite')
            wertschreiben_Exemplar('Unit Length','IGF_RLT_Länge')
            wertschreiben_Exemplar('Height','IGF_RLT_Höhe')
            wertschreiben_Typ('ltp_Height','IGF_RLT_Höhe')
            wertschreiben_Typ('ltp_Width','IGF_RLT_Breite')
            wertschreiben_Typ('ltp_Length','IGF_RLT_Länge')
            wertschreiben_Exemplar('ltp_Width','IGF_RLT_Breite')
            wertschreiben_Exemplar('lto_Depth','IGF_RLT_Länge')
            wertschreiben_Exemplar('ltp_Height','IGF_RLT_Höhe')
            wertschreiben_Typ('SBI_Achsenhöhe','IGF_RLT_Höhe')
            wertschreiben_Typ('SBI_Breite','IGF_RLT_Breite')
            wertschreiben_Typ('SBI_Länge','IGF_RLT_Länge')
            wertschreiben_Exemplar('Bautiefe','IGF_RLT_Breite')
            wertschreiben_Exemplar('Baulänge','IGF_RLT_Länge')
            wertschreiben_Exemplar('Bauhöhe','IGF_RLT_Höhe')


        t.Commit()

# HLS_BT = Familien_Liste(bauteile_collector)
if forms.alert('Dimension schreiben?', ok=False, yes=True, no=True):
    Luft_auslass(Luftauslaesse_collector,Luftauslaesse)
    HLS_bauteile(bauteile_collector,bauteile)


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
