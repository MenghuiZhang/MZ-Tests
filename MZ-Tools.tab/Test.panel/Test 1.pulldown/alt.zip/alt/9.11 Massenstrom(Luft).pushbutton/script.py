# coding: utf8

import xlrd
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "9.11 Vereinheitlichen_Massenstrom(Luft)"
__doc__ = """Massenstrom vereinheitlichen(Luftdurchlässe)"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

from pyIGF_logInfo import getlog
getlog(__title__)


uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

Luftauslaesse_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_DuctTerminal)\
    .WhereElementIsNotElementType()
Luftauslaesse = Luftauslaesse_collector.ToElementIds()

logger.info("{} Luftauslässe ausgewählt".format(len(Luftauslaesse)))

if not Luftauslaesse:
    logger.error("Keine Luftauslässe in aktueller Projekt gefunden")
    script.exit()


def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value

# Volumenstrom schreiben
def Luftauslaess(Familie,Familie_Id):
    with forms.ProgressBar(title='{value}/{max_value} Volumenstrom schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Volumenstrom vereinheitlichen")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))

            def wertschreiben_Typ(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Typparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.Symbol.LookupParameter(alt):
                    wert = get_value(Item.Symbol.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))
            def wertschreiben_Exemplar(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Exemplarparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.LookupParameter(alt):
                    wert = get_value(Item.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))

 #  Hier kann man weitere Änderungen von Parameter ergänzen.
            wertschreiben_Typ('Max. Volumenstrom', 'IGF_RLT_AuslassVolumenstromMax')
            wertschreiben_Typ('Min. Volumenstrom', 'IGF_RLT_AuslassVolumenstromMin')
            wertschreiben_Typ('Volumenstrom (L)', 'IGF_RLT_Volumenstrom')
            wertschreiben_Exemplar('Volumenstrom (L)', 'IGF_RLT_Volumenstrom')
            wertschreiben_Exemplar('Volumenstrom', 'IGF_RLT_Volumenstrom')
            wertschreiben_Exemplar('Druckverlust (L)', 'IGF_RLT_Druckverlust')
            wertschreiben_Exemplar('Geschwindigkeit', 'IGF_RLT_Geschwindigkeit')

        t.Commit()

# HLS_BT = Familien_Liste(bauteile_collector)
if forms.alert('Volumenstrom vereinheitlichen?', ok=False, yes=True, no=True):
    Luftauslaess(Luftauslaesse_collector,Luftauslaesse)



total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
