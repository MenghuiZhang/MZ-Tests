# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time

start = time.time()


__title__ = "9.00 Wanddurchbrüche"
__doc__ = """Höhe von Wanddurchbrüche berechnen"""
__authors__ = "Menghui Zhang"

__context__ = 'zero-doc'

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

from pyIGF_logInfo import getlog
getlog(__title__)



# MEP Räume aus aktueller Ansicht
HLS_Bauteile_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment) \
    .WhereElementIsNotElementType()
HLS_Bauteile = HLS_Bauteile_collector.ToElementIds()

logger.info("{} MEP Räume ausgewählt".format(len(HLS_Bauteile)))

if not HLS_Bauteile:
    logger.error("Keine Wanddurchbrüche in aktueller Projekt gefunden")
    script.exit()


def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value

t = Transaction(doc,'Höhe Schreiben')
t.Start()
with forms.ProgressBar(title='{value}/{max_value} HLS_Bauteile',
                       cancellable=True, step=10) as pb:
    n = 0
    H = 0
    for Bauteile in HLS_Bauteile_collector:
        if pb.cancelled:
            script.exit()
        n += 1
        pb.update_progress(n, len(HLS_Bauteile))

        Kenn = get_value(Bauteile.LookupParameter('Kennzeichen'))
        if get_value(Bauteile.LookupParameter('IGF_SuD_Typ')):
            H = round(Bauteile.Location.Point.Z * 304.8 , 0)
            Bauteile.LookupParameter('IGF_SuD_mittlere_Höhe').SetValueString(str(H))


        logger.info("Patikel {} Höhe {}".format(Kenn,H))

t.Commit()
total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
