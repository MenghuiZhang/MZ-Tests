# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
import time
from Autodesk.Revit.DB import Transaction

start = time.time()


__title__ = "9.60 Rohre"
__doc__ = """Raster"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

from pyIGF_logInfo import getlog
getlog(__title__)


uidoc = rpw.revit.uidoc
doc = rpw.revit.doc
active_view = doc.ActiveView

# MEP Räume aus aktueller Projekt
raster_collector = DB.FilteredElementCollector(doc,active_view.Id) \
    .OfCategory(DB.BuiltInCategory.OST_Grids)\
    .WhereElementIsNotElementType()
raster = raster_collector.ToElementIds()


ansicht = uidoc.Selection.PickObject(UI.Selection.ObjectType.Element, "Ansicht")

def getBoundingBox(inElement):
    box = inElement.get_BoundingBox(active_view)
    maxX = box.Max.X
    maxY = box.Max.Y
    maxZ = box.Max.Z
    minX = box.Min.X
    minY = box.Min.Y
    minZ = box.Min.Z
    return maxX,maxY,maxZ,minX,minY,minZ

ansicht_max_X, ansicht_max_Y,ansicht_max_Z,ansicht_min_X,ansicht_min_Y,ansicht_min_Z = getBoundingBox(ansicht)
abstand = rpw.ui.forms.TextInput('Versatz von Beschrifungszuschnitt(mm): ', default = "0")
neu_max_X = ansicht_max_X - int(abstand)/5.1535
neu_max_Y = ansicht_max_Y - int(abstand)/5.1535
neu_max_Z = ansicht_max_Z - int(abstand)/5.1535
neu_min_X = ansicht_min_X - int(abstand)/5.1535
neu_min_Y = ansicht_min_Y - int(abstand)/5.1535
neu_min_Z = ansicht_min_Z - int(abstand)/5.1535

print(neu_max_X)
print(neu_max_Y)
print(neu_max_Z)
print(neu_min_X)
print(neu_min_Y)
print(neu_min_Z)

def Richtung(inZahl1,inZahl2,inZahl3,inZahl4,inZahl5,inZahl6):
    out_Richtung = None
    X_Achse =  abs(inZahl1 - inZahl4)
    Y_Achse =  abs(inZahl2 - inZahl5)
    Z_Achse =  abs(inZahl3 - inZahl6)
    if X_Achse > 5:
        out_Richtung = 'X'
    if Y_Achse > 5:
        out_Richtung = 'Y'
    if Z_Achse > 5:
        out_Richtung = 'Z'
    return out_Richtung

def neuPoint(inZahl1,inZahl2):
    neu2 = inZahl1 - 2.14
    neu1 = inZahl2 + 2.14
    return neu1,neu2

t = Transaction(doc, 'Parameter erstellen')
t.Start()
for i in raster_collector:
    max_X,max_Y,max_Z,min_X,min_Y,min_Z = getBoundingBox(i)
    rasterRichtung = Richtung(max_X,max_Y,max_Z,min_X,min_Y,min_Z)
    if rasterRichtung == 'X':
        neu_X1,neu_X2 = neuPoint(neu_max_X,neu_min_X)
        box_raster = i.get_BoundingBox(active_view)
        box_raster.Max = DB.XYZ(neu_X2,max_Y,max_Z)
        box_raster.Min = DB.XYZ(neu_X1,min_Y,min_Z)
    elif rasterRichtung == 'Y':
        neu_Y1,neu_Y2 = neuPoint(neu_max_Y,neu_min_Y)
        box_raster = i.get_BoundingBox(active_view)
        box_raster.Max = DB.XYZ(max_X,neu_Y2,max_Z)
        box_raster.Min = DB.XYZ(min_X,neu_Y1,min_Z)
    elif rasterRichtung == 'Z':
        neu_Z1,neu_Z2 = neuPoint(neu_max_Z,neu_min_Z)
        box_raster = i.get_BoundingBox(active_view)
        box_raster.Max = DB.XYZ(max_X,max_Y,neu_Z2)
        box_raster.Min = DB.XYZ(min_X,min_X,neu_Z1)

t.Commit()

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
