# coding: utf8
from pyrevit import script, forms
from rpw import *
import time
import clr
from Autodesk.Revit.DB import Transaction

import System
import xlsxwriter

start = time.time()


__title__ = "9.34 ParameterExportieren"
__doc__ = """SharedParameter und ProjektParameter in Excel schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc
app = revit.app
uiapp = revit.uiapp


filename = app.SharedParametersFilename
file = app.OpenSharedParameterFile()


def AktuellParameter(inputfile):
    aktuellshpa = []
    for dg in inputfile.Groups:
        for d in dg.Definitions:
            name = d.Name
            owner = d.OwnerGroup.Name
            TYPE = d.ParameterType.ToString()
            guid = d.GUID.ToString()
            type = DB.LabelUtils.GetLabelFor(d.ParameterType)
            commen = ['Text','Ganzzahl','Zahl','Länge','Fläche','Volumen','Winkel','Neigung','Währung','Massendichte',
                      'Zeit','Geschwindigkeit','URL','Material','Bild','Ja/Nein','Mehrzeiliger Text']
            Energie = ['Energie','Wärmedurchgangskoeffizient','Thermischer Widerstand','Thermisch wirksame Masse',
                       'Wärmeleitfähigkeit','Spezifische Wärme','Spezifische Verdunstungswärme','Permeabilität']
            dis = None
            if type in commen:
                dis = 'Allgemein'
            elif type in Energie:
                dis = 'Energie'
            else:
                dis = 'Tragwerk'

            if TYPE[:3] == 'HVA':
                dis = 'Lüftung'
            elif TYPE[:3] == 'Pip':
                dis = 'Rohre'
            elif TYPE[:3] == 'Ele':
                dis = 'Elektro'
            else:
                pass
            if name == 'HVACEnergy':
                dis = 'Energie'

            definition = [owner,name,guid,dis,type]
            aktuellshpa.append(definition)
    aktuellshpa.sort()
    if any(aktuellshpa):
        output.print_table(
            table_data=aktuellshpa,
            title="Aktuelle SharedParameters",
            columns=['DefinitionGroup', 'Name', 'GUID','Disziplin', 'Type']
        )

    return aktuellshpa
def projektparameter():
    map = doc.ParameterBindings
    dep = map.ForwardIterator()
    List = []
    while(dep.MoveNext()):
        definition = dep.Key
        Name = definition.Name
        Typ = DB.LabelUtils.GetLabelFor(definition.ParameterType)
        Group_ = DB.LabelUtils.GetLabelFor(definition.ParameterGroup)
        cateName = ''
        Binding = dep.Current
        Type = Binding.GetType().ToString()
        typOrex = None
        if Type == 'Autodesk.Revit.DB.InstanceBinding':
            typOrex = 'Exemplar'
        else:
            typOrex = 'Type'
        if Binding:
            cates = Binding.Categories
            for cate in cates:
                cateName = cate.Name + ',' + cateName
        List.append([Name,Typ,cateName,typOrex,Group_])
    List.sort()
    if any(List):
        output.print_table(
            table_data=List,
            title="Aktuelle Projectparameter",
            columns=['Name', 'Type','Kategorie','Typ or Exemplar','ParameterGroup']
        )
    return List
def ZweiList(Liste1,Liste2):
    OutListe = []
    for i in Liste1:
        for j in Liste2:
            if i[1] == j[0]:
                OutListe.append([i[0],i[1],i[2],i[3],i[4],j[4],j[2],j[3]])
    if any(OutListe):
        output.print_table(
            table_data=OutListe,
            title="ProjektParameter aus SharedParameter",
            columns=['DefinitionGroup', 'Name','Disziplin','GUID','ParameterTyp','ParameterGroup','Kategorie','Typ or Exemplar'])
    return OutListe

def Group(inListe):
    outliste = [i[0] for i in inListe]
    outliste = set(outliste)
    outliste = list(outliste)
    return outliste

def excel(inpath,inListe,groupliste,column):
    liste1 = []
    workbook = xlsxwriter.Workbook(inpath)
    for i in groupliste:
        list = [column]
        for j in inListe:
            if j[0] == i:
                list.append(j)
        liste1.append(list)
    for item in liste1:
        worksheet = workbook.add_worksheet(item[1][0])
        for row in range(len(item)):
            for col in range(len(item[row])):
                worksheet.write(row, col, item[row][col])
    workbook.close()

def excel2(inpath,inListe,column):
    inListe.insert(0,column)
    workbook = xlsxwriter.Workbook(inpath)
    a = 0
    worksheet = workbook.add_worksheet()

    for row in inListe:
        for col in range(len(row)):
            worksheet.write(a, col, row[col])
        a += 1


    workbook.close()



aktuPara = AktuellParameter(file)
ProPara = projektparameter()
final = ZweiList(aktuPara,ProPara)
group_shared = Group(aktuPara)
group_final = Group(final)
path1 = 'R:\\Vorlagen\\_IGF\Revit_Parameter\\PROJEKT_SharedParameter.xlsx'
path2 = 'R:\\Vorlagen\\_IGF\Revit_Parameter\\PROJEKT_ProjektParameter.xlsx'
path3 = 'R:\\Vorlagen\\_IGF\Revit_Parameter\\PROJEKT_Projekt_Sharedparameter.xlsx'
excel(path1,aktuPara,group_shared,['Group', 'Name', 'Disziplin', 'Type'])
excel2(path2,ProPara,['Name', 'Type','Kategorie','Typ or Exemplar','ParameterGroup'])
excel(path3,final,group_final,['Group', 'Name','Disziplin','Typ','ParameterGroup','Kategorie','Typ or Exemplar'])

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))

