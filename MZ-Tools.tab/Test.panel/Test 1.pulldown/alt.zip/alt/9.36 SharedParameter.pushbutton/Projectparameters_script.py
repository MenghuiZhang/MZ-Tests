# coding: utf8
from pyrevit import script, forms
from rpw import *
import time
from Autodesk.Revit.DB import Transaction

import System
import clr
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel

start = time.time()


__title__ = "9.33 Parameter_Überprüfen"
__doc__ = """Überprüfen, ob der Parameter im Projektparameter und im SharedParameter vorhanden ist"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

from pyIGF_logInfo import getlog
getlog(__title__)


uidoc = revit.uidoc
doc = revit.doc
app = revit.app
uiapp = revit.uiapp

ex = Excel.ApplicationClass()
ex.Visible = True
filename = app.SharedParametersFilename
file = app.OpenSharedParameterFile()

def AktuellSharedPara(inputfile):
    aktuellSharedPara = []
    for dg in inputfile.Groups:
        for d in dg.Definitions:
            name = d.Name
            owner = d.OwnerGroup.Name
            TYPE = d.ParameterType.ToString()
            type = DB.LabelUtils.GetLabelFor(d.ParameterType)
            commen = ['Text','Ganzzahl','Zahl','Länge','Fläche','Volumen','Winkel','Neigung','Währung','Massendichte',
                      'Zeit','Geschwindigkeit','URL','Material','Bild','Ja/Nein','Mehrzeiliger Text']
            Energie = ['Energie','Wärmedurchgangskoeffizient','Thermischer Widerstand','Thermisch wirksame Masse',
                       'Wärmeleitfähigkeit','Spezifische Wärme','Spezifische Verdunstungswärme','Permeabilität']
            dis = None
            if type in commen:
                dis = 'Allgemein'
            elif type in Energie:
                dis = 'Energie'
            else:
                dis = 'Tragwerk'

            if TYPE[:3] == 'HVA':
                dis = 'Lüftung'
            elif TYPE[:3] == 'Pip':
                dis = 'Rohre'
            elif TYPE[:3] == 'Ele':
                dis = 'Elektro'
            else:
                pass
            if name == 'HVACEnergy':
                dis = 'Energie'

            definition = [owner,name,dis,type]
            aktuellSharedPara.append(definition)
    aktuellSharedPara.sort()
    if any(aktuellSharedPara):
        output.print_table(
            table_data=aktuellSharedPara,
            title="Aktuelle SharedParameters",
            columns=['Group', 'Name', 'Disziplin', 'ParameterType']
        )

    return aktuellSharedPara

def AktuellProjektPara():
    map = doc.ParameterBindings
    dep = map.ForwardIterator()
    Liste = []
    while(dep.MoveNext()):
        definition = dep.Key
        Name = definition.Name
        Typ = DB.LabelUtils.GetLabelFor(definition.ParameterType)
        Group = DB.LabelUtils.GetLabelFor(definition.ParameterGroup)
        cateName = ''
        Binding = dep.Current
        Type = Binding.GetType().ToString()
        typOrex = None
        if Type == 'Autodesk.Revit.DB.InstanceBinding':
            typOrex = 'Exemplar'
        else:
            typOrex = 'Type'
        if Binding:
            cates = Binding.Categories
            for cate in cates:
                cateName = cate.Name + ',' + cateName
        Liste.append([Name,Typ,cateName,typOrex,Group])
    Liste.sort()
    if any(Liste):
        output.print_table(
            table_data=Liste,
            title="Aktuelle Projectparameter",
            columns=['Name', 'Type','categories','Typ or Exemplar','Group']
        )
    return Liste

def AktuSharProPara(SharedListe,ProjektListe):
    OutListe = []
    for i in SharedListe:
        for j in ProjektListe:
            if i[1] == j[0]:
                OutListe.append([i[0],i[1],i[2],i[3],j[4],j[2],j[3]])
    if any(OutListe):
        output.print_table(
            table_data=OutListe,
            title="ProjektParameter aus SharedParameter",
            columns=['Group', 'Name','Disziplin','ParameterTyp','ParameterGroup','Kategorie','Typ or Exemplar'])
    return OutListe


aktuSharedPara = AktuellSharedPara(file)
aktuProjektPara = AktuellProjektPara()
aktuSharProPara = AktuSharProPara(aktuSharedPara,aktuProjektPara)

sharedDefinitionListe = [i[1] for i in aktuSharedPara]
sharproDefinitionListe = [i[1] for i in aktuSharProPara]

excelPath = rpw.ui.forms.TextInput('Excel: ', default = "R:\\Vorlagen\\_IGF\\Revit_Parameter\\IGF_SharedParameter.xlsx")
book = ex.Workbooks.Open(excelPath)

for sheet in book.Worksheets:
    Gname = sheet.Name
    title = '{value}/{max_value} ' + Gname
    with forms.ProgressBar(title=title, cancellable=True, step=5) as pb:
        n = 0
    if not Gname in ['Hinweis', 'Revit (Original)']:
        rows = sheet.UsedRange.Rows.Count
        for row in range(2, rows + 1):
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, rows - 1)
            if sheet.Cells[row, 3].Value2 in sharproDefinitionListe:
                sheet.Cells[row, 2] = 'Beide'
            elif sheet.Cells[row, 3].Value2 in sharedDefinitionListe:
                sheet.Cells[row, 2] = 'Shared'
            else:
                sheet.Cells[row, 2] = None


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
