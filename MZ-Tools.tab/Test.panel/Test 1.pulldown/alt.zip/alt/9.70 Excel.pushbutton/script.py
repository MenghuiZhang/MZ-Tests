# coding: utf8
import clr
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel
import time
from pyrevit import script, forms
from rpw import *
import System


start = time.time()

__title__ = "9.70 Excel"
__doc__ = """die Informationen der Projekt- und SharedParameter zu Excel Exportieren"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()


from pyIGF_logInfo import getlog
getlog(__title__)


def ExcelLesen(inExcelPath):
    outListe = []
    book = exapp.Workbooks.Open(inExcelPath)
    for sheet in book.Worksheets:
        groupName = sheet.Name
        if groupName == 'Tabelle1':
            for row in range(1, 126):
                System = None
                Farbe = None
                R = None
                G = None
                B = None
                System = sheet.UsedRange.Cells[row, 1].Value2
                Farbe = sheet.UsedRange.Cells[row, 2].Value2
                print(System,Farbe)
                if Farbe == 'rot':
                    Farbe = '255 0 0'
                elif Farbe == 'grün':
                    Farbe = '0 255 0'
                if Farbe:
                    try:
                        R = Farbe.split(' ')[0]
                        G = Farbe.split(' ')[1]
                        B = Farbe.split(' ')[2]
                    except Exception as e:
                        R = Farbe.split(',')[0]
                        G = Farbe.split(',')[1]
                        B = Farbe.split(',')[2]



                if System and Farbe:
                    outListe.append([System,Farbe,R,G,B])


    book.Save()
    book.Close()
    output.print_table(
        table_data=outListe,
        title="SystemFarbe",
        columns=["System", "Farbe", "R", "G", "B",]
    )

    return outListe

def Liste2Dict(Liste):
    outdict = {}
    for ele in Liste:
        outdict[ele[0]] = [ele[1],ele[2],ele[3],ele[4]]
    return outdict

def ExcelSchreiben(inExcelPath,Dict):
    book = exapp.Workbooks.Open(inExcelPath)
    for sheet in book.Worksheets:
        groupName = sheet.Name
        rows = sheet.UsedRange.Rows.Count
        if groupName == 'Familien':
            for row in range(2, rows+1):
                System = sheet.UsedRange.Cells[row, 2].Value2
                if System in Dict.keys():
                    sheet.Cells[row,6] = Dict[System][0]
                    sheet.Cells[row,7] = Dict[System][1]
                    sheet.Cells[row,8] = Dict[System][2]
                    sheet.Cells[row,9] = Dict[System][3]

    book.Save()
    book.Close()


excelPath1 = "R:\\Vorlagen\\_IGF\\_Material\\IGF_Material.xlsx"
excelPath2 = "C:\\Users\\Zhang\\Desktop\\Test.xlsx"
exapp = Excel.ApplicationClass()
exapp.Visible = False
Daten = ExcelLesen(excelPath2)
farbeDict = Liste2Dict(Daten)
ExcelSchreiben(excelPath1,farbeDict)


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
