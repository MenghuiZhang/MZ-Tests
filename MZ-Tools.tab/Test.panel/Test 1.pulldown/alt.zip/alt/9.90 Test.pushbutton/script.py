# coding: utf8
from pyIGF_lib import AlleElementInAnsicht,AlleElementInDocument
import rpw


__title__ = "9.90 test"
__doc__ = """Leistung, Druckverlust, Massenstrom von DeS in IGF-Parameter schreiben"""
__author__ = "Menghui Zhang"
doc = rpw.revit.doc

liste,FamilieName = AlleElementInAnsicht()
for id in liste:
    elem = doc.GetElement(id)
print("In dieser Ebene sind {} {} installiert".format(len(liste),FamilieName))


from pyIGF_logInfo import getlog
getlog(__title__)
