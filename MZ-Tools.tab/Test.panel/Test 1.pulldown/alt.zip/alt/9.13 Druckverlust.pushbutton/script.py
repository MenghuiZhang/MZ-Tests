# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import *
import rpw
import time
import clr

start = time.time()

__title__ = "9.13 Vereinheitlichen_Druckverlust"
__doc__ = """Druckverlust vereinheitlichen(Luftdurchlässe, HLS-Bauteile, Lufukanal- und Rohrzubehör)"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

from pyIGF_logInfo import getlog
getlog(__title__)


# Luftauslässe
Luftauslaesse_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctTerminal).WhereElementIsNotElementType()
Luftauslaesse = Luftauslaesse_collector.ToElementIds()

logger.info("{} Luftauslässe ausgewählt".format(len(Luftauslaesse)))

# HLS-Bauteile
bauteile_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType()
bauteile = bauteile_collector.ToElementIds()
logger.info("{} HLS Bauteile ausgewählt".format(len(bauteile)))

# Rohrzubehör
Rohrzubehoer_collector = DB.FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipeAccessory).WhereElementIsNotElementType()
Rohrzubehoer = Rohrzubehoer_collector.ToElementIds()
logger.info("{} Luftauslässe ausgewählt".format(len(Rohrzubehoer)))

# Luftkanalzubehör
Luftkanalzubehoer_collector = DB.FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctAccessory).WhereElementIsNotElementType()
Luftkanalzubehoer = Luftkanalzubehoer_collector.ToElementIds()
logger.info("{} HLS Bauteile ausgewählt".format(len(Luftkanalzubehoer)))

def get_value(param):
    value = revit.query.get_param_value(param)
    try:
        unit = param.DisplayUnitType
        value = DB.UnitUtils.ConvertFromInternalUnits(value,unit)
    except Exception as e:
        pass
    return value

# Dimension schreiben
def DatenSchreiben(Familie,Familie_Id,Kate):
    title = '{value}/{max_value} ' + Kate
    with forms.ProgressBar(title=title,cancellable=True, step=10) as pb:
        n = 0
        t = Transaction(doc, "Druckverlust vereinheitlichen")
        t.Start()
        for el in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))
            druckverlust = [None,None,None,None]
            if el.LookupParameter('SBI_Breite'):
                druckverlust[0] = get_value(el.LookupParameter('SBI_Breite'))
            if el.LookupParameter('SBI_Breite'):
                druckverlust[1] = get_value(el.LookupParameter('SBI_Breite'))
            if el.LookupParameter('SBI_Breite'):
                druckverlust[2] = get_value(el.LookupParameter('SBI_Breite'))
            if el.LookupParameter('SBI_Breite'):
                druckverlust[3] = get_value(el.LookupParameter('SBI_Breite'))
            if druckverlust[0] and druckverlust[2] and druckverlust[0] == druckverlust[2]:
                el.LookupParameter('IGF_Druckverlust').SetValueString(str(wert))



            def wertschreiben_Exemplar(alt,neu):
                wert = None
                if Item.LookupParameter(alt):
                    wert = get_value(Item.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))

            wertschreiben_Exemplar('CAX_HLSE_Höhe','IGF_RLT_Höhe')
            wertschreiben_Exemplar('CAx_HLSE_Breite','IGF_RLT_Breite')
            wertschreiben_Exemplar('CAx_HLSE_Länge','IGF_RLT_Länge')

        t.Commit()

# Dimension schreiben
def Luft_auslass(Familie,Familie_Id):
    with forms.ProgressBar(title='{value}/{max_value} Dimension schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Dimension vereinheitlichen")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))
            def wertschreiben_Exemplar(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Exemplarparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.LookupParameter(alt):
                    wert = get_value(Item.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))

            wertschreiben_Exemplar('CAX_HLSE_Höhe','IGF_RLT_Höhe')
            wertschreiben_Exemplar('CAx_HLSE_Breite','IGF_RLT_Breite')
            wertschreiben_Exemplar('CAx_HLSE_Länge','IGF_RLT_Länge')

        t.Commit()
# Dimension schreiben
def HLS_bauteile(Familie,Familie_Id):
    with forms.ProgressBar(title='{value}/{max_value} Dimension schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Dimension vereinheitlichen")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))

            def wertschreiben_Typ(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Typparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.Symbol.LookupParameter(alt):
                    wert = get_value(Item.Symbol.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))
            def wertschreiben_Exemplar(alt,neu):
                '''
                Wert von alte Typparameter in neue Exemplarparameter schreiben

                alt: alte Exemplarparameter
                neu: neue Exemplarparameter
                '''
                wert = None
                if Item.LookupParameter(alt):
                    wert = get_value(Item.LookupParameter(alt))
                    Item.LookupParameter(neu).SetValueString(str(wert))

            wertschreiben_Exemplar('Plattenhöhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Plattenbreite','IGF_RLT_Breite')
            wertschreiben_Exemplar('Plattenlänge','IGF_RLT_Länge')
            wertschreiben_Exemplar('CAx_HZK_Höhe','IGF_RLT_Höhe')
            wertschreiben_Exemplar('CAx_HZK_Tiefe','IGF_RLT_Breite')
            wertschreiben_Exemplar('CAx_HZK_Länge','IGF_RLT_Länge')
            wertschreiben_Exemplar('CAX_HLSE_Höhe','IGF_RLT_Höhe')
            wertschreiben_Exemplar('CAx_HLSE_Breite','IGF_RLT_Breite')
            wertschreiben_Exemplar('CAx_HLSE_Länge','IGF_RLT_Länge')
            wertschreiben_Typ('Regiesterhöhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Registerbreite','IGF_RLT_Breite')
            wertschreiben_Typ('Registerlänge','IGF_RLT_Länge')
            wertschreiben_Typ('Höhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Breite','IGF_RLT_Breite')
            wertschreiben_Typ('Länge','IGF_RLT_Länge')
            wertschreiben_Typ('Höhe Bloc','IGF_RLT_Höhe')
            wertschreiben_Typ('Breite Bloc','IGF_RLT_Breite')
            wertschreiben_Typ('Länge Bloc','IGF_RLT_Länge')
            wertschreiben_Typ('Länge Verteiler','IGF_RLT_Länge')
            wertschreiben_Typ('KA Höhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Ka Breite','IGF_RLT_Breite')
            wertschreiben_Typ('Kasten Höhe','IGF_RLT_Höhe')
            wertschreiben_Typ('Kasten Breite','IGF_RLT_Breite')
            wertschreiben_Typ('Kasten Länge','IGF_RLT_Länge')
            wertschreiben_Exemplar('Höhe Monobloc','IGF_RLT_Höhe')
            wertschreiben_Exemplar('Breite Monobloc','IGF_RLT_Breite')
            wertschreiben_Exemplar('Länge Monobloc','IGF_RLT_Länge')
            wertschreiben_Typ('Länge Behälter','IGF_RLT_Länge')
            wertschreiben_Exemplar('Unit Width','IGF_RLT_Breite')
            wertschreiben_Exemplar('Unit Length','IGF_RLT_Länge')
            wertschreiben_Exemplar('Height','IGF_RLT_Höhe')
            wertschreiben_Typ('ltp_Height','IGF_RLT_Höhe')
            wertschreiben_Typ('ltp_Width','IGF_RLT_Breite')
            wertschreiben_Typ('ltp_Length','IGF_RLT_Länge')
            wertschreiben_Exemplar('ltp_Width','IGF_RLT_Breite')
            wertschreiben_Exemplar('lto_Depth','IGF_RLT_Länge')
            wertschreiben_Exemplar('ltp_Height','IGF_RLT_Höhe')
            wertschreiben_Typ('SBI_Achsenhöhe','IGF_RLT_Höhe')
            wertschreiben_Typ('SBI_Breite','IGF_RLT_Breite')
            wertschreiben_Typ('SBI_Länge','IGF_RLT_Länge')
            wertschreiben_Exemplar('Bautiefe','IGF_RLT_Breite')
            wertschreiben_Exemplar('Baulänge','IGF_RLT_Länge')
            wertschreiben_Exemplar('Bauhöhe','IGF_RLT_Höhe')


        t.Commit()

# HLS_BT = Familien_Liste(bauteile_collector)
if forms.alert('Dimension schreiben?', ok=False, yes=True, no=True):
    Luft_auslass(Luftauslaesse_collector,Luftauslaesse)
    HLS_bauteile(bauteile_collector,bauteile)


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
