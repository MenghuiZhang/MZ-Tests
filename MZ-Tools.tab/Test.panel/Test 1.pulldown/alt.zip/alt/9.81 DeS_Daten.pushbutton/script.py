# coding: utf8
import clr
import time
from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
from Autodesk.Revit.DB import *

start = time.time()

__title__ = "9.81 DeS_Verbinder_Leistung"
__doc__ = """Leistung, Druckverlust, Massenstrom von DeS in IGF-Parameter schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc


from pyIGF_logInfo import getlog
getlog(__title__)


HLS_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType()
HLS = HLS_collector.ToElementIds()
HLS_collector.Dispose()


def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value

phase = list(doc.Phases)[0]
DeS = {}
RaumListe = {}
for id in HLS:
    hls = doc.GetElement(id)
    try:
        Raumnummer = hls.Space[phase].Number
        be = hls.Symbol.LookupParameter('Beschreibung').AsString()
        if be == 'Heiz- und Kühlsegel':
            DeS[id] = Raumnummer
        else:
            pass
        if Raumnummer in RaumListe.keys():
            RaumListe[Raumnummer].append(id)
        else:
            RaumListe[Raumnummer] = [id]
    except Exception as e:
        logger.error(e)


# t = Transaction(doc,'DeS')
# t.Start()
# with forms.ProgressBar(title='{value}/{max_value} Daten schreiben',cancellable=True, step=1) as pb:
#     n_1 = 0
#     for eleid in DeS.keys():
#         if pb.cancelled:
#             script.exit()
#         n_1 += 1
#         pb.update_progress(n_1, len(DeS.keys()))
#         el = doc.GetElement(eleid)
#         print(30*'--')
#         print(el.Symbol.FamilyName)
#         el = doc.GetElement(eleid)
#         if el.Symbol.FamilyName == '_K_IGF_435_Deckensegelverbinder':
#             L_Heiz_V = get_value(el.LookupParameter('Leistung_Heizen'))
#             L_Kuehl_V = get_value(el.LookupParameter('Leistung_Kühlen'))
#             Massen_V = get_value(el.LookupParameter('Massenstrom (kg/h)'))
#             Druck_V = get_value(el.LookupParameter('Druckverlust'))
#             print(L_Heiz_V)
#             raum = DeS[eleid]
#             ids = RaumListe[raum]
#             for newid in ids:
#                 ele = doc.GetElement(newid)
#                 if ele.Symbol.FamilyName != '_K_IGF_435_Deckensegelverbinder':
#                     L_Heiz_E = get_value(ele.LookupParameter('Leistung_Heizen'))
#                     L_Kuehl_E = get_value(ele.LookupParameter('Leistung_Kühlen'))
#                     Massen_E = get_value(ele.LookupParameter('Massenstrom (kg/h)'))
#                     Druck_E = get_value(ele.LookupParameter('Druckverlust'))
#                     L_Heiz_V = float(L_Heiz_V) + float(L_Heiz_E)
#                     L_Kuehl_V = float(L_Kuehl_V) + float(L_Kuehl_E)
#                     Massen_V = float(Massen_V) + float(Massen_E)
#                     Druck_V = float(Druck_V) + float(Druck_E)
#                     print(L_Heiz_V)
#                     el.LookupParameter('IGF_DeS_Heizung').SetValueString(str(round(L_Heiz_V,1)))
#                     el.LookupParameter('IGF_DeS_Kühlung').SetValueString(str(round(L_Kuehl_V,1)))
#                     el.LookupParameter('IGF_DeS_Massenstrom (kg/h)').Set(Massen_V)
#                     el.LookupParameter('IGF_DeS_Druckverlust').SetValueString(str(round(Druck_V,1)))
#                     break
#
#
#         else:
#             L_Heiz = get_value(el.LookupParameter('Leistung_Heizen'))
#             L_Kuehl = get_value(el.LookupParameter('Leistung_Kühlen'))
#             Massen = get_value(el.LookupParameter('Massenstrom (kg/h)'))
#             Druck = get_value(el.LookupParameter('Druckverlust'))
#             el.LookupParameter('IGF_DeS_Heizung').Set(L_Heiz)
#             el.LookupParameter('IGF_DeS_Kühlung').Set(L_Kuehl)
#             el.LookupParameter('IGF_DeS_Massenstrom (kg/h)').Set(L_Heiz)
#             el.LookupParameter('IGF_DeS_Druckverlust').Set(Druck)
#
# t.Commit()


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
