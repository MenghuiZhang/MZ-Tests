# coding: utf8
from manage_plugins import *

__title__ = "Module ausblenden"

logger = script.get_logger()
config = script.get_config('Module ausblenden')

def schreiben_Log():
    """write all Log information"""
    try:
        from IGF_log import getlog
        getlog(__title__)
    except:
        pass

if __name__ == '__main__':
    schreiben_Log()
    all_plugins = get_all_plugins()
    itemssource = get_itemssource(all_plugins)
    run_wpf(itemssource,config)
    setup_plugins(itemssource)
    change_icon(config,script.get_button())


def __selfinit__(script_cmp, ui_button_cmp, __rvt__):
    setup_tooltip(ui_button_cmp,script_cmp)
    config = script.get_config('Module ausblenden')

    all_plugins = get_all_plugins()
    itemssource = get_itemssource(all_plugins)
    WPF_UI(itemssource,config)
    setup_plugins(itemssource)
    change_icon(config,ui_button_cmp)