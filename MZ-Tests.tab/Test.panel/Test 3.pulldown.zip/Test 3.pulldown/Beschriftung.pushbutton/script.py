# coding: utf8
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from IGF_log import getlog
from rpw import revit, UI, DB
from pyrevit import script, forms
import time
import clr
import System
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
from System.Windows.Forms import OpenFileDialog,DialogResult
from System.Windows.Controls import *
from pyrevit.forms import WPFWindow
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel
from System.Runtime.InteropServices import Marshal

start = time.time()

__title__ = "Beschriftung der Fall- und Steigleitungen"
__doc__ = """Beschriftung der Fall- und Steigleitungen
Category: Allgemeine Beschriftungen"""
__author__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

uidoc = revit.uidoc
doc = revit.doc

logger = script.get_logger()
output = script.get_output()

name = doc.ProjectInformation.Name
number = doc.ProjectInformation.Number

bimid_config = script.get_config(name+number+'_Beschriftung Fallleitung')

# Views aus aktueller Projekt
views_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Views).WhereElementIsNotElementType()
views = views_collector.ToElementIds()
views_collector.Dispose()
view_liste = []

for el in views:
    elem = doc.GetElement(el)
    typ = elem.ViewType.ToString()
    if elem.IsTemplate:
        continue
    if typ in ['FloorPlan','CeilingPlan']:
        view_liste.append(el)

# class für Itemssource in WPF
class Itemtemplate(object):
    def __init__(self,_index,_name):
        self.Name = _name
        self.selectindex = _index
    @property
    def Name(self):
        return self._Name
    @Name.setter
    def Name(self, value):
        self._Name = value
    @property
    def selectindex(self):
        return self._selectindex
    @selectindex.setter
    def selectindex(self, value):
        self._selectindex = value

Levels_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Levels).WhereElementIsNotElementType()
levels = Levels_collector.ToElementIds()
Levels_collector.Dispose()
levels_liste = []
levels_dict_Name = {}

levels_id_name = {}
levels_name_id = {}

levels_dict_ID = {}
levels_IS = ObservableCollection[Itemtemplate]()
levels_id_height = {}
levels_height_id = {}

for n,elemid in enumerate(levels):
    name = doc.GetElement(elemid).Name
    height = doc.GetElement(elemid).Elevation
    levels_IS.Add(Itemtemplate(n,name))
    levels_dict_Name[name] = elemid
    levels_dict_ID[n] = elemid
    levels_id_name[name] = n
    levels_name_id[n] = name
    levels_id_height[height] = n
    levels_id_height[n] = height

families_collector = DB.FilteredElementCollector(doc).OfClass(DB.Family)
families = families_collector.ToElementIds()
families_collector.Dispose()
families_IS = {}

for elemid in families:
    family = doc.GetElement(elemid)
    name = family.Name
    if family.FamilyCategory.Id.ToString() != '-2000150':
        continue
    families_IS[name] = family

familien_IS = families_IS.keys()[:]
familien_IS.sort()

class Views(object):
    def __init__(self,elementid):
        self.levels_IS = levels_IS

        self.ElementID = elementid
        self.checked = False

        self.ansichtname = ''

        self.OBE_id = -1
        self.UTE_id = -1

    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value

    @property
    def ansichtname(self):
        return self._ansichtname
    @ansichtname.setter
    def ansichtname(self, value):
        self._ansichtname = value
    
    @property
    def OBE_id(self):
        return self._OBE_id
    @OBE_id.setter
    def OBE_id(self, value):
        self._OBE_id = value
    @property
    def UTE_id(self):
        return self._UTE_id
    @UTE_id.setter
    def UTE_id(self, value):
        self._UTE_id = value

Liste_Views = ObservableCollection[Views]()
Auswahldict = {}
planname_temp =  ObservableCollection[str]()

for viewid in view_liste:
    elem = doc.GetElement(viewid)
    tempclass = Views(viewid)
    tempclass.ansichtname = elem.Name

    Liste_Views.Add(tempclass)



class Viewsauswahl(WPFWindow):
    def __init__(self, xaml_file_name,liste_views):
        self.liste_views = liste_views
        WPFWindow.__init__(self, xaml_file_name)
        self.listview_ansicht.ItemsSource = liste_views
        self.tempcoll = ObservableCollection[Views]()
        self.leercoll = ObservableCollection[Views]()

        self.familie.ItemsSource = familien_IS
        self.altListview = liste_views
        self.familieids = {}
        self.Anzeigen = True

        # self.read_config()

        self.familie.SelectionChanged += self.family_changed
        self.suche.TextChanged += self.auswahl_txt_changed


    def checkedchanged(self, sender, args):
        Checked = sender.IsChecked
        if self.listview_ansicht.SelectedItem is not None:
            try:
                if sender.DataContext in self.listview_ansicht.SelectedItems:
                    for item in self.listview_ansicht.SelectedItems:
                        try:
                            item.checked = Checked
                        except:
                            pass
                    self.listview_ansicht.Items.Refresh()
                else:
                    pass
            except:
                pass
    
    def family_changed(self, sender, args):
        familie = self.familie.SelectedItem.ToString()
        family = families_IS[familie]
        familieids_liste = family.GetFamilySymbolIds()
        familieids = {}
        for elid in familieids_liste:
            name = doc.GetElement(elid).get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            familieids[name] = elid
        
        self.familieids = familieids
        familieids_liste = familieids.keys()[:]
        familieids_liste.sort()
        
        self.typ1.Text = ''
        self.typ2.Text = ''
        self.typ3.Text = ''
        self.typ4.Text = ''
        self.typ5.Text = ''
        self.typ6.Text = ''

        self.typ1.ItemsSource = familieids_liste
        self.typ2.ItemsSource = familieids_liste
        self.typ3.ItemsSource = familieids_liste
        self.typ4.ItemsSource = familieids_liste
        self.typ5.ItemsSource = familieids_liste
        self.typ6.ItemsSource = familieids_liste


    def auswahl_txt_changed(self, sender, args):
        self.tempcoll.Clear()
        text_typ = self.suche.Text.upper()

        if text_typ in ['',None]:
            self.listview_ansicht.ItemsSource = self.altListview
            text_typ = self.suche.Text = ''
            self.ein_ausblenden()
            return

        for item in self.altListview:
            if item.ansichtname.upper().find(text_typ) != -1:
                self.tempcoll.Add(item)
                                        
            self.listview_ansicht.ItemsSource = self.tempcoll
        self.listview_ansicht.Items.Refresh()

    def check(self,sender,args):
        for item in self.listview_ansicht.Items:
            item.checked = True
        self.listview_ansicht.Items.Refresh()


    def uncheck(self,sender,args):
        for item in self.listview_ansicht.Items:
            item.checked = False
        self.listview_ansicht.Items.Refresh()


    def toggle(self,sender,args):
        for item in self.listview_ansicht.Items:
            value = item.checked
            item.checked = not value
        self.listview_ansicht.Items.Refresh()

    def ok(self,sender,args):        
        self.Close()

    def abbrechen(self,sender,args):
        self.Close()
        script.exit()
    
    def anzeigen(self,sender,args):        
        self.Anzeigen = True
        self.ein_ausblenden()

    def ausblenden(self,sender,args):
        self.Anzeigen = False
        self.ein_ausblenden()
    
    def ein_ausblenden(self):
        self.tempcoll.Clear()
        if self.Anzeigen:
            self.listview_ansicht.ItemsSource = self.liste_views
            self.listview_ansicht.Items.Refresh()
        else:
            for el in self.altListview:
                if el.checked:
                    self.tempcoll.Add(el)
            self.listview_ansicht.ItemsSource = self.tempcoll

            self.listview_ansicht.Items.Refresh()
                
        

Planfenster = Viewsauswahl("window.xaml",Liste_Views)
try:
    Planfenster.ShowDialog()
except Exception as e:
    Planfenster.Close()
    logger.error(e)
    script.exit()

Liste_Ansichts = []
for el in Liste_Views:
    if el.checked:
        Liste_Ansichts.append(el)


try:
    Typ1 = Planfenster.familieids[Planfenster.typ1.SelectedItem.ToString()]
except:
    Typ1 = ''
try:
    Typ2 = Planfenster.familieids[Planfenster.typ2.SelectedItem.ToString()]
except:
    Typ2 = ''
try:
    Typ3 = Planfenster.familieids[Planfenster.typ3.SelectedItem.ToString()]
except:
    Typ3 = ''
try:
    Typ4 = Planfenster.familieids[Planfenster.typ4.SelectedItem.ToString()]
except:
    Typ4 = ''
try:
    Typ5 = Planfenster.familieids[Planfenster.typ5.SelectedItem.ToString()]
except:
    Typ5 = ''
try:
    Typ6 = Planfenster.familieids[Planfenster.typ6.SelectedItem.ToString()]
except:
    Typ6 = ''
try:
    Family = Planfenster.familie.SelectedItem.ToString()
except:
    Family = ''

class Beschriftung:
    def __init__(self,view):
        self.view = view
        self.typ1 = Typ1
        self.typ2 = Typ2
        self.typ3 = Typ3
        self.typ4 = Typ4
        self.typ5 = Typ5
        self.typ6 = Typ6
        self.family = Family
        self.OBE = levels_id_height[view.OBE_id]
        self.UTE = levels_id_height[view.UTE_id]
        self.Rohre = DB.FilteredElementCollector(doc,self.view.ElementID).OfCategory(DB.BuiltInCategory.OST_PipeCurves).WhereElementIsNotElementType().ToElements()
        self.beschriftung = DB.FilteredElementCollector(doc,self.view.ElementID).WherePasses(self.Filter).WhereElementIsNotElementType().ToElements()
        self.beschrifting_dict = self.get_Beschriftungsinfo()
        self.Rohr_info = self.get_Rohresinfo()
        self.Rohr_info_XYZ = self.get_Rohresinfo_XYZ()
        self.Beschriftungstyp = self.get_beschriftungtyp()

    
    @property
    def Filter(self):
        param_equality=DB.FilterStringEquals()
        Fam_name_id = DB.ElementId(DB.BuiltInParameter.ELEM_FAMILY_PARAM)
        Fam_name_prov=DB.ParameterValueProvider(Fam_name_id)
        Fam_name_value_rule=DB.FilterStringRule(Fam_name_prov,param_equality,self.family,True)
        Fam_name_filter = DB.ElementParameterFilter(Fam_name_value_rule)
        return Fam_name_filter
    
    def get_Beschriftungsinfo(self):
        dict_temp  ={}
        for el in self.beschriftung:
            dict_temp[el.Location.Point] = el
        return dict_temp
    
    def Pruefen(self,conns):
        p_X = []
        p_Y = []
        for conn in conns:
            p_X.append(round(conn.Origin.X*304.8))
            p_Y.append(round(conn.Origin.Y*304.8))

        if abs(p_X[0]-p_X[1]) <=2 and abs(p_Y[0]-p_Y[1]) <=2:
            return True
        else:
            return False
    
    def get_Rohresinfo(self):
        dict_temp  ={}
        for el in self.Rohre:
            conns = el.ConnectorManager.Connectors
            h1 = 0
            h2 = 0
            X = 0
            Y = 0
            if self.Pruefen(conns):
                for conn in conns:
                    if conn.Direction.ToString() == 'In':
                        h1 = conn.Origin.Z
                    elif conn.Direction.ToString() == 'Out':
                        h2 = conn.Origin.Z
                    X = round(conn.Origin.X*304.8)
                    Y = round(conn.Origin.Y*304.8)
                if h1 == h2 == 0:
                    continue
                if h1 == 0:
                    print(el.Id)
                if X not in dict_temp.keys():
                    dict_temp[X] = {}
                                            
                if Y not in dict_temp[X].keys():
                    dict_temp[X][Y] = [h1,h2]
                else:
                    h1_temp = dict_temp[X][Y][0]
                    h2_temp = dict_temp[X][Y][1]
                    if h1_temp > h2_temp:
                        if h2 >= h1_temp:
                            if h1 > h2:
                                dict_temp[X][Y][0] = h1
                        elif h2_temp >= h1:
                            if h1 > h2:
                                dict_temp[X][Y][1] = h2
                    elif h1_temp < h2_temp:
                        if h1_temp >= h2:
                            if h2 > h1:
                                dict_temp[X][Y][0] = h1 
                        elif h2_temp <= h1:
                            if h2 > h1:
                                dict_temp[X][Y][1] = h2

        return dict_temp

    def get_Rohresinfo_XYZ(self):
        dict_temp = {}
        for x in self.Rohr_info.keys():
            for y in self.Rohr_info[x].keys():
                p = DB.XYZ(x/304.8,y/304.8,0)
                dict_temp[p] = self.Rohr_info[x][y]
        return dict_temp
  
    
    def get_beschriftungtyp(self):
        dict_temp = {}
        for el in self.beschrifting_dict.keys():
            elem = self.beschrifting_dict[el]
            p1 = DB.XYZ(el.X,el.Y,0)

            for p2 in self.Rohr_info_XYZ.keys():
                if p1.DistanceTo(p2) < 0.09:
                    h1 = self.Rohr_info_XYZ[p2][0]
                    h2 = self.Rohr_info_XYZ[p2][1]
                    if h1 > h2:
                        if h1 > self.OBE:
                            if h2 < self.UTE:
                                dict_temp[elem] = self.typ1
                                break
                            else:
                                dict_temp[elem] = self.typ2
                                break
                        else:
                            if h2 < self.UTE:
                                dict_temp[elem] = self.typ3
                                break
                            else:
                                logger.error('kein typ: von hier bis hier. Elementid: {}'.format(elem.Id.ToString()))
                                print(h1,h2,self.OBE,self.UTE)
                    else:
                        if h1 < self.UTE:
                            if h2 > self.OBE:
                                dict_temp[elem] = self.typ4
                                break
                            else:
                                dict_temp[elem] = self.typ5
                                break
                        else:
                            if h2 > self.OBE:
                                dict_temp[elem] = self.typ6
                                break
                            else:
                                logger.error('kein typ: von hier nach hier. Elementid: {}'.format(elem.Id.ToString()))
                                print(h1,h2,self.OBE,self.UTE)
        return dict_temp

    def changetyp(self):
        for el in self.Beschriftungstyp.keys():
            try:
                el.ChangeTypeId(self.Beschriftungstyp[el])
            except Exception as e:
                logger.error(e)

t = DB.Transaction(doc)
t.Start('Test')
for el in Liste_Ansichts:
    temp = Beschriftung(el)
    temp.changetyp()
t.Commit()

end = time.time()

print(end-start)

    # def read_config(self):
    #     try:
    #         self.bz_l_erstellung.Text = config.bz_l_erstellung
    #     except:
    #         self.bz_l_erstellung.Text = config.bz_l_erstellung = '10'
    #     try:
    #         self.bz_r_erstellung.Text = config.bz_r_erstellung
    #     except:
    #         self.bz_r_erstellung.Text = config.bz_r_erstellung = '10'
    #     try:
    #         self.bz_o_erstellung.Text = config.bz_o_erstellung
    #     except:
    #         self.bz_o_erstellung.Text = config.bz_o_erstellung = '10'
    #     try:
    #         self.bz_u_erstellung.Text = config.bz_u_erstellung
    #     except:
    #         self.bz_u_erstellung.Text = config.bz_u_erstellung = '10'

    #     try:
    #         self.pk_l_erstellung.Text = config.pk_l_erstellung
    #     except:
    #         self.pk_l_erstellung.Text = config.pk_l_erstellung = '20'
    #     try:
    #         self.pk_r_erstellung.Text = config.pk_r_erstellung
    #     except:
    #         self.pk_r_erstellung.Text = config.pk_r_erstellung = '5'
    #     try:
    #         self.pk_o_erstellung.Text = config.pk_o_erstellung
    #     except:
    #         self.pk_o_erstellung.Text = config.pk_o_erstellung = '5'
    #     try:
    #         self.pk_u_erstellung.Text = config.pk_u_erstellung
    #     except:
    #         self.pk_u_erstellung.Text = config.pk_u_erstellung = '5'

    #     try:
    #         if config.erstellung_plankopf in plankopf_liste:
    #             self.Plankopf.SelectedIndex = Selected_Plankopf_Index
    #         else:
    #             self.Plankopf.Text = config.erstellung_plankopf = ''
    #     except:
    #         self.Plankopf.Text = config.erstellung_plankopf = ''

    # def write_config(self):
    #     try:
    #         config_temp.bz_l_erstellung = self.bz_l_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.bz_r_erstellung = self.bz_r_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.bz_o_erstellung = self.bz_o_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.bz_u_erstellung = self.bz_u_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.pk_u_erstellung = self.pk_u_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.pk_o_erstellung = self.pk_o_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.pk_l_erstellung = self.pk_l_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.pk_r_erstellung = self.pk_r_erstellung.Text
    #     except:
    #         pass

    #     try:
    #         config_temp.erstellung_plankopf = self.Plankopf.SelectedItem.Name
    #     except:
    #         config_temp.erstellung_plankopf = ''

    #     script.save_config()










































                    

# # Exceldaten
# class Exceldaten(object):
#     def __init__(self):
#         self.checked = False
#         self.bb = False
#         self.Systemname = ''
#         self.GK = ''
#         self.KG = ''
#         self.KN01 = ''
#         self.KN02 = ''
#         self.BIMID = ''
#         self.Workset = ''

#     @property
#     def checked(self):
#         return self._checked
#     @checked.setter
#     def checked(self, value):
#         self._checked = value
#     @property
#     def Systemname(self):
#         return self._Systemname
#     @Systemname.setter
#     def Systemname(self, value):
#         self._Systemname = value
#     @property
#     def GK(self):
#         return self._GK
#     @GK.setter
#     def GK(self, value):
#         self._GK = value
#     @property
#     def KG(self):
#         return self._KG
#     @KG.setter
#     def KG(self, value):
#         self._KG = value
#     @property
#     def KN01(self):
#         return self._KN01
#     @KN01.setter
#     def KN01(self, value):
#         self._KN01 = value
#     @property
#     def KN02(self):
#         return self._KN02
#     @KN02.setter
#     def KN02(self, value):
#         self._KN02 = value#
#     @property
#     def BIMID(self):
#         return self._BIMID
#     @BIMID.setter
#     def BIMID(self, value):
#         self._BIMID = value
#     @property
#     def Workset(self):
#         return self._Workset
#     @Workset.setter
#     def Workset(self, value):
#         self._Workset = value

# Liste_Luft = ObservableCollection[Exceldaten]()
# Liste_Alle = ObservableCollection[Exceldaten]()
# Liste_Rohr = ObservableCollection[Exceldaten]()

# def datenlesen(filepath,sheetname,Liste):
#     ex = Excel.ApplicationClass()
#     _nova_Nr_Id = {}
#     book = ex.Workbooks.Open(filepath)
#     sheet = book.Worksheets[sheetname]
#     rows = sheet.UsedRange.Rows.Count
#     for row in range(2,rows+1):
#         tempclass = Exceldaten()
#         sysname = sheet.Cells[row, 1].Value2
#         GK = sheet.Cells[row, 2].Value2
#         KG = str(int(sheet.Cells[row, 3].Value2))
#         KN01 = str(int(sheet.Cells[row, 4].Value2))
#         if len(KN01) == 1:
#             KN01 = '0' + KN01
#         KN02 = str(int(sheet.Cells[row, 5].Value2))
#         if len(KN02) == 1:
#             KN02 = '0' + KN02
#         workset = sheet.Cells[row, 7].Value2
#         bimid = GK + '_' + KG + '_' + KN01 + ' ' + KN02
#         tempclass.Systemname = sysname
#         tempclass.GK = GK
#         tempclass.KG = KG
#         tempclass.KN01 = KN01
#         tempclass.KN02 = KN02
#         tempclass.BIMID = bimid
#         tempclass.Workset = workset
#         Liste.Add(tempclass)
#         Liste_Alle.Add(tempclass)
#     book.Save()
#     book.Close()
#     Marshal.FinalReleaseComObject(sheet)
#     Marshal.FinalReleaseComObject(book)
#     ex.Quit()
#     Marshal.FinalReleaseComObject(ex)


# try:
#     Adresse = bimid_config.bimid
#     datenausexcel = {}
#     try:
#         datenlesen(Adresse,'Luft',Liste_Luft)
#         datenlesen(Adresse,'Rohr',Liste_Rohr)
#     except Exception as e:
#         logger.error(e)
# except:
#     pass


# # ExcelBimId GUI
# class ExcelBimId(WPFWindow):
#     def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_All):
#         self.liste_Luft = liste_Luft
#         self.liste_All = liste_All
#         self.liste_Rohr = liste_Rohr
#         WPFWindow.__init__(self, xaml_file_name)
#         self.tempcoll = ObservableCollection[Exceldaten]()
#         self.altdatagrid = None
#         self.read_config()

#         try:
#             self.dataGrid.ItemsSource = self.liste_All
#             self.altdatagrid = self.liste_All
#             self.backAll()
#             self.click(self.alle)
#         except Exception as e:
#             logger.error(e)

#         self.systemsuche.TextChanged += self.search_txt_changed
#         self.Adresse.TextChanged += self.excel_changed
#     def click(self,button):
#         button.Background = BrushConverter().ConvertFromString("#FF707070")
#         button.FontWeight = FontWeights.Bold
#         button.FontStyle = FontStyles.Italic
#     def back(self,button):
#         button.Background  = Brushes.White
#         button.FontWeight = FontWeights.Normal
#         button.FontStyle = FontStyles.Normal
#     def backAll(self):
#         self.back(self.luft)
#         self.back(self.rohr)
#         self.back(self.alle)

#     def rohr(self,sender,args):
#         self.backAll()
#         self.click(self.rohr)
#         self.dataGrid.ItemsSource = self.liste_Rohr
#         self.altdatagrid = self.liste_Rohr
#         self.dataGrid.Items.Refresh()
#     def luft(self,sender,args):
#         self.backAll()
#         self.click(self.luft)
#         self.dataGrid.ItemsSource = self.liste_Luft
#         self.altdatagrid = self.liste_Luft
#         self.dataGrid.Items.Refresh()
#     def alle(self,sender,args):
#         self.backAll()
#         self.click(self.alle)
#         self.dataGrid.ItemsSource = self.liste_All
#         self.altdatagrid = self.liste_All
#         self.dataGrid.Items.Refresh()

#     def read_config(self):
#         try:
#             self.Adresse.Text = str(bimid_config.bimid)
#         except:
#             self.Adresse.Text = bimid_config.bimid = ""

#     def write_config(self):
#         bimid_config.bimid = self.Adresse.Text.encode('utf-8')
#         script.save_config()

#     def search_txt_changed(self, sender, args):
#         """Handle text change in search box."""
#         self.tempcoll.Clear()
#         text_typ = self.systemsuche.Text.upper()
#         if text_typ in ['',None]:
#             self.dataGrid.ItemsSource = self.altdatagrid

#         else:
#             if text_typ == None:
#                 text_typ = ''
#             for item in self.altdatagrid:
#                 if item.Systemname.upper().find(text_typ) != -1:
#                     self.tempcoll.Add(item)
#             self.dataGrid.ItemsSource = self.tempcoll
#         self.dataGrid.Items.Refresh()

#     def excel_changed(self, sender, args):
#         Liste_Luft.Clear()
#         Liste_Rohr.Clear()
#         Liste_Alle.Clear()
#         try:
#             datenlesen(self.Adresse.Text,'Luft',Liste_Luft)
#             datenlesen(self.Adresse.Text,'Rohr',Liste_Rohr)
#         except:
#             pass
#         self.liste_Luft = Liste_Luft
#         self.dataGrid.ItemsSource = Liste_Luft

#     def durchsuchen(self,sender,args):
#         dialog = OpenFileDialog()
#         dialog.Multiselect = False
#         dialog.Title = "BIM-ID Datei suchen"
#         dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
#         if dialog.ShowDialog() == DialogResult.OK:
#             self.Adresse.Text = dialog.FileName
#         self.write_config()

#     def checkall(self,sender,args):
#         for item in self.dataGrid.Items:
#             item.checked = True
#         self.dataGrid.Items.Refresh()

#     def uncheckall(self,sender,args):
#         for item in self.dataGrid.Items:
#             item.checked = False
#         self.dataGrid.Items.Refresh()

#     def toggleall(self,sender,args):
#         for item in self.dataGrid.Items:
#             value = item.checked
#             item.checked = not value
#         self.dataGrid.Items.Refresh()
#     def checkallbb(self,sender,args):
#         for item in self.dataGrid.Items:
#             item.bb = True
#         self.dataGrid.Items.Refresh()

#     def uncheckallbb(self,sender,args):
#         for item in self.dataGrid.Items:
#             item.bb = False
#         self.dataGrid.Items.Refresh()

#     def toggleallbb(self,sender,args):
#         for item in self.dataGrid.Items:
#             value = item.bb
#             item.bb = not value
#         self.dataGrid.Items.Refresh()

#     def ok(self,sender,args):
#         self.Close()

# windowExcelBimId = ExcelBimId("Window.xaml",Liste_Luft,Liste_Rohr,Liste_Alle)
# windowExcelBimId.ShowDialog()


# DictAusExcel_Luft = {}
# for el in Liste_Luft:
#     if el.checked == True:
#         DictAusExcel_Luft[el.Systemname] = [
#         el.GK,
#         el.KG,
#         el.KN01,
#         el.KN02,
#         el.BIMID,
#         el.Workset,
#         el.bb
#     ]

# DictAusExcel_Rohr = {}
# for el in Liste_Rohr:
#     if el.checked == True:
#         DictAusExcel_Rohr[el.Systemname] = [
#         el.GK,
#         el.KG,
#         el.KN01,
#         el.KN02,
#         el.BIMID,
#         el.Workset,
#         el.bb
#     ]

# WorksetListe = []
# if len(DictAusExcel_Luft.keys()) > 0:
#     for item in DictAusExcel_Luft.keys():
#         if DictAusExcel_Luft[item][6]:
#             WorksetListe.append(DictAusExcel_Luft[item][5])
# if len(DictAusExcel_Rohr.keys()) > 0:
#     for item in DictAusExcel_Rohr.keys():
#         if DictAusExcel_Rohr[item][6]:
#             WorksetListe.append(DictAusExcel_Rohr[item][5])

# fehlendeworkset = []
# if len(WorksetListe) > 0:
#     for item in WorksetListe:
#         if not item in Workset_dict.keys():
#            fehlendeworkset.append(item)
# fehlendeworkset = set(fehlendeworkset)
# fehlendeworkset = list(fehlendeworkset)

# if any(fehlendeworkset):
#     if forms.alert("fehlende Bearbeitungsbereiche erstellen?", ok=False, yes=True, no=True):
#         t = DB.Transaction(doc)
#         t.Start('Bearbeitunsbereich erstellen')
#         for el in fehlendeworkset:
#             logger.info(30*'-')
#             logger.info(el)
#             try:
#                 item = DB.Workset.Create(doc,el)
#                 Workset_dict[el] = item.Id.ToString()
#                 logger.info('Bearbeitunsbereich {} erstellt'.format(el))
#             except Exception as e:
#                 logger.error(e)
#         doc.Regenerate()
#         t.Commit()


# # Luft System
# luftsys = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
# luftsysids = luftsys.ToElementIds()
# luftsys.Dispose()

# # Rohr System
# rohrsys = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
# rohrsysids = rohrsys.ToElementIds()
# rohrsys.Dispose()


# syslistluftids = {}
# for sysid in luftsysids:
#     elem = doc.GetElement(sysid)
#     systyp = elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
#     if systyp in DictAusExcel_Luft.keys():
#         if systyp in syslistluftids.keys():
#             syslistluftids[systyp].append(sysid)
#         else:
#             syslistluftids[systyp] = [sysid]

# syslistrohrids = {}
# for sysid in rohrsysids:
#     elem = doc.GetElement(sysid)
#     systyp = elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
#     if systyp in DictAusExcel_Rohr.keys():
#         if systyp in syslistrohrids.keys():
#             syslistrohrids[systyp].append(sysid)
#         else:
#             syslistrohrids[systyp] = [sysid]


# class MEPSystem:
#     def __init__(self,elemid,liste):
#         self.elemid = elemid
#         self.elem = doc.GetElement(self.elemid)
#         self.typid = self.elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsElementId()
#         self.typ = doc.GetElement(self.typid)
#         self.liste = liste
#         self.GK = self.liste[0]
#         self.KG = self.liste[1]
#         self.KN01 = self.liste[2]
#         self.KN02 = self.liste[3]
#         self.bimid = self.liste[4]

#     def wert_schreiben(self, elem, param_name, wert):
#             if not wert is None:
#                 if elem.LookupParameter(param_name):
#                     elem.LookupParameter(param_name).Set(wert)
    
#     def DatenSchreiben_System(self):
#         self.wert_schreiben(self.typ,'IGF_X_Gewerkkürzel',str(self.GK))
#         self.wert_schreiben(self.typ,'IGF_X_Kostengruppe',int(self.KG))
#         self.wert_schreiben(self.typ,'IGF_X_Kennnummer_1',int(self.KN01))
#         self.wert_schreiben(self.typ,'IGF_X_Kennnummer_2',int(self.KN02))
#         self.wert_schreiben(self.typ,'IGF_X_BIM-ID',str(self.bimid))



# class bauteil:
#     def __init__(self,elemid,liste):
#         self.elemid = elemid
#         self.elem = doc.GetElement(self.elemid)
#         self.liste = liste
#         self.GK = self.liste[0]
#         self.KG = self.liste[1]
#         self.KN01 = self.liste[2]
#         self.KN02 = self.liste[3]
#         self.bimid = self.liste[4]

#     def wert_schreiben(self, elem, param_name, wert):
#             if not wert is None:
#                 if elem.LookupParameter(param_name):
#                     elem.LookupParameter(param_name).Set(wert)
    
#     def DatenSchreiben(self):
#         self.wert_schreiben(self.elem,'IGF_X_Gewerkkürzel_Exemplar',str(self.GK))
#         self.wert_schreiben(self.elem,'IGF_X_KG_Exemplar',int(self.KG))
#         self.wert_schreiben(self.elem,'IGF_X_KN01_Exemplar',int(self.KN01))
#         self.wert_schreiben(self.elem,'IGF_X_KN02_Exemplar',int(self.KN02))
#         self.wert_schreiben(self.elem,'IGF_X_BIM-ID_Exemplar',str(self.bimid))

# if any(DictAusExcel_Luft):
#     Systemtypliste = syslistluftids.keys()
#     with forms.ProgressBar(title="{value}/{max_value} Luftkanal Systeme",cancellable=True, step=1) as pb:
#         t = DB.Transaction(doc,'Luftkanal Systeme')
#         t.Start()
#         for n, typ in enumerate(Systemtypliste):
#             if pb.cancelled:
#                 t.RollBack()
#                 script.exit()
#             pb.update_progress(n + 1, len(Systemtypliste))
#             for id in syslistluftids[typ]:
#                 liste_temp = DictAusExcel_Luft[typ]
#                 system_temp = MEPSystem(id,liste_temp)
#                 try:
#                     system_temp.DatenSchreiben_System()
#                 except Exception as e:
#                     logger.error(e)
#         t.Commit()
#     with forms.ProgressBar(title="{value}/{max_value} Elements",cancellable=True, step=1) as pb:
#         for n0,typ in enumerate(Systemtypliste):
#             sysliste = syslistluftids[typ]
#             daten = DictAusExcel_Luft[typ]
#             bbschreiben = DictAusExcel_Luft[typ][6]
#             if bbschreiben:
#                 bb = DictAusExcel_Luft[typ][5]
            
#             t1 = DB.Transaction(doc,'Bauteile ' + typ)
#             t1.Start()
#             for n1,systemid in enumerate(sysliste):
#                 elements = list(doc.GetElement(systemid).DuctNetwork)
#                 title = str(n0+1) + '/' + str(len(Systemtypliste)) + ' Luftkanalsystemtyp ---- ' + \
#                     str(n1+1) + '/' + str(len(sysliste)) + ' Luftkanal Systeme ---- ' + "{value}/{max_value} Elements ---- " + typ
                
#                 pb.title = title 
#                 pb.step = int(len(elements)/500)+1    
#                 for n2,el in enumerate(elements):
#                     if pb.cancelled:
#                         t1.RollBack()
#                         script.exit()
#                     pb.update_progress(n2 + 1, len(elements))

#                     if el.Category.Id.ToString() in ['-2008000','-2008020']:
#                         try:
                            
#                             if el.MEPSystem.Id.ToString() == systemid.ToString():
#                                 kanal = bauteil(el.Id,daten)
#                                 kanal.DatenSchreiben()
#                                 try:
#                                     kanal.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
#                                 except:
#                                     pass
#                         except Exception as e:
#                             logger.error(e)
#                             pass
#                     elif el.Category.Id.ToString() == '-2008013':
#                         try:
#                             if list(el.MEPModel.ConnectorManager.Connectors)[0].MEPSystem.Id.ToString() == systemid.ToString():
#                                 auslass = bauteil(el.Id,daten)
#                                 auslass.DatenSchreiben()
#                                 try:
#                                     auslass.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
#                                 except:
#                                     pass
#                         except:
#                             pass

#                     elif el.Category.Id.ToString() in ['-2008010','-2008016','-2001140']:
#                         conns = el.MEPModel.ConnectorManager.Connectors
#                         In = {}
#                         Out = {}
#                         Unverbunden = {}
#                         for conn in conns:
#                             if conn.IsConnected:
#                                 if conn.Direction.ToString() == 'In':
#                                     In[conn.Id] = conn
#                                 else:
#                                     Out[conn.Id] = conn
#                             else:
#                                 Unverbunden[conn.Id] = conn
#                         sorted(In)
#                         sorted(Out)
#                         sorted(Unverbunden)
#                         conns = In.values()[:]
#                         connouts = Out.values()[:]
#                         connunvers = Unverbunden.values()[:]
#                         conns.extend(connouts)
#                         conns.extend(connunvers)
                        
#                         try:
#                             for conn in conns:
#                                 if not conn.MEPSystem:
#                                     continue
#                                 else:
#                                     if conn.MEPSystem.Id.ToString() == systemid.ToString():
#                                         formteilUndZubehoer = bauteil(el.Id,daten)
#                                         formteilUndZubehoer.DatenSchreiben()
#                                         try:
#                                             formteilUndZubehoer.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
#                                         except:
#                                             pass
#                                     break
#                         except:
#                             pass
#             try:
#                 t1.Commit()
#             except Exception as e:
#                 print(e)
#                 t1.RollBack()


# if any(DictAusExcel_Rohr):
#     Systemtypliste = syslistrohrids.keys()
#     with forms.ProgressBar(title="{value}/{max_value} Rohr Systeme",cancellable=True, step=1) as pb:
#         t = DB.Transaction(doc,'Rohr Systeme')
#         t.Start()
#         for n, typ in enumerate(Systemtypliste):
#             if pb.cancelled:
#                 t.RollBack()
#                 script.exit()
#             pb.update_progress(n + 1, len(Systemtypliste))
#             for id in syslistrohrids[typ]:
#                 liste_temp = DictAusExcel_Rohr[typ]
#                 system_temp = MEPSystem(id,liste_temp)
#                 try:
#                     system_temp.DatenSchreiben_System()
#                 except Exception as e:
#                     logger.error(e)
#         t.Commit()

#     with forms.ProgressBar(title="{value}/{max_value} Elements",cancellable=True, step=1) as pb:
#         for n0,typ in enumerate(Systemtypliste):
#             sysliste = syslistrohrids[typ]
#             daten = DictAusExcel_Rohr[typ]
#             bbschreiben = DictAusExcel_Rohr[typ][6]
#             if bbschreiben:
#                 bb = DictAusExcel_Luft[typ][5]
#             t1 = DB.Transaction(doc,'Bauteile ' + typ)
#             t1.Start()
#             for n1,systemid in enumerate(sysliste):
#                 elements = list(doc.GetElement(systemid).PipingNetwork)
#                 title = str(n0+1) + '/' + str(len(Systemtypliste)) + ' Rohrsystemtyp ---- ' + \
#                     str(n1+1) + '/' + str(len(sysliste)) + ' Rohr Systeme ---- ' + "{value}/{max_value} Elements ---- " + typ
#                 pb.title = title 
#                 pb.step = int(len(elements)/500)+1
#                 for n2,el in enumerate(elements):
#                     if pb.cancelled:
#                         t1.RollBack()
#                         script.exit()
#                     pb.update_progress(n2 + 1, len(elements))
#                     if el.Category.Id.ToString() in ['-2008050','-2008044']:
#                         try:
#                             if el.MEPSystem.Id.ToString() == systemid.ToString():
#                                 rohr = bauteil(el.Id,daten)
#                                 rohr.DatenSchreiben()
#                                 try:
#                                     rohr.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
#                                 except:
#                                     pass
#                         except:
#                             pass
#                     elif el.Category.Id.ToString() == '-2008099':
#                         try:
#                             if list(el.MEPModel.ConnectorManager.Connectors)[0].MEPSystem.Id.ToString() == systemid.ToString():
#                                 sprinkler = bauteil(el.Id,daten)
#                                 sprinkler.DatenSchreiben()
#                                 try:
#                                     sprinkler.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
#                                 except:
#                                     pass
#                         except:
#                             pass

#                     elif el.Category.Id.ToString() in ['-2008049','-2008055','-2001140','-2001160']:
#                         conns = el.MEPModel.ConnectorManager.Connectors
#                         In = {}
#                         Out = {}
#                         Unverbunden = {}
#                         for conn in conns:
#                             if conn.IsConnected:
#                                 if conn.Direction.ToString() == 'In':
#                                     In[conn.Id] = conn
#                                 else:
#                                     Out[conn.Id] = conn
#                             else:
#                                 Unverbunden[conn.Id] = conn
#                         sorted(In)
#                         sorted(Out)
#                         sorted(Unverbunden)
#                         conns = In.values()[:]
#                         connouts = Out.values()[:]
#                         connunvers = Unverbunden.values()[:]
#                         conns.extend(connouts)
#                         conns.extend(connunvers)
                        
#                         try:
#                             for conn in conns:
#                                 if not conn.MEPSystem:
#                                     continue
#                                 else:
#                                     if conn.MEPSystem.Id.ToString() == systemid.ToString():
#                                         formteilUndZubehoer = bauteil(el.Id,daten)
#                                         formteilUndZubehoer.DatenSchreiben()
#                                         try:
#                                             formteilUndZubehoer.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
#                                         except:
#                                             pass
#                                     break
#                         except:
#                             pass
#                         try:
#                             if list(conns)[0].MEPSystem.Id.ToString() == systemid.ToString():
#                                 formteilUndZubehoer = bauteil(el.Id,daten)
#                                 formteilUndZubehoer.DatenSchreiben()
#                                 try:
#                                     formteilUndZubehoer.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
#                                 except:
#                                     pass
#                         except:
#                             pass
#             try:
#                 t1.Commit()
#             except:
#                 t1.RollBack()