# coding: utf8
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from IGF_log import getlog
from pyrevit.forms import WPFWindow
from rpw import revit,DB
from pyrevit import script


__title__ = "GA-Parameter"
__doc__ = """änderung von GA-Parameter. buzüglich auf Typparameter.

[2022.02.07]
Version: 1.0
"""
__author__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

doc = revit.doc
logger = script.get_logger()


Kategorien_Dict = {
    'Elektrische Ausstattung':DB.BuiltInCategory.OST_ElectricalEquipment,
    'Luftkanalzubehör':DB.BuiltInCategory.OST_DuctAccessory,
    'Rohrzubehör':DB.BuiltInCategory.OST_PipeAccessory,
    'HLS-Bauteile':DB.BuiltInCategory.OST_MechanicalEquipment,
}


class GUI_GA_Param(WPFWindow):
    def __init__(self, xaml_file_name):
        WPFWindow.__init__(self, xaml_file_name)
        self.Category.ItemsSource = sorted(Kategorien_Dict.keys())
        self.dict_itemssource = {}
        self.parameter = None
        self.transaction = DB.Transaction(doc, 'Wert schreiben')
        for cate in Kategorien_Dict.keys():
            self.dict_itemssource[cate] = {}
            coll = DB.FilteredElementCollector(doc).OfCategory(Kategorien_Dict[cate]).WhereElementIsNotElementType()
            for elem in coll:
                family = elem.Symbol.FamilyName
                typ = elem.Name
                if family not in self.dict_itemssource[cate].keys():
                    self.dict_itemssource[cate][family] = {}
                if typ not in self.dict_itemssource[cate][family].keys():

                    params = elem.Symbol.Parameters
                    param_dict = {}
                    for param in params:
                        name = param.Definition.Name
                        if name.find('IGF_GA') != -1:
                            param_dict[name] = param
                    self.dict_itemssource[cate][family][typ] = param_dict


    
    def cate_changed(self, sender, args):
        cate = str(self.Category.SelectedItem)
        self.Family.SelectedIndex = -1
        self.Type.SelectedIndex = -1
        self.Param.SelectedIndex = -1
        self.value.Text = ''
        self.Family.ItemsSource = sorted(self.dict_itemssource[cate].keys())
    
    def fam_changed(self, sender, args):
        cate = str(self.Category.SelectedItem)
        fam = str(self.Family.SelectedItem)
        self.Type.SelectedIndex = -1
        self.Param.SelectedIndex = -1
        self.value.Text = ''
        self.Type.ItemsSource = sorted(self.dict_itemssource[cate][fam].keys())
    
    def typ_changed(self, sender, args):
        cate = str(self.Category.SelectedItem)
        fam = str(self.Family.SelectedItem)
        typ = str(self.Type.SelectedItem)
        self.Param.SelectedIndex = -1
        self.value.Text = ''
        self.Param.ItemsSource = sorted(self.dict_itemssource[cate][fam][typ].keys())

    def param_changed(self, sender, args):
        self.value.Text = ''
        cate = str(self.Category.SelectedItem)
        fam = str(self.Family.SelectedItem)
        typ = str(self.Type.SelectedItem)
        paramname = str(self.Param.SelectedItem)
        self.parameter = self.dict_itemssource[cate][fam][typ][paramname]

    def wert_schreiben(self, sender, args):
        self.transaction.Start()
        if self.value.Text != None:
            if self.parameter.StorageType == 'String':
                self.parameter.Set(self.value.Text)
            elif self.parameter.StorageType == 'Integer':
                try:

                    self.parameter.Set(int(self.value.Text))
                except Exception as E:
                    logger.error(E)
            elif self.parameter.StorageType == 'Double':
                try:

                    self.parameter.SetValueString(self.value.Text)
                except Exception as E:
                    logger.error(E)

        self.transaction.Commit()

name = GUI_GA_Param('window.xaml')

try:
    name.ShowDialog()
except Exception as x:
    logger.error(x)
    name.Close()
