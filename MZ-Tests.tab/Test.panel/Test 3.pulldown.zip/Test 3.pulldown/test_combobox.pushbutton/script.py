# coding: utf8

from System.Collections.ObjectModel import ObservableCollection
from pyrevit.forms import WPFWindow

class Test1(object):
    def __init__(self):
        self.checked = False
        self.name = ''

    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, value):
        self._name = value
    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value

class Test2(object):
    def __init__(self):
        self.Textname = ''
        self.Liste = None
    @property
    def Textname(self):
        return self._Textname
    @Textname.setter
    def Textname(self, value):
        self._Textname = value
    @property
    def Liste(self):
        return self._Liste
    @Liste.setter
    def Liste(self, value):
        self._Liste = value

Liste = ['Test1','Test2','Test3','Test4']
coll = ObservableCollection[Test1]()
for el in Liste:
    temp = Test1()
    temp.name = el
    coll.Add(temp)

class PlanUI(WPFWindow):
    def __init__(self, xaml_file_name,liste_views):
        self.liste_views = liste_views
        WPFWindow.__init__(self, xaml_file_name)
        self.Test_combo.ItemsSource = liste_views

    def changed(self, sender, args):
        Text = ''
        for el in self.liste_views:
            if el.checked:
                Text = Text + el.name + ','
        if len(Text) > 1:
            text = Text[:-1]
        else:
            text = ''
        self.Test_combo.Text = text
        print(text)

Planfenster = PlanUI("window.xaml",coll)
try:
    Planfenster.ShowDialog()
except Exception as e:
    Planfenster.Close()
    print(e)

