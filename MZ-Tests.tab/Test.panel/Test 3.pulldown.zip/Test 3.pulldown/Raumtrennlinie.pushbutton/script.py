# coding: utf8
from pyrevit import revit,DB,UI,script,forms
from pyIGF_abfrage import abfrage

__title__ = "Raumtrennlinie löschen"
__doc__ = """Raumtrennlinie löschen
Version: 1.0"""
__author__ = "Menghui Zhang"

try:
    from pyIGF_logInfo import getlog
    getlog(__title__)
except:
    pass

doc = revit.doc
active_view = doc.ActiveView

frage_schicht = abfrage(title= 'Schicht', info = 'Aktuelle Ansicht oder ganz Projekt', ja = True,ja_text= 'Ansicht',nein_text='Projekt')


frage_schicht.ShowDialog()

coll = None
if frage_schicht.antwort == 'Ansicht':
    coll = DB.FilteredElementCollector(doc,active_view.Id).OfCategory(DB.BuiltInCategory.OST_MEPSpaceSeparationLines).WhereElementIsNotElementType()
elif frage_schicht.antwort == 'Projekt':
    coll = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MEPSpaceSeparationLines).WhereElementIsNotElementType()
if not coll:
    script.exit()


frage_delete = abfrage(title= 'Frage', info = 'MEP-Raumtrennlinie löschen?', ja = True,ja_text= 'Ja',nein_text='Nein')
frage_delete.ShowDialog()
if coll:
    elementids = coll.ToElementIds()
    coll.Dispose()

if frage_delete.antwort == 'Ja':
    t_del = DB.Transaction(doc,'Raumtrennlinie löschen')
    t_del.Start()
    with forms.ProgressBar(title="{value}/{max_value} MEP-Raumtrennlinie", cancellable=True, step=1) as pb:
        for n, elementid in enumerate(elementids):
            if pb.cancelled:
                t_del.RollBack()
                script.exit()
            pb.update_progress(n + 1, len(elementids))

            try:
                doc.Delete(elementid)
            except:
                pass

    t_del.Commit()
    
elif frage_delete.antwort == 'Nein':
    pass