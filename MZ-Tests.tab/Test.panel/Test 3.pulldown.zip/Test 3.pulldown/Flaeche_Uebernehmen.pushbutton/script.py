# coding: utf8
from rpw import revit,DB,UI
from pyrevit import forms,script

__title__ = "4.50 Dachfläche übernehmen(Regenwasser)"
__doc__ = """..."""
__author__ = "Menghui Zhang"

try:
    from pyIGF_logInfo import getlog
    getlog(__title__)
except:
    pass

doc = revit.doc

coll = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_DetailComponents).WhereElementIsNotElementType()
elementids = coll.ToElementIds()
coll.Dispose()
        

class Flaeche(object):
    def __init__(self,elementid):
        self.elem_id = elementid
        self.elem = doc.GetElement(self.elem_id)
    
    @property
    def Area(self):
        return self.elem.get_Parameter(DB.BuiltInParameter.HOST_AREA_COMPUTED).AsDouble()*0.3048*0.3048
    @property
    def isDachFlaeche(self):
        return self.elem.LookupParameter('IGF_S_RW_istDachfläche').AsInteger()

    def werte_schreiben(self):
        if self.isDachFlaeche != 0:
            self.elem.LookupParameter('IGF_S_Dachfläche').Set(round(float(self.Area),2))

Liste = []
with forms.ProgressBar(title="{value}/{max_value} Detailelemente in Projekt", cancellable=True, step=10) as pb:
    for n, elemid in enumerate(elementids):
        if pb.cancelled:
            script.exit()
        pb.update_progress(n + 1, len(elementids))
        flaeche = Flaeche(elemid)
        if flaeche.isDachFlaeche != 0:
            Liste.append(flaeche)

if len(Liste) == 0:
    UI.TaskDialog.Show(__title__,'Keine Dachfläche in Projekt gefunden')
    script.exit()
else:
    print('{} Dachfläche in Projekt gefunden'.format(len(Liste)))

# Werte zuückschreiben + Abfrage
if forms.alert('Dachfläche in Parameter "IGF_S_Dachfläche" schreiben?', ok=False, yes=True, no=True):
    t = DB.Transaction(doc,'Fläche schreiben')
    t.Start()
    with forms.ProgressBar(title="{value}/{max_value} Dachfläche in Projekt", cancellable=True, step=10) as pb1:
        for n1, flaeche in enumerate(Liste):
            if pb1.cancelled:
                t.Rollback()
                script.exit()
            pb.update_progress(n1 + 1, len(Liste))
    
            flaeche.werte_schreiben()
            
    t.Commit()