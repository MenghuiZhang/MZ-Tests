# coding: utf8
from re import S
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from IGF_log import getlog
from rpw import revit, DB
from pyrevit import script, forms
import clr
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
from System.Windows.Forms import OpenFileDialog,DialogResult
from System.Windows.Controls import *
from pyrevit.forms import WPFWindow
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel
from System.Runtime.InteropServices import Marshal

__title__ = "8.10 BIM-ID und Bearbeitsungsbereiche"
__doc__ = """BIM-ID und Bearbeitunsbereich aus excel in Modell schreiben

[2021.11.23]
Version: 2.0
"""
__authors__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

uidoc = revit.uidoc
doc = revit.doc

logger = script.get_logger()
output = script.get_output()

name = doc.ProjectInformation.Name
number = doc.ProjectInformation.Number

bimid_config = script.get_config(name+number+'BIM-ID und Bearbeitsungsbereiche')

# Bearbeitungsbereich
worksets = DB.FilteredWorksetCollector(doc).OfKind(DB.WorksetKind.UserWorkset)
Workset_dict = {}
for el in worksets:
    Workset_dict[el.Name] = el.Id.ToString()

# Exceldaten
class Exceldaten(object):
    def __init__(self):
        self.checked = False
        self.bb = False
        self.Systemname = ''
        self.GK = ''
        self.KG = ''
        self.KN01 = ''
        self.KN02 = ''
        self.BIMID = ''
        self.Workset = ''

    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def Systemname(self):
        return self._Systemname
    @Systemname.setter
    def Systemname(self, value):
        self._Systemname = value
    @property
    def GK(self):
        return self._GK
    @GK.setter
    def GK(self, value):
        self._GK = value
    @property
    def KG(self):
        return self._KG
    @KG.setter
    def KG(self, value):
        self._KG = value
    @property
    def KN01(self):
        return self._KN01
    @KN01.setter
    def KN01(self, value):
        self._KN01 = value
    @property
    def KN02(self):
        return self._KN02
    @KN02.setter
    def KN02(self, value):
        self._KN02 = value
    @property
    def BIMID(self):
        return self._BIMID
    @BIMID.setter
    def BIMID(self, value):
        self._BIMID = value
    @property
    def Workset(self):
        return self._Workset
    @Workset.setter
    def Workset(self, value):
        self._Workset = value

Liste_Luft = ObservableCollection[Exceldaten]()
Liste_Alle = ObservableCollection[Exceldaten]()
Liste_Rohr = ObservableCollection[Exceldaten]()

def datenlesen(filepath,sheetname,Liste):
    ex = Excel.ApplicationClass()
    book = ex.Workbooks.Open(filepath)
    sheet = book.Worksheets[sheetname]
    rows = sheet.UsedRange.Rows.Count
    for row in range(2,rows+1):
        tempclass = Exceldaten()
        sysname = sheet.Cells[row, 1].Value2
        GK = sheet.Cells[row, 2].Value2
        KG = str(int(sheet.Cells[row, 3].Value2))
        KN01 = str(int(sheet.Cells[row, 4].Value2))
        if len(KN01) == 1:
            KN01 = '0' + KN01
        KN02 = str(int(sheet.Cells[row, 5].Value2))
        if len(KN02) == 1:
            KN02 = '0' + KN02
        workset = sheet.Cells[row, 7].Value2
        bimid = GK + '_' + KG + '_' + KN01 + ' ' + KN02
        tempclass.Systemname = sysname
        tempclass.GK = GK
        tempclass.KG = KG
        tempclass.KN01 = KN01
        tempclass.KN02 = KN02
        tempclass.BIMID = bimid
        tempclass.Workset = workset
        Liste.Add(tempclass)
        Liste_Alle.Add(tempclass)
    book.Save()
    book.Close()
    Marshal.FinalReleaseComObject(sheet)
    Marshal.FinalReleaseComObject(book)
    ex.Quit()
    Marshal.FinalReleaseComObject(ex)


try:
    Adresse = bimid_config.bimid
    datenausexcel = {}
    try:
        datenlesen(Adresse,'Luft',Liste_Luft)
        datenlesen(Adresse,'Rohr',Liste_Rohr)
    except Exception as e:
        logger.error(e)
except:
    pass


# ExcelBimId GUI
class ExcelBimId(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_All):
        self.liste_Luft = liste_Luft
        self.liste_All = liste_All
        self.liste_Rohr = liste_Rohr
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[Exceldaten]()
        self.altdatagrid = None
        self.read_config()

        try:
            self.dataGrid.ItemsSource = self.liste_All
            self.altdatagrid = self.liste_All
            self.backAll()
            self.click(self.alle)
        except Exception as e:
            logger.error(e)

        self.systemsuche.TextChanged += self.search_txt_changed
        self.Adresse.TextChanged += self.excel_changed
    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal
    def backAll(self):
        self.back(self.luft)
        self.back(self.rohr)
        self.back(self.alle)

    def rohr(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Items.Refresh()
    def luft(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Items.Refresh()
    def alle(self,sender,args):
        self.backAll()
        self.click(self.alle)
        self.dataGrid.ItemsSource = self.liste_All
        self.altdatagrid = self.liste_All
        self.dataGrid.Items.Refresh()

    def read_config(self):
        try:
            self.Adresse.Text = str(bimid_config.bimid)
        except:
            self.Adresse.Text = bimid_config.bimid = ""

    def write_config(self):
        bimid_config.bimid = self.Adresse.Text.encode('utf-8')
        script.save_config()

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.systemsuche.Text.upper()
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.Systemname.upper().find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()

    def excel_changed(self, sender, args):
        Liste_Luft.Clear()
        Liste_Rohr.Clear()
        Liste_Alle.Clear()
        try:
            datenlesen(self.Adresse.Text,'Luft',Liste_Luft)
            datenlesen(self.Adresse.Text,'Rohr',Liste_Rohr)
        except:
            pass
        self.liste_Luft = Liste_Luft
        self.dataGrid.ItemsSource = Liste_Luft

    def durchsuchen(self,sender,args):
        dialog = OpenFileDialog()
        dialog.Multiselect = False
        dialog.Title = "BIM-ID Datei suchen"
        dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
        if dialog.ShowDialog() == DialogResult.OK:
            self.Adresse.Text = dialog.FileName
        self.write_config()

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()
    def checkallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = True
        self.dataGrid.Items.Refresh()

    def uncheckallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = False
        self.dataGrid.Items.Refresh()

    def toggleallbb(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.bb
            item.bb = not value
        self.dataGrid.Items.Refresh()

    def ok(self,sender,args):
        self.Close()

windowExcelBimId = ExcelBimId("Window.xaml",Liste_Luft,Liste_Rohr,Liste_Alle)
windowExcelBimId.ShowDialog()


DictAusExcel_Luft = {}
DictAusExcel_Luft_bb = {}
for el in Liste_Luft:
    if el.checked == True:
        DictAusExcel_Luft[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset,
    ]
    if el.bb == True:
        DictAusExcel_Luft_bb[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset,
    ]

DictAusExcel_Rohr = {}
DictAusExcel_Rohr_bb = {}
for el in Liste_Rohr:
    if el.checked == True:
        DictAusExcel_Rohr[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset,
    ]
    if el.bb == True:
        DictAusExcel_Rohr_bb[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset,
    ]

system_luft_final = []
system_rohr_final = []

for el in DictAusExcel_Luft.keys():
    system_luft_final.append(el)
for el in DictAusExcel_Luft_bb.keys():
    system_luft_final.append(el)
for el in DictAusExcel_Rohr.keys():
    system_rohr_final.append(el)
for el in DictAusExcel_Rohr_bb.keys():
    system_rohr_final.append(el)

WorksetListe = []
if len(DictAusExcel_Luft_bb.keys()) > 0:
    for item in DictAusExcel_Luft_bb.keys():
        WorksetListe.append(DictAusExcel_Luft_bb[item][5])
if len(DictAusExcel_Rohr_bb.keys()) > 0:
    for item in DictAusExcel_Rohr_bb.keys():
        WorksetListe.append(DictAusExcel_Rohr_bb[item][5])

fehlendeworkset = []
if len(WorksetListe) > 0:
    for item in WorksetListe:
        if not item in Workset_dict.keys():
           fehlendeworkset.append(item)
fehlendeworkset = set(fehlendeworkset)
fehlendeworkset = list(fehlendeworkset)

if any(fehlendeworkset):
    if forms.alert("fehlende Bearbeitungsbereiche erstellen?", ok=False, yes=True, no=True):
        t = DB.Transaction(doc)
        t.Start('Bearbeitunsbereich erstellen')
        for el in fehlendeworkset:
            logger.info(30*'-')
            logger.info(el)
            try:
                item = DB.Workset.Create(doc,el)
                Workset_dict[el] = item.Id.ToString()
                logger.info('Bearbeitunsbereich {} erstellt'.format(el))
            except Exception as e:
                logger.error(e)
        doc.Regenerate()
        t.Commit()
        t.Dispose()


# Luft System
luftsys = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
luftsysids = luftsys.ToElementIds()
luftsys.Dispose()

# Rohr System
rohrsys = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
rohrsysids = rohrsys.ToElementIds()
rohrsys.Dispose()


syslistluftids = {}
for sysid in luftsysids:
    elem = doc.GetElement(sysid)
    systyp = elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
    if systyp in system_luft_final:
        if systyp in syslistluftids.keys():
            syslistluftids[systyp].append(sysid)
        else:
            syslistluftids[systyp] = [sysid]

syslistrohrids = {}
for sysid in rohrsysids:
    elem = doc.GetElement(sysid)
    systyp = elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsValueString()
    if systyp in system_rohr_final:
        if systyp in syslistrohrids.keys():
            syslistrohrids[systyp].append(sysid)
        else:
            syslistrohrids[systyp] = [sysid]


class MEPSystem:
    def __init__(self,elemid,liste):
        self.elemid = elemid
        self.elem = doc.GetElement(self.elemid)
        self.typid = self.elem.get_Parameter(DB.BuiltInParameter.ELEM_TYPE_PARAM).AsElementId()
        self.typ = doc.GetElement(self.typid)
        self.liste = liste
        self.GK = self.liste[0]
        self.KG = self.liste[1]
        self.KN01 = self.liste[2]
        self.KN02 = self.liste[3]
        self.bimid = self.liste[4]

    def wert_schreiben(self, elem, param_name, wert):
            if not wert is None:
                if elem.LookupParameter(param_name):
                    elem.LookupParameter(param_name).Set(wert)
    
    def DatenSchreiben_System(self):
        self.wert_schreiben(self.typ,'IGF_X_Gewerkkürzel',str(self.GK))
        self.wert_schreiben(self.typ,'IGF_X_Kostengruppe',int(self.KG))
        self.wert_schreiben(self.typ,'IGF_X_Kennnummer_1',int(self.KN01))
        self.wert_schreiben(self.typ,'IGF_X_Kennnummer_2',int(self.KN02))
        self.wert_schreiben(self.typ,'IGF_X_BIM-ID',str(self.bimid))

class bauteil:
    def __init__(self,elemid,liste):
        self.elemid = elemid
        self.elem = doc.GetElement(self.elemid)
        self.liste = liste
        self.GK = self.liste[0]
        self.KG = self.liste[1]
        self.KN01 = self.liste[2]
        self.KN02 = self.liste[3]
        self.bimid = self.liste[4]

    def wert_schreiben(self, elem, param_name, wert):
            if not wert is None:
                if elem.LookupParameter(param_name):
                    elem.LookupParameter(param_name).Set(wert)
    
    def DatenSchreiben(self):
        self.wert_schreiben(self.elem,'IGF_X_Gewerkkürzel_Exemplar',str(self.GK))
        self.wert_schreiben(self.elem,'IGF_X_KG_Exemplar',int(self.KG))
        self.wert_schreiben(self.elem,'IGF_X_KN01_Exemplar',int(self.KN01))
        self.wert_schreiben(self.elem,'IGF_X_KN02_Exemplar',int(self.KN02))
        self.wert_schreiben(self.elem,'IGF_X_BIM-ID_Exemplar',str(self.bimid))

nichtbearbeitet_duct = DictAusExcel_Luft.keys()[:]
bearbeitet_duct = []

if any(DictAusExcel_Luft):
    Systemtypliste = syslistluftids.keys()
    with forms.ProgressBar(title="{value}/{max_value} Luftkanal Systeme",cancellable=True, step=1) as pb:
        t = DB.Transaction(doc,'Luftkanal Systeme')
        t.Start()
        for n, typ in enumerate(Systemtypliste):
            if pb.cancelled:
                if forms.alert('bisherige Änderung behalten?',yes=True,no=True,ok=False):
                    t.Commit()
                    logger.info('BIM ID wurden in folgenede Systeme geschrieben.')
                    for el in bearbeitet_duct:
                        logger.info(el)
                    logger.info('---------------------------------------')
                    logger.info('BIM ID werden in folgenede Systeme noch nicht geschrieben.')
                    for el in nichtbearbeitet_duct:
                        logger.info(el)
                else:
                    t.RollBack()
                
                script.exit()

            pb.update_progress(n + 1, len(Systemtypliste))
            if typ in DictAusExcel_Luft.keys():
                for id in syslistluftids[typ]:
                    liste_temp = DictAusExcel_Luft[typ]
                    system_temp = MEPSystem(id,liste_temp)
                    try:
                        system_temp.DatenSchreiben_System()
                    except Exception as e:
                        logger.error(e)
                    break
                bearbeitet_duct.append(typ)
                nichtbearbeitet_duct.remove(typ)
        t.Commit()
        t.Dispose()

if any(system_luft_final):
    Systemtypliste = syslistluftids.keys()      
    with forms.ProgressBar(title="{value}/{max_value} Elements",cancellable=True, step=1) as pb:
        for n0,typ in enumerate(Systemtypliste):
            sysliste = syslistluftids[typ]
            t1 = DB.Transaction(doc,'Bauteile ' + typ)
            t1.Start()
            if typ in DictAusExcel_Luft.keys():
                daten = DictAusExcel_Luft[typ]
                if typ in DictAusExcel_Luft_bb.keys():
                    bb = DictAusExcel_Luft[typ][5]
                else:
                    bb = None              
                
                for n1,systemid in enumerate(sysliste):
                    elements = list(doc.GetElement(systemid).DuctNetwork)
                    title = str(n0+1) + '/' + str(len(Systemtypliste)) + ' Luftkanalsystemtyp ---- ' + \
                        str(n1+1) + '/' + str(len(sysliste)) + ' Luftkanal Systeme ---- ' + "{value}/{max_value} Elements ---- " + typ
                    
                    pb.title = title 
                    pb.step = int(len(elements)/500)+1    
                    for n2,el in enumerate(elements):
                        if pb.cancelled:
                            t1.RollBack()
                            script.exit()
                        pb.update_progress(n2 + 1, len(elements))

                        if el.Category.Id.ToString() in ['-2008000','-2008020']:
                            try:
                                if el.MEPSystem.Id.ToString() == systemid.ToString():
                                    kanal = bauteil(el.Id,daten)
                                    kanal.DatenSchreiben()
                                    if bb:
                                        try:
                                            kanal.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                        except:
                                            pass
                            except Exception as e:
                                logger.error(e)
                                pass
                        elif el.Category.Id.ToString() == '-2008013':
                            try:
                                if list(el.MEPModel.ConnectorManager.Connectors)[0].MEPSystem.Id.ToString() == systemid.ToString():
                                    auslass = bauteil(el.Id,daten)
                                    auslass.DatenSchreiben()
                                    if bb:
                                        try:
                                            auslass.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                        except:
                                            pass
                            except:
                                pass

                        elif el.Category.Id.ToString() in ['-2008010','-2008016','-2001140']:
                            conns = el.MEPModel.ConnectorManager.Connectors
                            In = {}
                            Out = {}
                            Unverbunden = {}
                            for conn in conns:
                                if conn.IsConnected:
                                    if conn.Direction.ToString() == 'In':
                                        In[conn.Id] = conn
                                    else:
                                        Out[conn.Id] = conn
                                else:
                                    Unverbunden[conn.Id] = conn
                            sorted(In)
                            sorted(Out)
                            sorted(Unverbunden)
                            conns = In.values()[:]
                            connouts = Out.values()[:]
                            connunvers = Unverbunden.values()[:]
                            conns.extend(connouts)
                            conns.extend(connunvers)
                            
                            try:
                                for conn in conns:
                                    if not conn.MEPSystem:
                                        continue
                                    else:
                                        if conn.MEPSystem.Id.ToString() == systemid.ToString():
                                            formteilUndZubehoer = bauteil(el.Id,daten)
                                            formteilUndZubehoer.DatenSchreiben()
                                            if bb:

                                                try:
                                                    formteilUndZubehoer.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                                except:
                                                    pass
                                        break
                            except:
                                pass
            else:
                bb = DictAusExcel_Luft_bb[typ][5]
                for n1,systemid in enumerate(sysliste):
                    elements = list(doc.GetElement(systemid).DuctNetwork)
                    title = str(n0+1) + '/' + str(len(Systemtypliste)) + ' Luftkanalsystemtyp ---- ' + \
                        str(n1+1) + '/' + str(len(sysliste)) + ' Luftkanal Systeme ---- ' + "{value}/{max_value} Elements ---- " + typ
                    
                    pb.title = title 
                    pb.step = int(len(elements)/500)+1    
                    for n2,el in enumerate(elements):
                        if pb.cancelled:
                            t1.RollBack()
                            script.exit()
                        pb.update_progress(n2 + 1, len(elements))

                        if el.Category.Id.ToString() in ['-2008000','-2008020']:
                            try:
                                if el.MEPSystem.Id.ToString() == systemid.ToString():
                                    try:
                                        el.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                    except:
                                        pass
                            except Exception as e:
                                logger.error(e)
                        elif el.Category.Id.ToString() == '-2008013':
                            try:
                                if list(el.MEPModel.ConnectorManager.Connectors)[0].MEPSystem.Id.ToString() == systemid.ToString():                                    
                                    try:
                                        el.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                    except:
                                        pass
                            except:
                                pass

                        elif el.Category.Id.ToString() in ['-2008010','-2008016','-2001140']:
                            conns = el.MEPModel.ConnectorManager.Connectors
                            In = {}
                            Out = {}
                            Unverbunden = {}
                            for conn in conns:
                                if conn.IsConnected:
                                    if conn.Direction.ToString() == 'In':
                                        In[conn.Id] = conn
                                    else:
                                        Out[conn.Id] = conn
                                else:
                                    Unverbunden[conn.Id] = conn
                            sorted(In)
                            sorted(Out)
                            sorted(Unverbunden)
                            conns = In.values()[:]
                            connouts = Out.values()[:]
                            connunvers = Unverbunden.values()[:]
                            conns.extend(connouts)
                            conns.extend(connunvers)
                            
                            try:
                                for conn in conns:
                                    if not conn.MEPSystem:
                                        continue
                                    else:
                                        if conn.MEPSystem.Id.ToString() == systemid.ToString():
                                            try:
                                                el.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                            except:
                                                pass
                                        break
                            except:
                                pass

            try:
                t1.Commit()
            except Exception as e:
                print(e)
                t1.RollBack()
            t1.Dispose()

nichtbearbeitet_pipe = DictAusExcel_Rohr.keys()[:]
bearbeitet_pipe = []

if any(DictAusExcel_Rohr):
    Systemtypliste = syslistrohrids.keys()
    with forms.ProgressBar(title="{value}/{max_value} Rohr Systeme",cancellable=True, step=1) as pb:
        t = DB.Transaction(doc,'Rohr Systeme')
        t.Start()
        
        for n, typ in enumerate(Systemtypliste):
            if pb.cancelled:
                if forms.alert('bisherige Änderung behalten?',yes=True,no=True,ok=False):
                    t.Commit()
                    logger.info('BIM ID wurden in folgenede Systeme geschrieben.')
                    for el in bearbeitet_pipe:
                        logger.info(el)
                    logger.info('---------------------------------------')
                    logger.info('BIM ID werden in folgenede Systeme noch nicht geschrieben.')
                    for el in nichtbearbeitet_pipe:
                        logger.info(el)
                else:
                    t.RollBack()
                
                script.exit()

            pb.update_progress(n + 1, len(Systemtypliste))
            if typ in DictAusExcel_Luft.keys():
                for id in syslistluftids[typ]:
                    liste_temp = DictAusExcel_Luft[typ]
                    system_temp = MEPSystem(id,liste_temp)
                    try:
                        system_temp.DatenSchreiben_System()
                    except Exception as e:
                        logger.error(e)
                    break
                bearbeitet_pipe.append(typ)
                nichtbearbeitet_pipe.remove(typ)
        t.Commit()
        t.Dispose()
    

if any(system_rohr_final):
    Systemtypliste = syslistrohrids.keys()
    with forms.ProgressBar(title="{value}/{max_value} Elements",cancellable=True, step=1) as pb:
        for n0,typ in enumerate(Systemtypliste):
            sysliste = syslistrohrids[typ]
            t1 = DB.Transaction(doc,'Bauteile ' + typ)
            t1.Start()
            if typ in DictAusExcel_Rohr.keys():
                daten = DictAusExcel_Rohr[typ]
                if typ in DictAusExcel_Rohr_bb.keys():
                    bb = DictAusExcel_Rohr[typ][5]
                else:
                    bb = None   
                
                for n1,systemid in enumerate(sysliste):
                    elements = list(doc.GetElement(systemid).PipingNetwork)
                    title = str(n0+1) + '/' + str(len(Systemtypliste)) + ' Rohrsystemtyp ---- ' + \
                        str(n1+1) + '/' + str(len(sysliste)) + ' Rohr Systeme ---- ' + "{value}/{max_value} Elements ---- " + typ
                    pb.title = title 
                    pb.step = int(len(elements)/500)+1
                    for n2,el in enumerate(elements):
                        if pb.cancelled:
                            t1.RollBack()
                            script.exit()
                        pb.update_progress(n2 + 1, len(elements))
                        if el.Category.Id.ToString() in ['-2008050','-2008044']:
                            try:
                                if el.MEPSystem.Id.ToString() == systemid.ToString():
                                    rohr = bauteil(el.Id,daten)
                                    rohr.DatenSchreiben()
                                    if bb:
                                        try:
                                            el.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                        except:
                                            pass
                            except:
                                pass

                        elif el.Category.Id.ToString() == '-2008099':
                            try:
                                if list(el.MEPModel.ConnectorManager.Connectors)[0].MEPSystem.Id.ToString() == systemid.ToString():
                                    sprinkler = bauteil(el.Id,daten)
                                    sprinkler.DatenSchreiben()
                                    if bb:
                                        try:
                                            el.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                        except:
                                            pass
                            except:
                                pass

                        elif el.Category.Id.ToString() in ['-2008049','-2008055','-2001140','-2001160']:
                            conns = el.MEPModel.ConnectorManager.Connectors
                            In = {}
                            Out = {}
                            Unverbunden = {}
                            for conn in conns:
                                if conn.IsConnected:
                                    if conn.Direction.ToString() == 'In':
                                        In[conn.Id] = conn
                                    else:
                                        Out[conn.Id] = conn
                                else:
                                    Unverbunden[conn.Id] = conn
                            sorted(In)
                            sorted(Out)
                            sorted(Unverbunden)
                            conns = In.values()[:]
                            connouts = Out.values()[:]
                            connunvers = Unverbunden.values()[:]
                            conns.extend(connouts)
                            conns.extend(connunvers)
                            
                            try:
                                for conn in conns:
                                    if not conn.MEPSystem:
                                        continue
                                    else:
                                        if conn.MEPSystem.Id.ToString() == systemid.ToString():
                                            formteilUndZubehoer = bauteil(el.Id,daten)
                                            formteilUndZubehoer.DatenSchreiben()
                                            if bb:
                                                try:
                                                    el.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                                except:
                                                    pass
                                        break
                            except:
                                pass
            
            else:
                bb = DictAusExcel_Rohr_bb[typ][5]
                for n1,systemid in enumerate(sysliste):
                    elements = list(doc.GetElement(systemid).PipingNetwork)
                    title = str(n0+1) + '/' + str(len(Systemtypliste)) + ' Rohrsystemtyp ---- ' + \
                        str(n1+1) + '/' + str(len(sysliste)) + ' Rohr Systeme ---- ' + "{value}/{max_value} Elements ---- " + typ
                    pb.title = title 
                    pb.step = int(len(elements)/500)+1
                    for n2,el in enumerate(elements):
                        if pb.cancelled:
                            t1.RollBack()
                            script.exit()
                        pb.update_progress(n2 + 1, len(elements))
                        if el.Category.Id.ToString() in ['-2008050','-2008044']:
                            try:
                                if el.MEPSystem.Id.ToString() == systemid.ToString():                                  
                                    try:
                                        el.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                    except:
                                        pass
                            except:
                                pass

                        elif el.Category.Id.ToString() == '-2008099':
                            try:
                                if list(el.MEPModel.ConnectorManager.Connectors)[0].MEPSystem.Id.ToString() == systemid.ToString():
                                    try:
                                        el.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                    except:
                                        pass
                            except:
                                pass

                        elif el.Category.Id.ToString() in ['-2008049','-2008055','-2001140','-2001160']:
                            conns = el.MEPModel.ConnectorManager.Connectors
                            In = {}
                            Out = {}
                            Unverbunden = {}
                            for conn in conns:
                                if conn.IsConnected:
                                    if conn.Direction.ToString() == 'In':
                                        In[conn.Id] = conn
                                    else:
                                        Out[conn.Id] = conn
                                else:
                                    Unverbunden[conn.Id] = conn
                            sorted(In)
                            sorted(Out)
                            sorted(Unverbunden)
                            conns = In.values()[:]
                            connouts = Out.values()[:]
                            connunvers = Unverbunden.values()[:]
                            conns.extend(connouts)
                            conns.extend(connunvers)
                            
                            try:
                                for conn in conns:
                                    if not conn.MEPSystem:
                                        continue
                                    else:
                                        if conn.MEPSystem.Id.ToString() == systemid.ToString():
                                            try:
                                                el.elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[bb]))
                                            except:
                                                pass
                                        break
                            except:
                                pass
                            
            try:
                t1.Commit()
            except:
                t1.RollBack()
            t1.Dispose()